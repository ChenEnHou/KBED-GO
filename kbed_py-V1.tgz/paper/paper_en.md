# Conditions for Decomposition in Hierarchical Exact Computation: Testing KBED's Local Valuation, Composition and Boundaries on Go Endgames

Chen-En Hou · October 8, 2026

## Abstract

KBED (Knot-Belt Exhaustive Decomposition) holds that exhaustive coverage of a finite state space does not require deriving every state independently: the problem can be cut into local units (knots), each solved exactly, and the results composed. This study uses Go endgames as a controlled setting to test the premises of that claim: when local exact values can be composed directly, when the parts must be merged and recomputed, and whether these conditions can be decided before merging.

Local values are computed with combinatorial game theory (CGT) and compared position by position against exhaustive search of the whole board. Four experiments relax the interface step by step:

- T1, T2: independent regions separated by uncapturable walls, testing summation and substitution of equal values;
- T3: regions joined by a capturable wall, testing detection of interaction;
- T4: virtual boundaries drawn through open areas, testing the exactness of arbitrary cuts and the reliability of advance screening.

Main results:

- With an empty interface, summed local values agree with exhaustive search in 316/316 positions, and swapping regions of equal value leaves the score unchanged in all 1000 contexts.
- Through a shared object, interaction can involve three regions. Decomposition is exact whenever premises hold, but premise checks cannot be both miss-free and low in false alarms.
- On virtual boundaries, arbitrary cuts give the exact score in only 35% of cases. The final screen, M1v, showed no false acceptance in a new, pre-registered sample (0/71), but recognises only 21% of exact cuts; its general correctness is not established.

No new mathematical result is claimed. The contribution has three parts:

1. turning "when can local results be composed" into an interface question that can be checked position by position;
2. identifying three concrete cross-boundary dependencies: the interface depending on both sides, capture transitions on the interface, and shared liberties;
3. measuring the coverage and cost limits of current screening.

## 1. Aim and research questions

KBED's core proposition is that, under full coverage, the computation that must be done independently can be smaller than the raw number of states. For this to be usable, one must first answer: when can local exact results be composed into an exact global result without recomputation?

Figure 1 sketches the KBED structure:

- initial points expand through legal moves into layers of succession;
- computable, reusable local structures in this network are knots;
- mapping and reuse between knots require verified exact equivalence;
- when an interface fails, adjacent knots must be merged and recomputed.

This study tests one link of that structure: the interface between knots.

![Figure 1. KBED structure (points, succession, knots and ring). Schematic, not computed data; T1–T4 mark the interface type each experiment tests.](fig/ring_en.png)

Go endgames are a suitable test setting for three reasons:

- mature local theory exists for comparison: CGT and the Berlekamp–Wolfe correspondence for endgames;
- small positions can be searched exhaustively, giving a position-by-position ground truth;
- interactions between local parts (shared liberties, sente, captures) are concrete and observable.

Research questions:

- **Q1**: When regions are independent, does the sum of local values agree with exhaustive search?
- **Q2**: Are local parts of equal value interchangeable? Are stops or temperature enough?
- **Q3**: When local parts are joined through a shared object, when do premises break, and can this be detected in advance?
- **Q4**: When an area is cut along a virtual boundary, when is the sum exact, and can such cases be screened reliably before solving the merged area?

Q1 and Q2 reproduce existing theory as calibration of the instrument; Q3 and Q4 are experiments on KBED's interface problem.

## 2. Background

- **Combinatorial game theory** (Conway; Berlekamp, Conway & Guy): independent local parts can be represented by values, and the outcome of a sum is determined by the values; $G=H$ iff $G-H$ is a second-player win, and equal values are interchangeable in any sum.
- **Sums of scored games**: the score is given by the left and right stops of the sum (Milnor).
- **Berlekamp and Wolfe** map Go endgames onto this theory by chilling.
- **Müller's decomposition search** solves endgames exactly by combining local values, given independent regions, safe boundaries and no ko.
- **Mechanisms this study borrows**:
    - "a result is reused while its premises hold and recomputed when they change", i.e., truth maintenance (Doyle) and incremental computation (Acar);
    - wall safety follows Benson's notion of unconditional life.

## 3. Method

### 3.1 Position model and rules

- **Walls**: uncapturable stones, representing walls proved unconditionally alive with single-point eyes.
- **End of game**: two consecutive passes.
- **Scoring**: Japanese territory counting. Dead stones (groups captured even when their owner moves first) count as prisoners and their points as the opponent's territory.
- **Settled regions**: no dame remain, and every live group in the region survives even with the opponent moving first. A settled position takes its count as its local value.
- **Ko** is handled under two protocols:
    - T1–T3: any ko shape in any search removes the position;
    - T4: exhaustive search uses the basic ko rule with the ko-banned point in the state, and a cycle in the state graph removes the position. With this state definition, table lookups do not depend on move history.

### 3.2 Valuation, basis of comparison and counting

- **Local value**: play only inside the local part with everything else frozen, recursively computing the reduced CGT canonical form, captures included in the value.
- **Decomposition**: sum the local values; the left stop gives the score with Black first, the right stop with White first; the best first move is determined from the stops of the summed value. "Chill, sum, solve, warm" serves as a cross-check.
- **Ground truth**: exhaustive search of the whole board, once with Black first and once with White first.
- **Basis of comparison**: "exact" means throughout, except in T2, that the scores with Black first and with White first agree with exhaustive search. It does not mean that local values preserve the full game value, optimal strategies or interchangeability in all contexts; the latter is tested only in T2.
- **Counting computation**: distinct states expanded (table hits not counted).
    - Exhaustive search counts whole-board states.
    - Decomposition counts the states of all local valuations.
    - Screening counts the local valuations of M1 and of the parts added in M1v. Valuations in M1t and in the static interface-side screen are not counted, so screening cost is underestimated.
    - Capture searches for dead-stone determination are not counted on either side.
    - Node counts are not running times.
- **Regression tests**:
    - `regress_ko.py`: on 280 tiny positions with ko, search with and without the table agrees exactly;
    - `regress_value4.py`: the 20 regions of local value 4, computed in sequence in one run, all agree with isolated exhaustive search. This guards the cache error described in Section 4.5.

Figure 2 shows the valuation and comparison procedure.

![Figure 2. Valuation and comparison procedure.](fig/flow_en.png)

### 3.3 Experimental design

**T1, T2**: 9×9 board; walls separate 2 to 5 regions of 2 to 6 points; at most 12 empty points.

- T1: compare decomposition with exhaustive search on score and first move.
- T2: regions cut from T1 positions are compared before and after substitution in the constructed distinguishing context $-B$ ($B$ with colours swapped) and in random contexts.

**T3**: a capturable chain touches 1 to 3 regions.

- **Minimal violating set** $S$: the merged value of the regions in $S$ with the wall differs from the sum of their values under the assumption that the wall cannot be captured, and $S$ contains no smaller violating set.
- **Detectors**:
    - D1: can the attacker capture the wall moving first;
    - D1b, D1c: the same after one or two free attacker moves;
    - D2: colour difference, i.e., whether the value of a region not played in changes.
- Checked after every move along the exhaustive optimal line.

**T4 (virtual boundaries)**: 7×7 board; an open area of 7 to 10 points in the centre, on an edge or in a corner; separators $S$ of 1 to 3 points, stones allowed.

- M0: cut and add, with the interface as a separate part; a variant assigns the interface to one knot.
- M2: exhaustive search of the merged area (ground truth).
- Screens were added round by round:
    - M1: knots insensitive to fixed interface states;
    - M1b: plus interface insensitive to both sides;
    - M1t: knots insensitive to states reached by actual play on the interface;
    - M1v: all of the above, plus an interface-side screen by actual play and a structural check on whole groups (a group whose stones and liberties span two or more parts forces a merge).
- Each round's criterion was recorded before running and tested on new random seeds: zero errors among cases passing the screen.
- The cost measurement listed as T4 in design v0.3 is reported here within T4 as a diagnostic.

## 4. Results

### 4.1 T1: summation over independent regions (316 positions)

| Item | Result |
|---|---|
| Score, Black first and White first | 316/316 |
| Decomposition's first move in the optimal set | 316/316 |
| Optimal move sets identical | 315/316 (difference only in passing) |
| Score via chilling | 316/316 |
| Hottest region contains an optimal move | 154/316 |
| Median states: exhaustive, decomposition | 6,885 and 9 (maxima 8,014,100 and 561) |

Notes:

- The single difference is one of rule representation: in a real game a pass lets the opponent pass and end the game, which stops do not include.
- Choosing by temperature alone is right only about half the time even in endgames this small.
- With an empty interface, decomposition needs about three orders of magnitude fewer states than exhaustive search.

### 4.2 T2: substitution (350 pairs, 1750 contexts)

| Category | Result |
|---|---|
| 200 pairs of equal value | score unchanged in all 1000 contexts |
| 50 pairs, different values and different stops | all differ |
| 100 pairs, different values but equal stops | 6 differ, only in the constructed $-B$ context; 94 are indistinguishable in all tested contexts |

Merging regions by stops or temperature alone is unsafe. For the query "score", on the other hand, values distinguish more than needed (mostly $*$ against $0$). Constructed contexts are far more effective than random ones.

### 4.3 T3: a capturable wall

Units: 1250 constructed H5 positions; 7870 states along optimal lines. Minimal violating sets are counted per state; decomposition correctness per position, at the root state.

- **Sizes of minimal violating sets** (over 7870 states): one region 433, two 580, three 415. Interactions appearing only among three regions are common; pairwise checks are insufficient.
- **Detection** (per state):

| Detector | Misses | False alarms |
|---|---|---|
| D1 | 147 | 0 |
| D1b | 11 | 1074 |
| D1c | 1 | 1735 |
| D2 | never fired | — |

- D1's misses come from sente threats: the wall cannot die, but when put in atari it must be reinforced, giving the attacker a tempo.
- Per root state: decomposition is exact in all 862 positions where premises hold, and in only 73 of the 388 where they are broken.

### 4.4 T4: virtual boundaries

The unit is the cut. Up to 4 cuts are taken per position, so cuts are not statistically independent.

**Sample** (rounds 2–5 pooled):

- Of the positions generated, 2312 were valid and 6342 were removed for cycles (73.3%).
- Of the cuts on valid positions, 3214 were analysed and 2072 skipped for local ko or cycles (39.2%).

**Exactness of cutting (M0, by score):** 1112/3214 (35%) overall.

| Factor | Exactness |
|---|---|
| Interface width 1, 2, 3 | 42%, 29%, 23% |
| 0, 1, 2 stones on the interface | 27%, 47%, 68% |
| With, without a junction | 27%, 35% |
| 2, 3 or more knots | 36%, 26% |
| Interface assigned to one knot | at least one assignment exact 75%; every assignment exact 38% |

"At least one assignment exact" is an upper bound obtained by choosing after the fact: which side to assign the interface to is not known in advance. It suggests that asymmetric assignment of the interface may beat a seam knot, but this needs a method for deciding the assignment beforehand.

**Pre-registered screens by round:**

| Round | Sample (new seeds) | Cuts | Screen | Passed | Errors | Criterion |
|---|---|---|---|---|---|---|
| 2 | from 500000 | 649 | M1b | 54 | 1 | failed |
| 3 | from 700000 | 752 | M1t plus interface side | 166 | 24 | failed |
| 4 | from 800000 | 819 | M1, M1t, M1b | 72 | 1 | failed |
| 5 | from 900000 | 994 | M1v | 71 | 0 | passed |

**Effect of each check in round 5** (994 cuts; 337 exact under M0):

| Screen combination | Passed | Errors | Additional rejections |
|---|---|---|---|
| M1 | 164 | 68 | — |
| M1b | 89 | 0 | 75 |
| M1b plus M1t | 89 | 0 | 0 |
| plus interface side by play | 80 | 0 | 9 |
| plus structural check (= M1v) | 71 | 0 | 9 |

M1v's pass rate is 71/994 (7%); its coverage of exact cuts is 71/337 (21%).

**Failure types:**

| Type | Content | Premise |
|---|---|---|
| A Interface depends on both sides | an interface point valued alone counts as territory of the adjacent colour | interface dependence |
| B Capture on the interface | a stone on one side has its last liberty on the interface; the fixed-state screen skipped "interface holds an opponent stone" as illegal, though that is a capturing move | transitions, sente threats |
| C Shared liberties | a stone on the interface with its two liberties on different sides; capturing it needs a move on each side | shared liberties |

Round 3 failed because of a design error in the screen itself: with a stone already on the interface, M1t sees only the current state.

Instances of types B and C follow. Symbols: X and O are uncapturable walls, x and o capturable stones, . an empty point. Only rows containing the open area are shown; rows and columns are counted from 0.

```
Type B (seed 500781; separator S = row 1, column 3, empty)
     0123456
  0  XXoxOXX      knot A = {(0,2) o, (0,3) x}
  1  XOO..OO      S = (1,3)
  2  XX.x.XO      knot B = {(1,4), (2,2), (2,3) x, (2,4)}
The black stone (0,3) has its last liberty on S; White playing S captures it.
Exhaustive: Black first 0, White first -2; cut and add: Black first 0, White first -1.
```

```
Type C (seed 850002; separator S = row 3, column 3, holding a black stone)
     0123456
  2  O..oOXX      knot A = {(2,1), (2,2), (2,3) o, (3,2)}
  3  XO.x..X      S = (3,3) x
  4  XOXOXXO      knot B = {(3,4), (3,5)}
The black stone on S has its two liberties (3,2) and (3,4) in A and B;
White needs one move in A and one in B to capture it.
Exhaustive: Black first 0, White first -1; cut and add: Black first 0, White first 0.
```

**Cost (diagnostic; basis in Section 3.2):**

- Round 5 median states: screening about 150, merged solving about 2460.
- For cuts accepted by M1v: cut plus screen 148, merging 836.
- Because screening cost is underestimated and only 7% of cuts pass, "screen, merge if rejected" costs about as much as merging directly at this scale.

### 4.5 Implementation errors and corrections

The following errors were found and corrected during the work; results from erroneous versions are kept.

| Error | How found | Effect | Action |
|---|---|---|---|
| Dead stones not removed at the end | T1 disagreed immediately | invasions paid, contrary to the CGT model | switched to Japanese counting |
| Dead-stone cache omitted wall colours and was shared across positions | the same position gave different results on two runs | results leaked between positions; also produced a false counterexample reported by another reviewer | key fixed, T1 rerun, `regress_value4.py` added |
| Version 1 of T4 stored history-dependent values in the table | external code review | ground truth unreliable | ko point added to the state, cycles rejected, `regress_ko.py` added; version 1 void |

## 5. Discussion

1. **With an empty interface, composition is exact**, with about three orders of magnitude fewer states than exhaustive search. Two additions: moves must be chosen from the exact sum of values, not by temperature; values are a necessary identifier but may be finer than a given query needs. This agrees with KBED's view that the query determines how much a representation must preserve.
2. **With a non-empty interface, every error observed can be described by shared objects, transitions and interface dependence.** This supports attaching knot premises to shared objects and checking whole groups with the distribution of their liberties, and supports a hypergraph as the representation of interaction. It is not shown that every interaction stays within the neighbourhood of a single shared object: move order and multi-stage transitions may propagate dependence further, and moves away from the interface or several dependencies at once may produce new types. The premise list cannot be taken as complete.
3. **The trade-off between safety and coverage.** T3's detectors and T4's screens show the same trade-off: reducing misses requires accepting many false alarms or rejections. At the scale studied, the cost of interface checking offsets the saving from decomposition.
4. **Relation to KBED.** The results support KBED v1.9's assessment that the computational advantage depends on the size and handling cost of interfaces, and give it an operational form: compute separately when the interface is small and provably insensitive, merge otherwise. A consequence still to be tested is that the net benefit of decomposition depends on the size of interfaces relative to knot interiors; the regions in this study are small, so this ratio is high. How it behaves at larger scale has not been measured.

## 6. Limitations

1. **Small scale.** At most 12 empty points in T1 and T2; open areas of 7 to 10 points in T4.
2. **Ko and cycles.**
    - T1–T3 exclude all ko;
    - in T4, 73.3% of positions were removed and 39.2% of cuts skipped.
    - Tempo fights and ko threats are likely concentrated in what was excluded.
3. **Power.**
    - Round 5's zero (0/71) has a one-sided 95% upper bound on the error rate of about 4%;
    - cuts from the same position are not independent, so the effective sample is smaller than 71;
    - in that round even M1b alone made no error, so the known hard types did not occur in the sample.
4. **Post-hoc design.** Screening rules were added after seeing errors; only the last round's sample was generated after the rules were fixed.
5. **Basis of comparison.** "Exact" refers to the score, not to full game values or strategies.
6. **Cost counting.** Counts are states, not running time, and part of the screening cost is not counted.
7. **Independent replication.** Another reviewer's reruns used the same code and are not an independent implementation.
8. **Approximate temperature.** Temperature is approximated by half the difference of the stops, not a full thermograph.

## 7. Conclusion

- In this controlled setting, local exact values compose safely when the interface is empty and greatly reduce computation, reproducing existing theory.
- With a non-empty interface, sums are usually inexact. The errors observed reduce to three cross-boundary dependencies that corresponding checks remove. The final screen showed no false acceptance on a new, pre-registered sample, but recognises only about a fifth of exact cuts, and its general correctness is not established.
- KBED's decomposition claim has clear conditions of validity on endgames, but its computational advantage across general interfaces is not established.
- Next steps:
    - handle local ko;
    - study the rejected exact cuts and ways to decide interface assignment in advance;
    - measure interface ratio and cost at larger scale;
    - choose exact algorithms per knot according to its structure, provided rules and result semantics are shared.

## Appendix: data and reproduction

- **Files**: all code, raw results, each round's pre-registration and the counterexamples are in `kbed_handoff_2026-10-08.tgz`; reproduction steps and file descriptions are in its `HANDOFF.md`, and the timeline is in `go/PROGRESS.md`.
- **Environment**: Python 3.13, standard library only; Linux, 2 cores.
- **Random seeds**:

| Experiment | Seed range |
|---|---|
| T1 | 1000–2199, 6000–6684 |
| T2 | regions cut from valid T1 positions; contexts drawn with fixed seed 7 |
| T3 (H5) | 100000–119999 |
| T4 round 2 | 500000–501752 |
| T4 round 3 | 700000–701118, 750000–751112 |
| T4 round 4 | 800000–801032, 850000–851363 |
| T4 round 5 | 900000–901459, 950000–951522 |

- **Main commands**:
    - T1: `python3 t1.py OUT start end 12 900`
    - T2: `python3 t2.py OUT 200 4 12`
    - T3: `T3CFG=... python3 t3.py OUT start end`
    - T4: `python3 t4.py OUT start end`

## References

- Acar, U. A. *Self-Adjusting Computation*. PhD thesis, Carnegie Mellon University, 2005.
- Benson, D. B. Life in the Game of Go. *Information Sciences* 10(2), 17–29, 1976.
- Berlekamp, E. R., Conway, J. H., & Guy, R. K. *Winning Ways for Your Mathematical Plays*. Academic Press, 1982.
- Berlekamp, E. R., & Wolfe, D. *Mathematical Go: Chilling Gets the Last Point*. A K Peters, 1994.
- Conway, J. H. *On Numbers and Games*. Academic Press, 1976.
- Doyle, J. A Truth Maintenance System. *Artificial Intelligence* 12(3), 231–272, 1979.
- Hou, C.-E. *KBED Methodology v1.9*. 2026.
- Milnor, J. Sums of Positional Games. In *Contributions to the Theory of Games II*, Annals of Mathematics Studies 28, 291–301, 1953.
- Müller, M. Decomposition Search: A Combinatorial Games Approach to Game Tree Search, with Applications to Solving Go Endgames. *IJCAI* 1999.
- Müller, M., Berlekamp, E., & Spight, B. Generalized Thermography: Algorithms, Implementation, and Application to Go Endgames. ICSI TR-96-030, 1996.
