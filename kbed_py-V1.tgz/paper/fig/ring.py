"""Schematic of the KBED structure (point - succession - knot - ring) on a
twisted band. Illustration only: positions are generated, not computed data.

usage: python3 ring.py zh|en OUT.png
"""
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

lang, out = sys.argv[1], sys.argv[2]
if lang == 'zh':
    for f in font_manager.findSystemFonts():
        if 'NotoSansCJK' in f.replace(' ', '') or 'NotoSansCJK' in f:
            font_manager.fontManager.addfont(f)
    plt.rcParams['font.family'] = 'Noto Sans CJK TC'
T = {
    'zh': dict(title='KBED 結構示意：點、承接、Knot 與 Ring',
               point='點（初始落子點）', succ='承接：合法著手展開的層', knot='Knot：可計算、可重用的局部結構',
               map='映射／重用（須經精確等價驗證）', fail='接口失效：合併重算',
               t12='T1–T2：接口為零', t3='T3：共用物件', t4='T4：虛擬邊界',
               note='示意圖，非計算資料。帶狀扭轉只作視覺參考；圖上相連不代表狀態可互換。'),
    'en': dict(title='KBED structure (schematic): points, succession, knots and ring',
               point='points (initial moves)', succ='succession: layers of legal moves', knot='knot: computable, reusable local structure',
               map='mapping / reuse (requires verified exact equivalence)', fail='interface failure: merge and recompute',
               t12='T1–T2: empty interface', t3='T3: shared object', t4='T4: virtual boundary',
               note='Schematic, not computed data. The twist is a visual reference only; connection in the picture does not imply interchangeable states.'),
}[lang]

rng = np.random.default_rng(3)


def band(u, v, R=3.0):
    """Moebius-like band: u in [0, 2pi), v in [-1, 1]."""
    x = (R + v * np.cos(u / 2)) * np.cos(u)
    y = (R + v * np.cos(u / 2)) * np.sin(u)
    z = v * np.sin(u / 2)
    return x, y, z


fig = plt.figure(figsize=(11, 6.4), dpi=200)
ax = fig.add_subplot(111, projection='3d')
ax.set_axis_off()

# succession layers: points on the band, edges between consecutive layers
L, P = 46, 13
us = np.linspace(0, 2 * np.pi, L, endpoint=False)
vs = np.linspace(-1.35, 1.35, P)
pts = {}
for i, u in enumerate(us):
    for j, v in enumerate(vs):
        jitter = rng.normal(0, 0.03)
        pts[(i, j)] = band(u + jitter, v + rng.normal(0, 0.02))
for i in range(L):
    for j in range(P):
        for dj in (-1, 0, 1):
            k = j + dj
            if 0 <= k < P and rng.random() < 0.33:
                a, b = pts[(i, j)], pts[((i + 1) % L, k)]
                ax.plot([a[0], b[0]], [a[1], b[1]], [a[2], b[2]], color='#9aa4ad', lw=0.25, alpha=0.6)
uu, vv = np.meshgrid(np.linspace(0, 2 * np.pi, 120), np.linspace(-1.35, 1.35, 8))
X, Y, Z = band(uu, vv)
ax.plot_surface(X, Y, Z, color='#cfd8e3', alpha=0.18, linewidth=0, shade=False)
xs, ys, zs = zip(*pts.values())
ax.scatter(xs, ys, zs, s=1.6, color='#5b6670', alpha=0.8, depthshade=False)

# initial points (layer 0) emphasised
for j in range(P):
    p = pts[(0, j)]
    ax.scatter(*p, s=10, color='#222222', depthshade=False)

# knots: clusters of points
knots = [(5, 3, '#2b7bb9'), (12, 8, '#2b7bb9'), (20, 4, '#e08a1e'), (22, 6, '#e08a1e'),
         (31, 5, '#c0392b'), (33, 7, '#c0392b'), (40, 9, '#2b7bb9')]
centers = []
for (i0, j0, col) in knots:
    cells = [(i, j) for i in range(i0 - 1, i0 + 2) for j in range(j0 - 1, j0 + 2) if 0 <= j < P]
    cx = np.mean([pts[(i % L, j)] for i, j in cells], axis=0)
    centers.append((cx, col))
    for i, j in cells:
        ax.scatter(*pts[(i % L, j)], s=14, color=col, alpha=0.9, depthshade=False)

# mapping / reuse arcs between knots (dashed)
for a, b in [(0, 1), (1, 6), (0, 6)]:
    p, q = centers[a][0], centers[b][0]
    m = (p + q) / 2 + np.array([0, 0, 1.4])
    t = np.linspace(0, 1, 40)[:, None]
    curve = (1 - t) ** 2 * p + 2 * (1 - t) * t * m + t ** 2 * q
    ax.plot(curve[:, 0], curve[:, 1], curve[:, 2], ls='--', lw=1.0, color='#2b7bb9', alpha=0.8)

# interface failure between two knots (red) and shared object (orange)
p, q = centers[4][0], centers[5][0]
ax.plot([p[0], q[0]], [p[1], q[1]], [p[2], q[2]], color='#c0392b', lw=2.2)
p, q = centers[2][0], centers[3][0]
ax.plot([p[0], q[0]], [p[1], q[1]], [p[2], q[2]], color='#e08a1e', lw=2.2)

# labels for experiments
def lab(c, text, dz=0.9, col='#222222'):
    import matplotlib.patheffects as pe
    ax.text(c[0], c[1], c[2] + dz, text, fontsize=10, color=col, ha='center', path_effects=[pe.withStroke(linewidth=3.5, foreground='white')], zorder=20)

lab(centers[0][0], T['t12'], 1.0, '#2b7bb9')
lab((centers[2][0] + centers[3][0]) / 2, T['t3'], 1.0, '#b36b10')
lab((centers[4][0] + centers[5][0]) / 2, T['t4'], 1.0, '#c0392b')

ax.view_init(elev=32, azim=-58)
ax.set_box_aspect((1, 1, 0.42), zoom=1.12)
lim = 4.1
ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim); ax.set_zlim(-1.5, 2.2)

# legend
from matplotlib.lines import Line2D
handles = [
    Line2D([0], [0], marker='o', color='w', markerfacecolor='#222222', markersize=6, label=T['point']),
    Line2D([0], [0], color='#9aa4ad', lw=1.2, label=T['succ']),
    Line2D([0], [0], marker='o', color='w', markerfacecolor='#2b7bb9', markersize=8, label=T['knot']),
    Line2D([0], [0], color='#2b7bb9', ls='--', lw=1.2, label=T['map']),
    Line2D([0], [0], color='#c0392b', lw=2.2, label=T['fail']),
]
ax.legend(handles=handles, loc='upper left', fontsize=8.5, frameon=False, bbox_to_anchor=(-0.02, 0.98))
fig.text(0.5, 0.90, T['title'], ha='center', fontsize=13)
fig.text(0.5, 0.12, T['note'], ha='center', fontsize=8, color='#555555')
plt.savefig(out, bbox_inches='tight')
print('saved', out)
