import random, time
from gen import make
from goeng import *
from decomp import decompose
rng = random.Random(1)
n=0
while n<5:
    r = make(rng, max_empty=12)
    if not r: continue
    bd,b,regs = r
    t=time.time()
    try:
        fs=FullSolver(bd); v1=fs.root(b,1); v2=fs.root(b,2)
        d=decompose(bd,b,regs)
    except (Ko,Cycle) as e:
        print('skip',type(e).__name__); continue
    n+=1
    print(render(bd,b)); print(len(regs),'regions', sum(1 for x in b if x==0),'empty', 'nodes',fs.nodes, 'time %.1f'%(time.time()-t))
    print('base',v1[0],v2[0],'decomp',d['ls'],d['rs'])
