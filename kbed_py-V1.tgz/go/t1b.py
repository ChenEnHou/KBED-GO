"""Route (b) cross-check: warm(sum of chilled local values) vs route (a) and baseline."""
import json, glob, sys
import cgt
from goeng import parse
from decomp import LocalSolver
out = []
for f in sorted(glob.glob('results/t1_*.jsonl')):
    for line in open(f):
        r = json.loads(line)
        if r['status'] != 'ok':
            continue
        bd, b = parse(r['board'])
        vals = [LocalSolver(bd, reg).value(b) for reg in r['regions']]
        S = cgt.total(vals)
        C = cgt.total([cgt.chill(v) for v in vals])
        lin = (C == cgt.chill(S))
        Wm = cgt.warm(C)
        ls, rs = cgt.left_stop(Wm), cgt.right_stop(Wm)
        ok = (ls == r['base']['B_first'] and rs == r['base']['W_first'])
        rt = (cgt.warm(cgt.chill(S)) == S)
        out.append({'seed': r['seed'], 'chill_sum_equals_sum_chill': lin,
                    'warm_chill_identity': rt, 'route_b_score_ok': ok,
                    'chilled_sum': cgt.show(C), 'sum': r['sum'],
                    'b_ls': str(ls), 'b_rs': str(rs),
                    'base': [r['base']['B_first'], r['base']['W_first']]})
json.dump(out, open('results/t1_routeb.json', 'w'), ensure_ascii=False, indent=0)
n = len(out)
print('n', n, 'linear', sum(o['chill_sum_equals_sum_chill'] for o in out),
      'warm(chill)=id', sum(o['warm_chill_identity'] for o in out),
      'route b score ok', sum(o['route_b_score_ok'] for o in out))
for o in out:
    if not o['route_b_score_ok']:
        print(o); break
