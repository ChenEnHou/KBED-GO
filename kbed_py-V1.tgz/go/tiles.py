"""Cut a region with its wall border out of a board and assemble tiles."""
from goeng import Board, regions


def tile(bd, b, cells):
    xs = [c % bd.w for c in cells]
    ys = [c // bd.w for c in cells]
    x0, x1, y0, y1 = min(xs) - 1, max(xs) + 1, min(ys) - 1, max(ys) + 1
    rows = []
    cs = set(cells)
    for y in range(y0, y1 + 1):
        row = []
        for x in range(x0, x1 + 1):
            if 0 <= x < bd.w and 0 <= y < bd.h:
                p = y * bd.w + x
                v = b[p]
                if p in cs:
                    row.append(v)
                elif v >= 3 and any(n in cs for n in bd.nb[p]):
                    row.append(v)
                else:
                    row.append(None)   # filler
            else:
                row.append('edge')
        rows.append(row)
    return rows


def swap(t):
    m = {0: 0, 1: 2, 2: 1, 3: 4, 4: 3, None: None, 'edge': 'edge'}
    return [[m[v] for v in row] for row in t]


def assemble(tiles, filler=3):
    """Place tiles left to right, separated by a filler wall column.
    'edge' cells (board edge in the source) become filler walls; this keeps
    the region's liberties unchanged only if the region never touched the
    edge -- callers must use tiles of regions away from the edge, or accept
    that the edge is replaced by a wall (an edge and an uncapturable wall of
    either colour are not equivalent for territory, so we reject such tiles)."""
    h = max(len(t) for t in tiles)
    w = sum(len(t[0]) for t in tiles) + len(tiles) - 1
    bd = Board(w, h)
    b = [filler] * (w * h)
    x = 0
    for t in tiles:
        for y, row in enumerate(t):
            for dx, v in enumerate(row):
                if v is None or v == 'edge':
                    continue
                b[y * w + x + dx] = v
        x += len(t[0]) + 1
    return bd, tuple(b)


def touches_edge(t):
    return any(v == 'edge' for row in t for v in row)
