# KBED Virtual Boundary Validation: First-Round Results (v0.4)

Oct 8, 2026 · Chen-En Hou

Basis: *KBED Validation Design for Virtual Boundaries and Interfaces v0.4*, with review comments adopted: M0 as the most naive baseline; M1 as a screen, not a certificate; M3 deferred; a new factor, depth.

## 1. Summary

| Item | Result |
|---|---|
| M0 cut and add (seam knot) exact | 95/308 (31%) |
| M0 with the interface assigned to one knot | at least one assignment exact 178/308; every assignment exact 87/308 |
| M1 screen passed (coverage) | 28/308 (9%) |
| M1 passed but M0 wrong | 8/28 |
| M1 plus "interface insensitive to both sides" (two-way screen) | 20/308 passed, 0 wrong |

Most arbitrary cuts through open areas cannot be cut directly. Checking "knot insensitive to interface" is not enough; "interface insensitive to knots" must be checked too. The two-way screen made no error in this sample, but it accepts only about 6% of cuts, it was designed after seeing the errors, and the sample is small.

## 2. Setting

- 7×7 board; an open area of 7 to 10 points enclosed by uncapturable walls, in the centre, on an edge or in a corner; 0 to 3 stones in the area, possibly on the interface.
- Separator $S$ (1 to 3 points): removing it splits the area into 2 or more knots of at least 2 points, and every separator point touches at least two knots. Up to 4 separators per area.
- M2 (ground truth): exhaustive search of the whole area, score with Black first and with White first.
- M0: local values of each knot and of the seam knot, others frozen; summed, score read from the stops. A variant assigns the interface to one knot.
- M1: each knot is valued with the interface points fixed to every combination of empty, black and white; it passes only if all values are equal.
- Two-way screen (post hoc): additionally set the empty points adjacent to the interface all black, all white, or as they are, and check that the seam knot's value does not change.

## 3. Rule handling in this round (different from the first round)

Open areas almost always produce ko and repetition during exhaustive search; under the first round's "remove on ko" rule most positions would be unusable. This round therefore uses:

1. Exhaustive search with the basic ko rule (no immediate recapture) and positional superko (no repeated position). The transposition table ignores this path dependence, which can cause errors; positions where superko pruning occurred are solved again with the reverse move order, and those that disagree are removed (10 positions).
2. Dead-stone determination also uses the basic ko rule, without external ko threats; repetition in that search counts as the defender surviving.
3. Local CGT valuation still cannot handle ko (ko makes the game loopy, not finite); separators whose local search met ko or repetition are skipped: 598 ko, 60 repetition, 658 in all, leaving 308. This is the largest selection bias of the round: the cuts kept are those without local ko.
4. In scoring, frozen empty points outside the counted cells neither extend nor colour a territory; no first-round position had this situation, and 60 positions plus the regression test were recomputed with identical results.

## 4. Results

### 4.1 Exactness of cutting (M0, seam knot)

| Factor | By group |
|---|---|
| Interface width $w$ | 1: 48/109; 2: 39/172; 3: 8/27 |
| Position | centre 49/141; edge 28/101; corner 18/66 |
| Junction | none 92/287; present 3/21 |
| Stones on the interface | 0: 47/189; 1: 45/114; 2: 3/5 |
| Depth (distance from interface to nearest stone) | 1: 57/182; 2: 23/65; 3: 2/10; no stones 13/51 |
| Number of knots | 2: 90/263; 3: 5/45 |

Narrower interfaces are more often cut correctly; with a junction or three knots the cut is almost always wrong. Stones on the interface raise exactness (one stone 39%, none 25%), possibly because they fix part of the boundary. Depth groups are small and show no clear trend.

### 4.2 M1 screen

- 28/308 passed. In open areas a knot's value almost always changes with the interface state; this is itself a result: knots cut arbitrarily in open space are usually sensitive to their interface.
- Of the 28 passes, 8 had M0 wrong. In all 8, the knots really were unaffected by the interface, but the seam knot's value was wrong. For example, an interface point next to a single black stone counts as black territory when valued alone, although the empty points beside it may later be taken by White. The error lies in "the interface depends on both sides", not "the sides depend on the interface".
- This matches GPT's review concern: extracting the interface as a third independent knot is itself a strong assumption.

### 4.3 Two-way screen (post hoc)

On the 28 M1 passes, the test "the seam knot's value is unaffected by the empty points adjacent to it" was added:

| | Count | M0 wrong among them |
|---|---|---|
| Passed both ways | 20 | 0 |
| Removed by the two-way screen | 8 | 8 |

The two-way screen removes exactly the 8 errors and nothing else. Limits: only 20 cases; only three fills (all black, all white, as is); and it was designed after seeing the errors, so it must be retested on a new sample to count. No error of the "tempo fight on the interface" type appeared in this round, perhaps because such cases mostly trigger ko in the local search and were skipped.

### 4.4 Cost

Median search nodes: M0 36, M1 116, M2 6,552. Screening costs about three times cutting and adding, still far below merging; but it accepts only about 6% of cuts, and the rest must still be merged.

## 5. Interpretation

1. Virtual boundaries can work, but the conditions are strict: a narrow interface, no junction, and mutual insensitivity of both sides. In open areas of 7 to 10 points such cuts are rare.
2. Interface dependence runs both ways. Testing only "knot on interface" misses "interface on knot"; this supports treating the interface as an object that needs information from both sides, not as a third independent knot.
3. The two-way screen made no error in this sample and is a candidate rule for the next round, to be retested on a new, pre-registered sample.
4. The largest blind spot is ko: every cut with local ko was skipped, and tempo fights on the interface may well hide among them. Handling them requires local valuation of loopy games, beyond the current CGT tools.

## 6. Next steps

1. Retest the two-way screen on new random seeds with a pre-registered criterion: zero errors among passes.
2. Extend the two-way screen's fills (e.g., all combinations on each side) and observe the trade-off between coverage and error.
3. Classify the 75 cases where M1 failed but M0 happened to be exact, to see whether the screen is too strict.
4. Ko: study handling of local ko (e.g., thermography under a komaster assumption), or at least measure whether M0's error rate is higher among skipped cuts (possible with exhaustive search alone, without local values).

## Appendix: files

`gen4.py`, `t4.py`, `fullko.py`, `t4_seam.py`, `sum_t4.py`; results `results/t4_a.jsonl`, `results/t4_b.jsonl`, `results/t4_seam.json`, `results/t4_summary.txt`.
