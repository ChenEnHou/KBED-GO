import json, glob, random
from gen import make
from goeng import FullSolver, regions
from decomp import decompose
seeds = []
for f in glob.glob('results/t1_*.jsonl'):
    for l in open(f):
        r = json.loads(l)
        if r['status'] == 'ok' and not r['moveset_equal']:
            seeds.append(r['seed'])
seeds += [14258, 12061, 12126, 15227]
out = []
for s in seeds:
    bd, b, regs = make(random.Random(s), max_empty=12)
    fs = FullSolver(bd)
    c = fs.terminal(b)
    d = decompose(bd, b, regs)
    vb, ob = fs.root(b, 1); vw, ow = fs.root(b, 2)
    pb = fs.solve(b, 2, True)   # Black passed, White to move (may end game)
    pw = fs.solve(b, 1, True)
    rec = dict(seed=s, count_now=c, LS=str(d['ls']), RS=str(d['rs']), base_B=vb, base_W=vw,
               after_B_pass=pb, after_W_pass=pw,
               pass_in_base_B='pass' in ob, pass_in_dec_B='pass' in d['opt1'],
               pass_in_base_W='pass' in ow, pass_in_dec_W='pass' in d['opt2'],
               nonpass_equal=({m for m in ob if m != 'pass'} == {m for m in d['opt1'] if m != 'pass'} and
                              {m for m in ow if m != 'pass'} == {m for m in d['opt2'] if m != 'pass'}))
    out.append(rec); print(rec)
json.dump(out, open('results/pass_diag.json', 'w'), indent=1)
