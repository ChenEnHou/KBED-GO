import sys, json, os
from t4 import run_one
out, seedfile = sys.argv[1], sys.argv[2]
seeds = json.load(open(seedfile))
done = set()
if os.path.exists(out):
    done = {json.loads(l)['seed'] for l in open(out)}
with open(out, 'a') as f:
    for s in seeds:
        if s in done:
            continue
        f.write(json.dumps(run_one(s), ensure_ascii=False) + '\n')
        f.flush()
