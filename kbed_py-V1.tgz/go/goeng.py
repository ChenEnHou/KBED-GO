"""Small-board Go with uncapturable walls, territory scoring.

Cells: 0 empty, 1 black stone, 2 white stone, 3 black wall, 4 white wall.
Walls model groups proved unconditionally alive (Benson): any group that
contains a wall cell can never be captured.
Score is always from Black's point of view.
"""
import sys
sys.setrecursionlimit(100000)

EMPTY, B, W, BW, WW = 0, 1, 2, 3, 4
COLOR = {0: 0, 1: 1, 2: 2, 3: 1, 4: 2}


class Ko(Exception):
    pass


class Cycle(Exception):
    pass


class Board:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.nb = []
        for i in range(w * h):
            x, y = i % w, i // w
            n = []
            if x > 0: n.append(i - 1)
            if x < w - 1: n.append(i + 1)
            if y > 0: n.append(i - w)
            if y < h - 1: n.append(i + w)
            self.nb.append(tuple(n))

    def group(self, b, p):
        c = COLOR[b[p]]
        seen = {p}
        st = [p]
        libs = set()
        immortal = False
        while st:
            q = st.pop()
            if b[q] >= 3:
                # connected to an uncapturable wall: liberties are irrelevant
                return seen, libs, True
            for r in self.nb[q]:
                v = b[r]
                if v == 0:
                    libs.add(r)
                elif COLOR[v] == c and r not in seen:
                    seen.add(r)
                    st.append(r)
        return seen, libs, immortal

    def play(self, b, p, color):
        """Return (new_board, captured, ko_shape) or None if illegal."""
        if b[p] != 0:
            return None
        nb = list(b)
        nb[p] = color
        opp = 3 - color
        captured = 0
        capt_pts = []
        for r in self.nb[p]:
            if COLOR[nb[r]] == opp and nb[r] != 0:
                g, libs, imm = self.group(nb, r)
                if not libs and not imm:
                    for q in g:
                        nb[q] = 0
                    captured += len(g)
                    capt_pts.extend(g)
        g, libs, imm = self.group(nb, p)
        if not libs and not imm:
            return None  # suicide
        ko = (captured == 1 and len(g) == 1 and len(libs) == 1 and not imm)
        return tuple(nb), captured, ko

    def score(self, b):
        """Territory (empty points surrounded by one colour) only."""
        seen = set()
        s = 0
        for p in range(len(b)):
            if b[p] != 0 or p in seen:
                continue
            comp = {p}
            st = [p]
            cols = set()
            while st:
                q = st.pop()
                for r in self.nb[q]:
                    v = b[r]
                    if v == 0:
                        if r not in comp:
                            comp.add(r)
                            st.append(r)
                    else:
                        cols.add(COLOR[v])
            seen |= comp
            if cols == {1}:
                s += len(comp)
            elif cols == {2}:
                s -= len(comp)
        return s


class FullSolver:
    """Exhaustive minimax on the whole board. Game ends after two passes.
    Value = future prisoners + final territory, Black minus White."""

    def __init__(self, board):
        self.bd = board
        self.memo = {}
        self.path = set()
        self.nodes = 0

    def terminal(self, b):
        import japanese
        if not hasattr(self, 'regs'):
            self.regs = regions(self.bd, b)
        return sum(japanese.count(self.bd, b, r)[0] for r in self.regs)

    def solve(self, b, tm, passed):
        key = (b, tm, passed)
        v = self.memo.get(key)
        if v is not None:
            return v
        self.nodes += 1
        if b in self.path and not passed:
            raise Cycle()
        best = None
        # pass
        if passed:
            vp = self.terminal(b)
        else:
            vp = self.solve(b, 3 - tm, True)
        best = vp
        self.path.add(b)
        try:
            for p in range(len(b)):
                if b[p] != 0:
                    continue
                r = self.bd.play(b, p, tm)
                if r is None:
                    continue
                nb, cap, ko = r
                if ko:
                    raise Ko()
                if nb in self.path:
                    raise Cycle()
                v = (cap if tm == 1 else -cap) + self.solve(nb, 3 - tm, False)
                if tm == 1:
                    best = max(best, v)
                else:
                    best = min(best, v)
        finally:
            self.path.discard(b)
        self.memo[key] = best
        return best

    def root(self, b, tm):
        """Return (value, optimal move set) with tm to move, no previous pass.
        Moves are cell indices; 'pass' for pass."""
        val = self.solve(b, tm, False)
        opt = set()
        if self.solve(b, 3 - tm, True) == val:
            opt.add('pass')
        for p in range(len(b)):
            if b[p] != 0:
                continue
            r = self.bd.play(b, p, tm)
            if r is None:
                continue
            nb, cap, ko = r
            v = (cap if tm == 1 else -cap) + self.solve(nb, 3 - tm, False)
            if v == val:
                opt.add(p)
        return val, opt


def regions(board, b):
    """Connected components of non-wall cells."""
    seen = set()
    out = []
    for p in range(len(b)):
        if b[p] >= 3 or p in seen:
            continue
        comp = []
        st = [p]
        seen.add(p)
        while st:
            q = st.pop()
            comp.append(q)
            for r in board.nb[q]:
                if b[r] < 3 and r not in seen:
                    seen.add(r)
                    st.append(r)
        out.append(sorted(comp))
    return out


def render(board, b):
    ch = {0: '.', 1: 'x', 2: 'o', 3: 'X', 4: 'O'}
    rows = []
    for y in range(board.h):
        rows.append(''.join(ch[b[y * board.w + x]] for x in range(board.w)))
    return '\n'.join(rows)


def parse(text):
    rows = [r.strip() for r in text.strip().splitlines()]
    h, w = len(rows), len(rows[0])
    m = {'.': 0, 'x': 1, 'o': 2, 'X': 3, 'O': 4}
    b = tuple(m[c] for r in rows for c in r)
    return Board(w, h), b
