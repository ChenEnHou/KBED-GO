"""T1: correctness of summation. Resumable: appends one JSON line per seed.

usage: python3 t1.py OUT.jsonl SEED_START SEED_END [max_empty]
"""
import sys, json, os, time, random, signal
import cgt
from goeng import FullSolver, Ko, Cycle, render
from decomp import decompose
from gen import make


class Timeout(Exception):
    pass


def _alarm(*a):
    raise Timeout()


def run_one(seed, max_empty, limit):
    import japanese
    japanese._DEAD.clear()
    rng = random.Random(seed)
    r = make(rng, max_empty=max_empty)
    if r is None:
        return {'seed': seed, 'status': 'nogen'}
    bd, b, regs = r
    rec = {'seed': seed, 'board': render(bd, b), 'regions': regs,
           'n_regions': len(regs), 'n_empty': sum(1 for x in b if x == 0)}
    signal.signal(signal.SIGALRM, _alarm)
    signal.alarm(limit)
    try:
        t0 = time.time()
        d = decompose(bd, b, regs)
        t1 = time.time()
        fs = FullSolver(bd)
        vb, ob = fs.root(b, 1)
        vw, ow = fs.root(b, 2)
        t2 = time.time()
    except Ko:
        rec['status'] = 'ko'
        return rec
    except Cycle:
        rec['status'] = 'cycle'
        return rec
    except Timeout:
        rec['status'] = 'timeout'
        return rec
    finally:
        signal.alarm(0)
    rec['status'] = 'ok'
    rec['local_values'] = [cgt.show(v) for v in d['vals']]
    rec['sum'] = cgt.show(d['sum'])
    rec['decomp'] = {'B_first': str(d['ls']), 'W_first': str(d['rs']),
                     'opt_B': sorted(map(str, d['opt1'])), 'opt_W': sorted(map(str, d['opt2']))}
    rec['base'] = {'B_first': vb, 'W_first': vw,
                   'opt_B': sorted(map(str, ob)), 'opt_W': sorted(map(str, ow))}
    rec['score_ok'] = (d['ls'] == vb and d['rs'] == vw)

    def pick(s):
        mv = sorted(x for x in s if x != 'pass')
        return mv[0] if mv else 'pass'
    rec['move_ok_B'] = pick(d['opt1']) in ob
    rec['move_ok_W'] = pick(d['opt2']) in ow
    rec['moveset_equal'] = (d['opt1'] == ob and d['opt2'] == ow)
    # hottest-region heuristic
    temps = d['temps']
    hot = None
    if any(t is not None for t in temps):
        hi = max(i for i in range(len(temps)) if temps[i] is not None and temps[i] == max(t for t in temps if t is not None))
        hot = hi
    rec['temps'] = [None if t is None else str(t) for t in temps]
    if hot is not None:
        cells = set(regs[hot])
        rec['hot_has_opt_B'] = any(m in cells for m in ob if m != 'pass')
    rec['nodes_full'] = fs.nodes
    rec['nodes_local'] = d['local_nodes']
    rec['time_full'] = round(t2 - t1, 3)
    rec['time_local'] = round(t1 - t0, 3)
    return rec


def main():
    out, a, z = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    max_empty = int(sys.argv[4]) if len(sys.argv) > 4 else 12
    limit = int(sys.argv[5]) if len(sys.argv) > 5 else 900
    done = set()
    if os.path.exists(out):
        for line in open(out):
            try:
                done.add(json.loads(line)['seed'])
            except Exception:
                pass
    with open(out, 'a') as f:
        for seed in range(a, z):
            if seed in done:
                continue
            rec = run_one(seed, max_empty, limit)
            f.write(json.dumps(rec, ensure_ascii=False) + '\n')
            f.flush()
            if rec['status'] == 'ok' and not (rec['score_ok'] and rec['move_ok_B'] and rec['move_ok_W']):
                print('MISMATCH seed', seed, flush=True)
                open(out + '.STOP', 'w').write(str(seed))
                return


if __name__ == '__main__':
    main()
