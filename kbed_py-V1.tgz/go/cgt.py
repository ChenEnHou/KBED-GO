"""Minimal combinatorial game theory for short games.

Every game is a node id in a global table. A node is (L, R): frozensets of
node ids. canon(g) returns the id of the canonical form. Numbers carry an
exact Fraction value in NUM.
"""
from fractions import Fraction
import sys

sys.setrecursionlimit(100000)

NODES = []          # id -> (L, R)
INDEX = {}          # (L, R) -> id
CANON = {}          # id -> canonical id
NUM = {}            # canonical id -> Fraction (only for numbers)
LE = {}             # (a, b) -> bool
SUM = {}
NEG = {}


def node(L, R):
    key = (frozenset(L), frozenset(R))
    i = INDEX.get(key)
    if i is None:
        i = len(NODES)
        NODES.append(key)
        INDEX[key] = i
    return i


ZERO = node((), ())
CANON[ZERO] = ZERO
NUM[ZERO] = Fraction(0)


def le(a, b):
    """a <= b"""
    if a == b:
        return True
    k = (a, b)
    r = LE.get(k)
    if r is not None:
        return r
    na, nb = NUM.get(a), NUM.get(b)
    if na is not None and nb is not None:
        r = na <= nb
    else:
        La, Ra = NODES[a]
        Lb, Rb = NODES[b]
        r = not any(le(b, x) for x in La) and not any(le(x, a) for x in Rb)
    LE[k] = r
    return r


def eq(a, b):
    return le(a, b) and le(b, a)


def simplest_between(lo, hi):
    """Simplest dyadic number strictly between lo and hi (None = infinity)."""
    import math
    if lo is not None and hi is not None:
        assert lo < hi
    if (lo is None or lo < 0) and (hi is None or hi > 0):
        return Fraction(0)
    if lo is not None and lo >= 0:
        n = math.floor(lo) + 1
        if hi is None or n < hi:
            return Fraction(n)
    elif hi is not None and hi <= 0:
        n = math.ceil(hi) - 1
        if lo is None or n > lo:
            return Fraction(n)
    d = 1
    while True:
        d *= 2
        k = math.floor(lo * d) + 1
        if Fraction(k, d) < hi:
            return Fraction(k, d)


def number(x):
    x = Fraction(x)
    if x == 0:
        return ZERO
    if x.denominator == 1:
        if x > 0:
            g = canon(node((number(x - 1),), ()))
        else:
            g = canon(node((), (number(x + 1),)))
        return g
    d = x.denominator
    return canon(node((number(x - Fraction(1, d)),), (number(x + Fraction(1, d)),)))


def _number_value(L, R):
    """If {L|R} with canonical options is a number, return its value."""
    lv = [NUM.get(x) for x in L]
    rv = [NUM.get(x) for x in R]
    if any(v is None for v in lv) or any(v is None for v in rv):
        return None
    lo = max(lv) if lv else None
    hi = min(rv) if rv else None
    if lo is not None and hi is not None and lo >= hi:
        return None
    return simplest_between(lo, hi)


def canon(g):
    c = CANON.get(g)
    if c is not None:
        return c
    L, R = NODES[g]
    L = {canon(x) for x in L}
    R = {canon(x) for x in R}
    changed = True
    while changed:
        changed = False
        cur = node(L, R)
        # bypass reversible left options
        newL = set()
        for a in L:
            rev = None
            for ar in NODES[a][1]:
                if le(ar, cur):
                    rev = ar
                    break
            if rev is not None:
                newL |= {canon(x) for x in NODES[rev][0]}
                changed = True
            else:
                newL.add(a)
        newR = set()
        for b in R:
            rev = None
            for bl in NODES[b][0]:
                if le(cur, bl):
                    rev = bl
                    break
            if rev is not None:
                newR |= {canon(x) for x in NODES[rev][1]}
                changed = True
            else:
                newR.add(b)
        # remove dominated
        L2 = {a for a in newL if not any(b != a and le(a, b) for b in newL)}
        R2 = {a for a in newR if not any(b != a and le(b, a) for b in newR)}
        if L2 != L or R2 != R:
            changed = True
        L, R = L2, R2
    v = _number_value(L, R)
    if v is not None:
        c = _canon_number(v)
    else:
        c = node(L, R)
        CANON[c] = c
    CANON[g] = c
    return c


_NUMC = {}


def _canon_number(v):
    c = _NUMC.get(v)
    if c is not None:
        return c
    if v == 0:
        c = ZERO
    elif v.denominator == 1:
        if v > 0:
            c = node((_canon_number(v - 1),), ())
        else:
            c = node((), (_canon_number(v + 1),))
    else:
        d = v.denominator
        c = node((_canon_number(v - Fraction(1, d)),), (_canon_number(v + Fraction(1, d)),))
    CANON[c] = c
    NUM[c] = v
    _NUMC[v] = c
    return c


def add(a, b):
    a, b = canon(a), canon(b)
    if a > b:
        a, b = b, a
    k = (a, b)
    r = SUM.get(k)
    if r is not None:
        return r
    if a == ZERO:
        r = b
    elif a in NUM and b in NUM:
        r = _canon_number(NUM[a] + NUM[b])
    else:
        La, Ra = NODES[a]
        Lb, Rb = NODES[b]
        L = [add(x, b) for x in La] + [add(a, y) for y in Lb]
        R = [add(x, b) for x in Ra] + [add(a, y) for y in Rb]
        r = canon(node(L, R))
    SUM[k] = r
    return r


def neg(a):
    a = canon(a)
    r = NEG.get(a)
    if r is not None:
        return r
    if a in NUM:
        r = _canon_number(-NUM[a])
    else:
        L, R = NODES[a]
        r = canon(node([neg(y) for y in R], [neg(x) for x in L]))
    NEG[a] = r
    return r


def total(gs):
    s = ZERO
    for g in gs:
        s = add(s, g)
    return s


def is_number(a):
    return canon(a) in NUM


def left_stop(a):
    a = canon(a)
    if a in NUM:
        return NUM[a]
    L = NODES[a][0]
    if not L:
        raise ValueError('left stop undefined')
    return max(right_stop(x) for x in L)


def right_stop(a):
    a = canon(a)
    if a in NUM:
        return NUM[a]
    R = NODES[a][1]
    if not R:
        raise ValueError('right stop undefined')
    return min(left_stop(x) for x in R)


def show(a, depth=0):
    a = canon(a)
    if a in NUM:
        v = NUM[a]
        return str(v)
    if a == STAR:
        return '*'
    if a == UP:
        return '↑'
    if a == DOWN:
        return '↓'
    L, R = NODES[a]
    if depth > 6:
        return '{…}'
    ls = ','.join(sorted(show(x, depth + 1) for x in L))
    rs = ','.join(sorted(show(x, depth + 1) for x in R))
    return '{' + ls + '|' + rs + '}'


STAR = canon(node((ZERO,), (ZERO,)))
UP = canon(node((ZERO,), (STAR,)))
DOWN = neg(UP)


def temperature_bound(a):
    """Crude: (left_stop - right_stop)/2 as a temperature proxy."""
    a = canon(a)
    if a in NUM:
        return Fraction(-1)
    return (left_stop(a) - right_stop(a)) / 2


CHILL = {}
WARM = {}


def is_integer(a):
    a = canon(a)
    return a in NUM and NUM[a].denominator == 1


def chill(a):
    """Berlekamp-Wolfe chilling: G if G is an integer, else {G^L chilled - 1 | G^R chilled + 1}."""
    a = canon(a)
    r = CHILL.get(a)
    if r is not None:
        return r
    if is_integer(a):
        r = a
    else:
        L, R = NODES[a]
        r = canon(node([add(chill(x), number(-1)) for x in L],
                       [add(chill(x), number(1)) for x in R]))
    CHILL[a] = r
    return r


def warm(a):
    """Warming: G if G is an integer, else {G^L warmed + 1 | G^R warmed - 1}."""
    a = canon(a)
    r = WARM.get(a)
    if r is not None:
        return r
    if is_integer(a):
        r = a
    else:
        L, R = NODES[a]
        r = canon(node([add(warm(x), number(1)) for x in L],
                       [add(warm(x), number(-1)) for x in R]))
    WARM[a] = r
    return r


_SER = {}


def ser(a):
    """Full canonical serialization (no truncation), usable as an identifier."""
    a = canon(a)
    s = _SER.get(a)
    if s is not None:
        return s
    if a in NUM:
        s = str(NUM[a])
    else:
        L, R = NODES[a]
        s = '{' + ','.join(sorted(ser(x) for x in L)) + '|' + ','.join(sorted(ser(x) for x in R)) + '}'
    _SER[a] = s
    return s
