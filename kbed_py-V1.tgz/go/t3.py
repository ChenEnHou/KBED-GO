"""T3: detection of interaction through a capturable wall chain.

For each position, walk the optimal line (Black first) from the exhaustive
baseline. At every state while the chain is on the board:
  v_prem(K)  local value of region K with the chain treated as uncapturable
  v_real(S)  local value of the regions in S played together, chain real
             (capturable), other regions frozen (their empties still give liberties)
  violation(S) := v_real(S) != sum_{K in S} v_prem(K)
  minimal violating sets = violating S with no violating proper subset
Detectors:
  D1  premise check: can the chain be captured with the attacker moving
      first and play restricted to all regions touching it? If yes, flag the
      hyperedge T = all regions touching the chain.
  D2  colour difference: did v_prem of any region other than the one just
      played in change?
Also at the root: decomposition (stops of sum v_prem) vs exhaustive score.

usage: python3 t3.py OUT.jsonl SEED_START SEED_END
"""
import sys, json, os, random, signal, itertools
import cgt, japanese
from goeng import FullSolver, Ko, Cycle, render
from decomp import LocalSolver
from gen3 import make3


class Timeout(Exception):
    pass


def _alarm(*a):
    raise Timeout()


def prem_board(b, chain):
    """Chain stones replaced by uncapturable walls of the same colour."""
    nb = list(b)
    for q in chain:
        if nb[q] == 1:
            nb[q] = 3
        elif nb[q] == 2:
            nb[q] = 4
    return tuple(nb)


def chain_alive(b, chain):
    return all(b[q] in (1, 2) for q in chain)


def analyse_state(bd, b, regs, chain, touching):
    pb = prem_board(b, chain)
    vprem = [LocalSolver(bd, r).value(pb) for r in regs]
    n = len(regs)
    viol = {}
    for k in range(1, n + 1):
        for S in itertools.combinations(range(n), k):
            cells = sorted(set(c for i in S for c in regs[i]) | set(chain))
            vr = LocalSolver(bd, cells).value(b)
            viol[S] = (vr != cgt.total([vprem[i] for i in S]))
    minimal = [S for S, v in viol.items() if v and
               not any(viol[T] for k in range(1, len(S)) for T in itertools.combinations(S, k))]
    # D1: capture test on the chain, attacker first, play in all touching regions
    cells = sorted(set(c for i in touching for c in regs[i]) | set(chain))
    colour = b[chain[0]]
    capt = japanese._capture_game(bd, b, cells, frozenset(chain), 3 - colour, 3 - colour,
                                  False, {}, set())
    d1 = [tuple(touching)] if capt else []
    # D1b: threat-aware premise check. The chain needs no reinforcement iff,
    # after ANY single attacker move in the touching regions, the attacker
    # still cannot capture it when moving first again (i.e. the attacker gets
    # a free move). Catches sente threats against the wall.
    threat = capt
    if not threat:
        att = 3 - colour
        for p in cells:
            if b[p] != 0:
                continue
            rr = bd.play(b, p, att)
            if rr is None:
                continue
            nb, cap, ko = rr
            if ko:
                raise Ko()
            if not all(nb[q] == colour for q in chain):
                threat = True
                break
            if japanese._capture_game(bd, nb, cells, frozenset(chain), att, att, False, {}, set()):
                threat = True
                break
    d1b = [tuple(touching)] if threat else []
    # D1c: two free attacker moves, then attacker-first capture game.
    threat2 = threat
    if not threat2:
        att = 3 - colour
        empt = [p for p in cells if b[p] == 0]
        for p in empt:
            r1 = bd.play(b, p, att)
            if r1 is None:
                continue
            b1 = r1[0]
            if r1[2]:
                raise Ko()
            for q in empt:
                if q == p or b1[q] != 0:
                    continue
                r2 = bd.play(b1, q, att)
                if r2 is None:
                    continue
                b2 = r2[0]
                if r2[2]:
                    raise Ko()
                if not all(b2[c] == colour for c in chain) or \
                   japanese._capture_game(bd, b2, cells, frozenset(chain), att, att, False, {}, set()):
                    threat2 = True
                    break
            if threat2:
                break
    d1c = [tuple(touching)] if threat2 else []
    return vprem, viol, minimal, d1, d1b, d1c


def covered(S, edges):
    return any(set(S) <= set(e) for e in edges)


def run_one(seed, limit=600):
    japanese._DEAD.clear()
    rng = random.Random(seed)
    cfg = json.loads(os.environ.get('T3CFG', '{}'))
    cfg = {k: tuple(v) if isinstance(v, list) else v for k, v in cfg.items()}
    r = make3(rng, **cfg)
    if r is None:
        return {'seed': seed, 'status': 'nogen'}
    bd, b, regs, chain, touching = r
    rec = {'seed': seed, 'board': render(bd, b), 'regions': regs, 'chain': chain,
           'touching': touching, 'n_empty': sum(1 for x in b if x == 0)}
    signal.signal(signal.SIGALRM, _alarm)
    signal.alarm(limit)
    try:
        fs = FullSolver(bd)
        vb = fs.solve(b, 1, False)
        vw = fs.solve(b, 2, False)
        pb = prem_board(b, chain)
        vprem0 = [LocalSolver(bd, reg).value(pb) for reg in regs]
        S0 = cgt.total(vprem0)
        rec['root'] = {'full': [vb, vw], 'decomp_premise': [str(cgt.left_stop(S0)), str(cgt.right_stop(S0))]}
        rec['root']['decomp_ok'] = (cgt.left_stop(S0) == vb and cgt.right_stop(S0) == vw)
        # optimal line, Black first
        states = []
        cur, tm, passed = b, 1, False
        last_region = None
        prev_vprem = None
        for step in range(30):
            if not chain_alive(cur, chain):
                states.append({'step': step, 'chain_captured': True})
                break
            vprem, viol, minimal, d1, d1b, d1c = analyse_state(bd, cur, regs, chain, touching)
            d2 = False
            if prev_vprem is not None:
                d2 = any(vprem[i] != prev_vprem[i] for i in range(len(regs)) if i != last_region)
            states.append({'step': step, 'minimal': [list(S) for S in minimal],
                           'd1': [list(e) for e in d1], 'd1b': [list(e) for e in d1b], 'd1c': [list(e) for e in d1c], 'd2': d2,
                           'any_violation': any(viol.values())})
            prev_vprem = vprem
            # choose optimal move
            val = fs.solve(cur, tm, passed)
            best = None
            for p in range(len(cur)):
                if cur[p] != 0:
                    continue
                rr = bd.play(cur, p, tm)
                if rr is None:
                    continue
                nb, cap, ko = rr
                v = (cap if tm == 1 else -cap) + fs.solve(nb, 3 - tm, False)
                if v == val:
                    best = (p, nb)
                    break
            if best is None:
                if passed:
                    break
                passed = True
                tm = 3 - tm
                last_region = None
                continue
            p, cur = best
            last_region = next((i for i, rg in enumerate(regs) if p in rg), None)
            tm = 3 - tm
            passed = False
    except Ko:
        rec['status'] = 'ko'
        return rec
    except Cycle:
        rec['status'] = 'cycle'
        return rec
    except Timeout:
        rec['status'] = 'timeout'
        return rec
    finally:
        signal.alarm(0)
    rec['status'] = 'ok'
    rec['states'] = states
    return rec


def main():
    out, a, z = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    done = set()
    if os.path.exists(out):
        for line in open(out):
            done.add(json.loads(line)['seed'])
    with open(out, 'a') as f:
        for seed in range(a, z):
            if seed in done:
                continue
            rec = run_one(seed)
            f.write(json.dumps(rec, ensure_ascii=False) + '\n')
            f.flush()


if __name__ == '__main__':
    main()
