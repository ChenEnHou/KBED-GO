#!/bin/sh
cd /home/claude/work && tar czf /home/claude/work/kbed_go_snapshot.tgz go/*.py go/*.md go/*.sh go/results hier/*.md
echo /home/claude/work/kbed_go_snapshot.tgz
