"""v0.4: virtual separators. M0 (cut and add), M1 (insensitivity screening),
M2 (merged exhaustive solution, ground truth).

usage: python3 t4.py OUT.jsonl SEED_START SEED_END
"""
import sys, json, os, random, signal, itertools
import cgt, japanese
from goeng import FullSolver, Ko, Cycle, render
from decomp import LocalSolver
from gen4 import make4
from fullko import FullSolverKo


class Timeout(Exception):
    pass


def _alarm(*a):
    raise Timeout()


def legal_board(bd, b, area):
    for p in area:
        if b[p] in (1, 2):
            g, libs, imm = bd.group(b, p)
            if not libs and not imm:
                return False
    return True


def stops_of(vals):
    S = cgt.total(vals)
    return cgt.left_stop(S), cgt.right_stop(S)


def analyse_sep(bd, b, area, S, comps, touch, full):
    out = {'S': list(S), 'w': len(S), 'knot_sizes': [len(c) for c in comps],
           'n_knots': len(comps), 'junction': any(len(t) >= 3 for t in touch),
           'S_stones': sum(1 for s in S if b[s] in (1, 2))}
    stones = [p for p in area if b[p] in (1, 2) and p not in S]
    w_ = bd.w
    if stones:
        out['depth'] = min(abs(s % w_ - p % w_) + abs(s // w_ - p // w_) for s in S for p in stones)
    else:
        out['depth'] = None
    nodes = 0
    # M0 seam knot
    sols = [LocalSolver(bd, c) for c in comps] + [LocalSolver(bd, sorted(S))]
    vals = [s.value(b) for s in sols]
    nodes += sum(s.nodes for s in sols)
    ls, rs = stops_of(vals)
    out['M0_seam'] = [str(ls), str(rs)]
    out['M0_seam_ok'] = (ls, rs) == full
    out['M0_nodes'] = nodes
    # M0 assign S to one knot
    assign = []
    for i in range(len(comps)):
        parts = [sorted(set(comps[j]) | (set(S) if j == i else set())) for j in range(len(comps))]
        v = [LocalSolver(bd, p).value(b) for p in parts]
        a = stops_of(v)
        assign.append(a == full)
    out['M0_assign_ok'] = assign
    # M1 screening: each knot's value must be the same for every state of S
    insensitive = []
    m1nodes = 0
    for c in comps:
        seen = set()
        for st in itertools.product((0, 1, 2), repeat=len(S)):
            nb = list(b)
            for s, v in zip(S, st):
                nb[s] = v
            nb = tuple(nb)
            if not legal_board(bd, nb, area):
                continue
            ls_ = LocalSolver(bd, c)
            seen.add(cgt.ser(ls_.value(nb)))
            m1nodes += ls_.nodes
            if len(seen) > 1:
                break
        insensitive.append(len(seen) <= 1)
    out['M1_insensitive'] = insensitive
    out['M1_pass'] = all(insensitive)
    out['M1_nodes'] = m1nodes
    out['M1_false_pass'] = out['M1_pass'] and not out['M0_seam_ok']
    out['local_values'] = [cgt.ser(v) for v in vals]
    return out


def run_one(seed, limit=120, max_seps=4):
    japanese.KO_RULE = True
    japanese._DEAD.clear()
    rng = random.Random(seed)
    r = make4(rng)
    if r is None:
        return {'seed': seed, 'status': 'nogen'}
    bd, b, area, where, seps = r
    rec = {'seed': seed, 'board': render(bd, b), 'area': area, 'where': where,
           'n_area': len(area), 'n_stones': sum(1 for p in area if b[p] in (1, 2))}
    signal.signal(signal.SIGALRM, _alarm)
    signal.alarm(limit)
    try:
        fs0 = FullSolver(bd)
        fs = FullSolverKo(bd, fs0.terminal)
        vb = fs.solve(b, 1, False)
        vw = fs.solve(b, 2, False)
        rec['full'] = [vb, vw]
        if fs.repetitions:
            fr = FullSolverKo(bd, fs0.terminal, reverse=True)
            rec['ghi_check'] = [fr.solve(b, 1, False), fr.solve(b, 2, False)] == [vb, vw]
        rec['full_ko_seen'] = fs.ko_seen
        rec['full_repetitions'] = fs.repetitions
        rec['full_nodes'] = fs.nodes
        full = (vb, vw)
        pick = rng.sample(seps, min(max_seps, len(seps)))
        rec['seps'] = []
        for S, comps, touch in pick:
            try:
                rec['seps'].append(analyse_sep(bd, b, area, S, comps, touch, full))
            except (Ko, Cycle) as e:
                rec['seps'].append({'S': list(S), 'status': 'local_' + type(e).__name__})
    except Ko:
        rec['status'] = 'ko'
        return rec
    except Cycle:
        rec['status'] = 'cycle'
        return rec
    except Timeout:
        rec['status'] = 'timeout'
        return rec
    finally:
        signal.alarm(0)
    rec['status'] = 'ok'
    return rec


def main():
    out, a, z = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    done = set()
    if os.path.exists(out):
        for line in open(out):
            done.add(json.loads(line)['seed'])
    with open(out, 'a') as f:
        for seed in range(a, z):
            if seed in done:
                continue
            rec = run_one(seed)
            f.write(json.dumps(rec, ensure_ascii=False) + '\n')
            f.flush()


if __name__ == '__main__':
    main()
