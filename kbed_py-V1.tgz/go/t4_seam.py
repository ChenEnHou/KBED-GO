"""Post-hoc: add seam screening to M1. The seam knot's value must not change
when the knot cells adjacent to S are set all-black, all-white, or left as is."""
import json, glob, itertools
import cgt, japanese
from goeng import parse, Ko, Cycle
from decomp import LocalSolver
japanese.KO_RULE = True
rows = []
for f in sorted(glob.glob('results/t4_*.jsonl')):
    for l in open(f):
        r = json.loads(l)
        if r['status'] != 'ok' or r.get('ghi_check') is False:
            continue
        bd, b = parse(r['board'])
        area = set(r['area'])
        for s in r['seps']:
            if 'status' in s or not s['M1_pass']:
                continue
            S = s['S']
            adj = sorted({n for p in S for n in bd.nb[p] if n in area and n not in S and b[n] == 0})
            seen = set(); err = None
            for fill in (None, 1, 2):
                nb = list(b)
                if fill:
                    for n in adj:
                        nb[n] = fill
                nb = tuple(nb)
                try:
                    japanese._DEAD.clear()
                    seen.add(cgt.ser(LocalSolver(bd, sorted(S)).value(nb)))
                except (Ko, Cycle) as e:
                    err = type(e).__name__
            rows.append({'seed': r['seed'], 'S': S, 'M0_ok': s['M0_seam_ok'],
                         'seam_insensitive': len(seen) <= 1 and err is None, 'err': err})
print('M1 passed:', len(rows))
p = [x for x in rows if x['seam_insensitive']]
print('M1 + seam screening passed:', len(p), ' of which M0 wrong:', sum(not x['M0_ok'] for x in p))
print('removed by seam screening:', len(rows) - len(p), ' of which M0 wrong:', sum(not x['M0_ok'] for x in rows if not x['seam_insensitive']))
json.dump(rows, open('results/t4_seam.json', 'w'), indent=1)
