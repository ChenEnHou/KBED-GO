"""T2: substitution. Equal-value region pairs must give identical full-board
scores in every context; different-value pairs are a diagnostic.

usage: python3 t2.py OUT.jsonl [n_pairs] [contexts_per_pair] [max_empty]
"""
import sys, json, glob, random, os, signal, collections
import cgt
from goeng import parse, FullSolver, Ko, Cycle, render
from decomp import LocalSolver
from tiles import tile, swap, assemble, touches_edge


class Timeout(Exception):
    pass


def _alarm(*a):
    raise Timeout()


def tile_value(t):
    bd, b = assemble([t])
    regs = [r for r in __import__('goeng').regions(bd, b)]
    assert len(regs) == 1, regs
    return LocalSolver(bd, regs[0]).value(b), sum(1 for x in b if x == 0)


def key(t):
    return json.dumps(t)


def full_scores(tiles, limit):
    bd, b = assemble(tiles)
    signal.signal(signal.SIGALRM, _alarm)
    signal.alarm(limit)
    try:
        fs = FullSolver(bd)
        return (fs.solve(b, 1, False), fs.solve(b, 2, False)), render(bd, b)
    finally:
        signal.alarm(0)


def main():
    out = sys.argv[1]
    npairs = int(sys.argv[2]) if len(sys.argv) > 2 else 200
    nctx = int(sys.argv[3]) if len(sys.argv) > 3 else 4
    max_empty = int(sys.argv[4]) if len(sys.argv) > 4 else 12
    limit = 600
    rng = random.Random(7)
    # pool of tiles
    pool = {}
    for f in sorted(glob.glob('results/t1_*.jsonl')):
        for line in open(f):
            r = json.loads(line)
            if r['status'] != 'ok':
                continue
            bd, b = parse(r['board'])
            for reg in r['regions']:
                t = tile(bd, b, reg)
                if touches_edge(t):
                    continue
                k = key(t)
                if k in pool:
                    continue
                try:
                    v, ne = tile_value(t)
                except (Ko, Cycle):
                    continue
                orig = LocalSolver(bd, reg).value(b)
                assert orig == v, 'tile value differs from in-board value'
                pool[k] = (t, v, ne)
    tiles = list(pool.values())
    byval = collections.defaultdict(list)
    for t in tiles:
        byval[cgt.ser(t[1])].append(t)
    eq_pairs = []
    for s, ts in byval.items():
        for i in range(len(ts)):
            for j in range(i + 1, len(ts)):
                eq_pairs.append((ts[i], ts[j]))
    # different-value pairs with equal stops (close values) first, then random
    close, other = [], []
    for i in range(len(tiles)):
        for j in range(i + 1, len(tiles)):
            a, c = tiles[i], tiles[j]
            if a[1] == c[1]:
                continue
            try:
                same_stops = (cgt.left_stop(a[1]) == cgt.left_stop(c[1]) and
                              cgt.right_stop(a[1]) == cgt.right_stop(c[1]))
            except ValueError:
                same_stops = False
            (close if same_stops else other).append((a, c))
    rng.shuffle(eq_pairs)
    rng.shuffle(close)
    rng.shuffle(other)
    print('tiles', len(tiles), 'values', len(byval), 'equal pairs', len(eq_pairs),
          'close pairs', len(close), 'other pairs', len(other), flush=True)
    jobs = [('equal', p) for p in eq_pairs[:npairs]] + \
           [('close', p) for p in close[:npairs // 2]] + \
           [('other', p) for p in other[:npairs // 4]]
    done = set()
    if os.path.exists(out):
        for line in open(out):
            done.add(json.loads(line)['job'])
    with open(out, 'a') as f:
        for ji, (kind, (A, Bt)) in enumerate(jobs):
            if ji in done:
                continue
            rec = {'job': ji, 'kind': kind, 'A': cgt.ser(A[1]), 'B': cgt.ser(Bt[1]),
                   'A_tile': A[0], 'B_tile': Bt[0], 'contexts': []}
            ctxs = [('negB', [swap(Bt[0])], Bt[2])]
            tries = 0
            while len(ctxs) < nctx + 1 and tries < 200:
                tries += 1
                k = rng.randint(1, 2)
                xs = rng.sample(tiles, k)
                ne = sum(x[2] for x in xs)
                if ne + max(A[2], Bt[2]) > max_empty:
                    continue
                ctxs.append(('random', [x[0] for x in xs], ne))
            for cname, X, ne in ctxs:
                if ne + max(A[2], Bt[2]) > max_empty:
                    continue
                try:
                    sa, ba = full_scores([A[0]] + X, limit)
                    sb, bb = full_scores([Bt[0]] + X, limit)
                except (Ko, Cycle, Timeout) as e:
                    rec['contexts'].append({'ctx': cname, 'status': type(e).__name__})
                    continue
                rec['contexts'].append({'ctx': cname, 'status': 'ok',
                                        'score_A': list(sa), 'score_B': list(sb),
                                        'same': sa == sb})
            f.write(json.dumps(rec, ensure_ascii=False) + '\n')
            f.flush()
            if kind == 'equal' and any(c['status'] == 'ok' and not c['same'] for c in rec['contexts']):
                print('MISMATCH job', ji, flush=True)
                open(out + '.STOP', 'w').write(str(ji))
                return


if __name__ == '__main__':
    main()
