import cgt
from goeng import *
from decomp import *
# region: one empty point between black wall and white wall -> dame (*)
pos = """
XXXXX
X.XOO
XXX.O
OOOOO
"""
bd, b = parse(pos)
regs = regions(bd, b)
print(regs)
for r in regs:
    v = LocalSolver(bd, r).value(b)
    print(r, cgt.show(v))
fs = FullSolver(bd)
print('B first', fs.root(b,1), 'W first', fs.root(b,2))
d = decompose(bd, b, regs)
print('decomp', d['ls'], d['rs'], d['opt1'], d['opt2'])
# a 2-point corridor bounded by black and white: X..O
pos2 = """
XXXXXX
X..OOO
XXXOOO
"""
bd, b = parse(pos2)
regs = regions(bd, b)
for r in regs:
    print(r, cgt.show(LocalSolver(bd, r).value(b)))
fs = FullSolver(bd)
print(fs.root(b,1), fs.root(b,2))
