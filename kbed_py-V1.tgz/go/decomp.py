"""Local CGT values of regions and decomposition-based evaluation."""
import cgt
from goeng import Ko, Cycle
import japanese


class LocalSolver:
    def __init__(self, board, cells):
        self.bd = board
        self.cells = cells
        self.memo = {}
        self.path = set()
        self.nodes = 0

    def key(self, b):
        return tuple(b[c] for c in self.cells)

    def options(self, b, color):
        """Yield (cell, child_board, captured)."""
        for p in self.cells:
            if b[p] != 0:
                continue
            r = self.bd.play(b, p, color)
            if r is None:
                continue
            nb, cap, ko = r
            if ko:
                raise Ko()
            yield p, nb, cap

    def value(self, b):
        k = self.key(b)
        v = self.memo.get(k)
        if v is not None:
            return v
        if k in self.path:
            raise Cycle()
        self.nodes += 1
        sc, settled = japanese.count(self.bd, b, self.cells)
        if settled:
            v = cgt.number(sc)
            self.memo[k] = v
            return v
        self.path.add(k)
        try:
            L = [cgt.add(cgt.number(cap), self.value(nb)) for _, nb, cap in self.options(b, 1)]
            R = [cgt.add(cgt.number(-cap), self.value(nb)) for _, nb, cap in self.options(b, 2)]
        finally:
            self.path.discard(k)
        v = cgt.canon(cgt.node(L, R))
        self.memo[k] = v
        return v


def decompose(board, b, regs):
    """Return dict with local values, sum, stops, and decomposition optimal
    first moves for each side."""
    sols = [LocalSolver(board, r) for r in regs]
    vals = [s.value(b) for s in sols]
    S = cgt.total(vals)
    ls, rs = cgt.left_stop(S), cgt.right_stop(S)
    out = {'vals': vals, 'sum': S, 'ls': ls, 'rs': rs,
           'local_nodes': sum(s.nodes for s in sols)}
    for color, target in ((1, ls), (2, rs)):
        opt = set()
        hot = []  # (temperature proxy of region, cells)
        for i, s in enumerate(sols):
            rest = cgt.add(S, cgt.neg(vals[i]))
            for p, nb, cap in s.options(b, color):
                c = cgt.add(cgt.number(cap if color == 1 else -cap), s.value(nb))
                t = cgt.add(rest, c)
                st = cgt.right_stop(t) if color == 1 else cgt.left_stop(t)
                if st == target:
                    opt.add(p)
        # pass as a move: opponent then moves first in S
        st = rs if color == 1 else ls
        if st == target:
            opt.add('pass')
        out['opt%d' % color] = opt
    # hottest-region heuristic (recorded for comparison only)
    temps = []
    for i, v in enumerate(vals):
        try:
            t = cgt.temperature_bound(v)
        except ValueError:
            t = None
        temps.append(t)
    out['temps'] = temps
    return out
