import json, collections, glob
recs = {}
for f in ['results/t2.jsonl', 'results/t2_rev.jsonl']:
    try:
        for l in open(f):
            r = json.loads(l); recs[r['job']] = r
    except FileNotFoundError:
        pass
c = collections.Counter(); pairs = collections.Counter(); pair_any_diff = collections.Counter()
negb = collections.Counter()
for r in recs.values():
    oks = [x for x in r['contexts'] if x['status'] == 'ok']
    pairs[r['kind']] += 1
    if any(not x['same'] for x in oks): pair_any_diff[r['kind']] += 1
    for x in r['contexts']:
        c[(r['kind'], x['status'], x.get('same'))] += 1
        if x['ctx'] == 'negB' and x['status'] == 'ok':
            negb[(r['kind'], x['same'])] += 1
print('jobs done', len(recs), 'of 350')
print('pairs', dict(pairs), 'pairs with a score difference', dict(pair_any_diff))
for k, v in sorted(c.items(), key=str): print(k, v)
print('negB context', dict(negb))
print('STOP', glob.glob('results/t2*.STOP'))
