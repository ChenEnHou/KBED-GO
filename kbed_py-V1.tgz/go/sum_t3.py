import json, glob, collections
import sys
pat = sys.argv[1] if len(sys.argv) > 1 else 'results/t3v2_*.jsonl'
key = sys.argv[2] if len(sys.argv) > 2 else 'd1'
rs = [json.loads(l) for f in sorted(glob.glob(pat)) for l in open(f)]
st = collections.Counter(r['status'] for r in rs)
ok = [r for r in rs if r['status'] == 'ok']
print('records', len(rs), dict(st))
nstate = 0; miss = 0; fa = 0; viol_states = 0; d1_states = 0; d2 = 0
sizes = collections.Counter(); miss_examples = []
root_ok_noviol = [0, 0]; root_ok_viol = [0, 0]
early = []
for r in ok:
    first_d1 = first_v = None
    for s in r['states']:
        if s.get('chain_captured'):
            continue
        nstate += 1
        mins = [tuple(m) for m in s['minimal']]
        d1 = [tuple(e) for e in s[key]]
        if s['any_violation']: viol_states += 1
        if d1: d1_states += 1
        if s['d2']: d2 += 1
        for m in mins:
            sizes[len(m)] += 1
            if not any(set(m) <= set(e) for e in d1):
                miss += 1
                if len(miss_examples) < 5: miss_examples.append((r['seed'], s['step'], m))
        if d1 and not mins:
            fa += 1
        if first_d1 is None and d1: first_d1 = s['step']
        if first_v is None and mins: first_v = s['step']
    if first_v is not None and first_d1 is not None:
        early.append(first_v - first_d1)
    v0 = bool(r['states'] and r['states'][0].get('minimal'))
    tgt = root_ok_viol if v0 else root_ok_noviol
    tgt[0] += r['root']['decomp_ok']; tgt[1] += 1
print('positions', len(ok), 'states', nstate, 'states with violation', viol_states, 'states flagged by D1', d1_states)
print('minimal violating set sizes', dict(sizes))
print('D1 misses (minimal set not covered)', miss, 'D1 false alarms (flag, no violation)', fa)
print('D2 fired', d2)
print('first violation minus first D1 flag (moves):', collections.Counter(early))
print('root decomposition correct: no violation at root %d/%d; violation at root %d/%d' % (root_ok_noviol[0], root_ok_noviol[1], root_ok_viol[0], root_ok_viol[1]))
print('miss examples', miss_examples)
