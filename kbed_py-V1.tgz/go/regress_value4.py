import sys, signal, collections
sys.argv=['x']
exec(open('gpt_hard_h1_h2.py').read().split("vals=collections.defaultdict(list)")[0])
import cgt, collections
vals=collections.defaultdict(list)
for x in pool.values(): vals[cgt.ser(x[1])].append(x)
from tiles import assemble
from goeng import FullSolver
c=collections.Counter()
for z in vals['4']:
    bd,b=assemble([z[0]]); fs=FullSolver(bd); c[(fs.root(b,1)[0], fs.root(b,2)[0])]+=1
print('value-4 shapes, one process, fixed code:', dict(c))
