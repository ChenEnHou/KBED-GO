"""Japanese-style counting: dead stones are removed and counted as prisoners.

A non-wall group is dead if the opponent can capture it even when the
owner moves first, with play restricted to the group's region.
"""
from goeng import Ko, Cycle, COLOR

_DEAD = {}
# False (T1-T3 protocol): any ko shape raises Ko. True (v0.4): basic ko rule
# inside capture games (no immediate recapture, no external ko threats); the
# ko point is part of the state, so memoisation is exact; any cycle raises
# Cycle and the position is rejected (2026-10-08 fix: the earlier v0.4 run
# treated repetition as "defender survives", which is history-dependent).
KO_RULE = False


def _ctx(bd, b, cells):
    """Cache key for a region: board identity, cell contents and the colours
    of the surrounding walls (bug fix 2026-10-07: walls were missing from the
    key, so results leaked between positions with the same cells)."""
    cs = set(cells)
    bnd = sorted({r for c in cells for r in bd.nb[c] if r not in cs})
    return (bd.w, bd.h, tuple(cells), tuple(b[c] for c in cells), tuple(bnd), tuple(b[r] for r in bnd))


def _capture_game(bd, b, cells, target, attacker, to_move, passed, memo, path, kopt=None):
    """True if attacker captures any point of target. Defender survives on
    two passes. Cycle or ko -> exception."""
    key = (tuple(b[c] for c in cells), to_move, passed, kopt)
    v = memo.get(key)
    if v is not None:
        return v
    # captured?
    if any(b[p] == 0 for p in target):
        memo[key] = True
        return True
    # immortal?
    g, libs, imm = bd.group(b, next(iter(target)))
    if imm or not all(p in g for p in target):
        # if the target split, treat each part; simple rule: alive only if immortal
        if imm:
            memo[key] = False
            return False
    if key in path:
        # a cycle in the state graph: the game is not finite under these
        # rules; the position is rejected (both protocols)
        raise Cycle()
    path.add(key)
    try:
        res = []
        # pass
        if passed:
            res.append(False)
        else:
            res.append(_capture_game(bd, b, cells, target, attacker, 3 - to_move, True, memo, path))
        for p in cells:
            if b[p] != 0 or p == kopt:
                continue
            r = bd.play(b, p, to_move)
            if r is None:
                continue
            nb, cap, ko = r
            nk = None
            if ko:
                if not KO_RULE:
                    raise Ko()
                nk = next(q for q in bd.nb[p] if b[q] != 0 and nb[q] == 0)
            res.append(_capture_game(bd, nb, cells, target, attacker, 3 - to_move, False, memo, path, nk))
            if to_move == attacker and res[-1]:
                break
            if to_move != attacker and not res[-1]:
                break
    finally:
        path.discard(key)
    v = any(res) if to_move == attacker else all(res)
    memo[key] = v
    return v


def dead_groups(bd, b, cells):
    """List of (stones, color) of dead groups among non-wall stones in cells."""
    seen = set()
    out = []
    cellset = set(cells)
    for p in cells:
        if b[p] in (1, 2) and p not in seen:
            g, libs, imm = bd.group(b, p)
            seen |= g
            if imm:
                continue
            key = (_ctx(bd, b, cells), min(g))
            d = _DEAD.get(key)
            if d is None:
                color = b[p]
                d = _capture_game(bd, b, cells, frozenset(g), 3 - color, color, False, {}, set())
                _DEAD[key] = d
            if d:
                out.append((g, b[p]))
    return out


def count(bd, b, cells):
    """Japanese count over cells (Black minus White): territory after
    removing dead stones, plus those dead stones as prisoners.
    Returns (score, settled) where settled means no dame remain."""
    dg = dead_groups(bd, b, cells)
    cellset = set(cells)
    nb = list(b)
    s = 0
    for g, color in dg:
        for q in g:
            nb[q] = 0
        s += len(g) if color == 2 else -len(g)
    seen = set()
    settled = True
    for p in cells:
        if nb[p] != 0 or p in seen:
            continue
        comp = {p}
        st = [p]
        cols = set()
        while st:
            q = st.pop()
            for r in bd.nb[q]:
                v = nb[r]
                if v == 0:
                    # empty points outside the counted cells are frozen and
                    # ignored (they neither extend the component nor colour it)
                    if r in cellset and r not in comp:
                        comp.add(r)
                        st.append(r)
                else:
                    cols.add(COLOR[v])
        seen |= comp
        if cols == {1}:
            s += len(comp)
        elif cols == {2}:
            s -= len(comp)
        else:
            settled = False
    # unsettled also if a live non-wall group could be captured with the
    # attacker moving first (an open fight)
    if settled:
        deadpts = set(q for g, _ in dg for q in g)
        seen = set()
        for p in cells:
            if b[p] in (1, 2) and p not in seen and p not in deadpts:
                g, libs, imm = bd.group(b, p)
                seen |= g
                if imm:
                    continue
                color = b[p]
                key = (_ctx(bd, b, cells), min(g), 'att')
                d = _DEAD.get(key)
                if d is None:
                    d = _capture_game(bd, b, cells, frozenset(g), 3 - color, 3 - color, False, {}, set())
                    _DEAD[key] = d
                if d:
                    settled = False
                    break
    return s, settled
