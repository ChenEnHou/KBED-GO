from cgt import *
from fractions import Fraction as F
assert show(STAR)=='*'
assert NUM[canon(node((ZERO,),()))]==1
half=canon(node((ZERO,),(number(1),)))
assert NUM[half]==F(1,2)
assert add(half,half)==number(1)
assert add(STAR,STAR)==ZERO
assert add(UP,DOWN)==ZERO
assert not le(UP,ZERO) and le(ZERO,UP) and UP!=ZERO
# switch {1|0}
sw=canon(node((number(1),),(ZERO,)))
assert left_stop(sw)==1 and right_stop(sw)==0
assert add(sw,neg(sw))==ZERO
# {1|-1} + {1|-1} = 0
pm=canon(node((number(1),),(number(-1),)))
assert add(pm,pm)==ZERO
# * vs 0 indistinguishable by stops
assert left_stop(STAR)==0==right_stop(STAR)
# up+* is fuzzy with 0? up* || 0
us=add(UP,STAR)
assert not le(us,ZERO) and not le(ZERO,us)
# reversible: {0|{2|0}} ... sanity: {1|}+{|−1} = 0
assert add(number(3),number(-3))==ZERO
assert NUM[add(number(F(3,4)),number(F(1,4)))]==1
# canonical numbers via game form {0|1}? = 1/2 ; {1/2|1}=3/4
assert NUM[canon(node((half,),(number(1),)))]==F(3,4)
# {0|*} = up ; {*|0}=down; {0,*|0}=up*? check: {0,*|0} = ↑* (canonical {0,*|0})
print('ok', show(UP), show(add(UP,STAR)), show(add(sw,STAR)))
