# KBED Hierarchical Exact Computation: First-Round Validation Results (T1, T2, T3)

Oct 7, 2026 · Chen-En Hou

Basis: *KBED Hierarchical Exact Computation: Theory and Validation Design v0.3*. This report records the first-round implementation, the errors found along the way, and the results of T1, T2 and T3. T4 and T5 have not been run formally.

## 1. Summary

| Experiment | Criterion | Result |
|---|---|---|
| T1 Summation | Score with Black first and White first matches exhaustive search | 316/316 |
| T1 | First move chosen by decomposition is in the optimal set (Black, White) | 316/316, 316/316 |
| T1 cross-check | Score via chill → sum → warm | 316/316 |
| T2 Substitution | Swapping equal-value regions leaves the score unchanged in every context | 200 pairs, 1000 contexts, all unchanged |
| T3 Interaction detection | Premise check has no misses | Not met: capture-only check misses 147; stronger checks reduce misses to 1 but false alarms rise sharply |
| T3 | Decomposition correct when premises hold | 862/862 (three-region wall positions), 10/10 (general positions) |

In this setting (territory scoring, no ko, uncapturable walls, at most 12 empty points), no counterexample was found. This shows the implementation reproduces Berlekamp and Wolfe's results on independent endgames, i.e., the instrument is calibrated; it says nothing about whether the hierarchy works with ko, seki, unsafe walls or in the middle game.

## 2. Implementation and modelling choices

- CGT: canonical forms, sums, negation, comparison, stops, chilling and warming implemented from scratch; unit-tested on known values ($*+*=0$, $\uparrow+\downarrow=0$, $\{1|-1\}+\{1|-1\}=0$, etc.).
- Walls: modelled as stones that can never be captured, equivalent to walls proved unconditionally alive by Benson's method whose eyes are single points. The eyes add only a constant.
- End of game: two consecutive passes. Scoring is Japanese territory counting: captured stones and dead stones count as prisoners; a group is dead if it is captured even when its owner moves first, with play restricted to its region.
- Local valuation: expansion stops when a region is settled; its value is then the Japanese count. Settled means no dame remain and every non-wall live group in the region survives even with the opponent moving first.
- Ko: any ko shape (a single stone capturing a single stone and left with one liberty) anywhere in either search removes the position; so does any cycle.
- Positions: 9×9 board, walls separating 2 to 5 regions of 2 to 6 points, a few random stones inside, at most 12 empty points; 900 s limit per position.

## 3. Findings and errors along the way

This section records what went wrong and how it was fixed; the original erroneous results are kept, not deleted.

**3.1 End-of-game counting (a design finding).** The first version counted territory directly after two passes without removing dead stones. T1 failed at once (e.g., exhaustive −5, decomposition −7). Without dead-stone removal, an invasion forces the defender to fill its own territory to capture, so invading pays; CGT values do not describe that game. Switching to Japanese counting (dead stones removed as prisoners) restored agreement. This is the convention Müller uses for decomposition search: terminal positions are those with no good move, and territory may contain prisoners. It partly answers Section 6 of the design: whether the Berlekamp–Wolfe correspondence holds depends on how dead stones are handled.

**3.2 Cache error (an implementation error).** The cache for dead-stone status was keyed on a region's cells and their contents, not on the colours of the surrounding walls, and was shared across positions within one run. Two regions with the same cells and contents but different wall colours received the same status. It was detected because two stored records showed a non-pass difference in the optimal move set that disappeared on re-computation. The fix adds the wall colours to the key and clears the cache for each position. All T1 results from before the fix were set aside and T1 was rerun from scratch.

**3.3 GPT's H2 counterexample (caused by the same error).** Running H2 on the pre-fix code, GPT reported a region valued 4 by decomposition but 3 by isolated exhaustive search, and concluded that the settled test is incomplete. On checking:

- With the fixed code, isolated exhaustive search gives 4 and the local value is 4;
- With the pre-fix code in a fresh run, isolated computation also gives 4;
- The 3 arose because GPT's probe computed 19 regions in sequence in one run. Cut-out regions are re-aligned to the same coordinates, so identical cells are common, triggering the error in 3.2. This also explains why substitution tests hit the error far more readily than random positions.

Rerunning GPT's H1/H2 script on the fixed code: H1 15/15 (score, first move with Black and with White first); H2 $*$ versus $0$ gives the same score in all 22 contexts, with decomposition exact 22/22. All 20 regions with value 4, computed in sequence in one run, give (4, 4); this is now a permanent regression test.

GPT's general point stands: the settled test has no proof, only test support (Section 6).

**3.4 Speed-up.** Determining a group used to flood along the whole connected wall; it now stops at the first wall cell, since such a group cannot be captured. About three to four times faster; 12 stored positions were recomputed with identical results. Times before and after are not comparable; node counts are unaffected.

**3.5 Environment.** The workspace is suspended and restarted when the conversation is idle, killing background processes; computation advances only while a session is active. All runs resume from checkpoints.

## 4. T1 results

1885 random seeds: 316 valid, 688 removed for ko, 22 for cycles, 859 where the generator produced no valid position, 0 timeouts.

| Item | Result |
|---|---|
| Score agreement (Black first, White first) | 316/316 |
| Decomposition's first move in the optimal set | Black 316/316, White 316/316 |
| Optimal move sets identical | 315/316 |
| Score via chilled sum, then warmed | 316/316 |
| Chilling linear over sums ($\sum$ chill = chill $\sum$) | 316/316 |
| Warming restores chilling ($\int$ chill $S=S$) | 184/316 |
| Hottest region contains an optimal Black move | 154/316 |

Distribution: 2–12 empty points (28 positions with 11, 19 with 12); 2 regions: 175, 3: 98, 4: 35, 5: 8.

**Pass differences.** The only move-set difference (and the 4 in GPT's data) concern passing alone; the optimal stone moves agree exactly. In the real game, after one side passes the other can pass and end the game at the current count; CGT stops have no "end now" option. When the current count differs from the stops (e.g., current 6, stops 7), the two disagree about whether passing is optimal. This is a difference in how the rules are represented, not a summation error. For decomposition to judge passing correctly, the current count must be compared as well.

**Warming not restoring (132/316)** is expected: chilling erases infinitesimals such as $*$ (a dame), and warming does not bring them back; under territory scoring dame are worth zero, so the score is unaffected.

**Choosing by temperature alone.** The hottest region contains an optimal move in only about half the positions; by number of regions: 2: 74/175, 3: 49/98, 4: 25/35, 5: 6/8. Even in endgames this small, temperature alone is unreliable; the move must come from exact summation of values (as T1 in the design requires). Temperature is approximated by half the difference of the stops, not a full thermograph, so this is indicative only.

**Cost (diagnostic, not a formal T4).** Median search nodes: exhaustive 6,885, decomposition 9; for the 47 positions with 11 or more empty points: exhaustive 483,324, decomposition 19. Maxima: exhaustive 8,014,100, decomposition 561. Removals and timeouts bias the sample; a formal comparison is left to T4.

## 5. T2 results

254 regions not touching the board edge were cut from T1's valid positions, with 50 distinct values. Each pair is compared by placing both regions in the same context and solving exhaustively with Black first and with White first. Contexts: the constructed distinguishing context $-B$ ($B$ with colours swapped) and 4 random contexts. 350 pairs, 1750 contexts, no timeouts or removals.

| Category | Pairs | Contexts | Result |
|---|---|---|---|
| Equal value (criterion) | 200 | 1000 | Score unchanged everywhere |
| Different value, different stops (control) | 50 | 250 | 50/50 pairs differ; $-B$ 50/50 |
| Different value, same stops (diagnostic) | 100 | 500 | 6/100 pairs differ, all only in $-B$ |

**Criterion: passed.** Equal values are interchangeable; no counterexample in this setting.

**Regions with equal stops but different values.** This partly answers question 3 in Section 6 of the design:

1. Equal stops (or equal temperature and mean) do not imply score equivalence. Six pairs give different scores in context $-B$; e.g., $\{1|*\}$ and another value with the same stops give (1, −1) and (0, 0). Using values as identifiers is therefore necessary; merging by stops or temperature would treat non-interchangeable regions as interchangeable.
2. All six differences appear only in the constructed $-B$ context; random contexts never caught them. Constructed contexts are far more effective than random sampling.
3. The other 94 pairs give the same score in every tested context, mostly $*$ versus $0$ (75), $n$ versus $n*$ (6), $\{*|-1\}$ versus $\{0|-1*\}$ (7). The value is finer than the "score" query needs; for a score-only query, these could be merged further. This means only that the tested contexts do not distinguish them; it is not a proof.

## 6. T3 results

**Setting.** A capturable wall is introduced: a chain of ordinary stones touching 1 to 3 regions, otherwise surrounded by uncapturable walls of the opposite colour. Two sets: general positions (wall touching 1–3 regions plus 0–2 independent regions; 31 valid) and constructed three-region positions H5 (wall touching 3 regions of 1–3 points each; 1250 valid). Along the exhaustive optimal line (Black first), every state before the wall is captured is checked: 183 and 7870 states.

**Ground truth.** $v_{\text{prem}}(K)$: value of region $K$ with the wall treated as uncapturable; $v_{\text{real}}(S)$: value of the regions in $S$ merged with the wall, the wall capturable, other regions frozen. $S$ violates the premise if $v_{\text{real}}(S)\neq\sum_{K\in S}v_{\text{prem}}(K)$; minimal violating sets contain no smaller violating set. A single region means that region alone breaks the premise; two or three regions mean cross-region interaction.

**Sizes of minimal violating sets.** H5: one region 433, two 580, three 415; general: one 52, two 12. Interactions appearing only among three regions are common, confirming that pairwise checks are insufficient (design v0.3, Section 6, question 3).

**Detectors.** All use the set of regions touching the wall as the unit; a flag is a hyperedge.

- D1: can the attacker capture the wall, moving first, with alternating play in these regions?
- D1b: the attacker gets one free move, then D1;
- D1c: the attacker gets two free moves, then D1;
- D2: colour difference, i.e., whether $v_{\text{prem}}$ of a region not played in changed.

| Detector | H5 misses | H5 false alarms | General misses | General false alarms |
|---|---|---|---|---|
| D1 | 147 | 0 | 2 | 0 |
| D1b | 11 | 1074 | 0 | 19 |
| D1c | 1 | 1735 | — | — |
| D2 | never fired | — | never fired | — |

Miss: a minimal violating set not inside any flagged hyperedge; false alarm: a flag with no violation. The general run started before D1c was added, so it has no D1c data.

**Interpretation.**

1. Colour difference (D2) never fired, as v0.2 argued: a region's value depends only on its own position; interaction changes premises, not values.
2. D1 asks only "can the wall be captured"; it has no false alarms but misses sente threats: the wall cannot die, yet when put in atari it must be reinforced, giving the attacker a tempo. This is exactly the "sente threats against the wall" item in the v0.3 premises.
3. Giving the attacker free moves reduces misses and gives earlier warning (D1c up to 6 moves ahead), but false alarms grow quickly. The one D1c miss: a wall with 4 liberties spread over three regions, still not capturable after two free moves. A premise check based on a bounded number of free moves cannot be both miss-free and low in false alarms.
4. Every violating set lies within the regions touching the same wall, i.e., the v0.3 hyperedge; no interaction travelling other than through a shared object was seen (a preliminary answer, in this setting, to question 2 of v0.3 Section 6).
5. When premises hold, decomposition is correct at the root in every case: H5 862/862, general 10/10; when they are broken it is right only by chance, 73/388 and 1/21. Whether to merge and recompute must be decided by the premise check.

**Practical compromise.** Flag suspect hyperedges with a loose detector (D1b or D1c), then confirm by exact merged valuation of the flagged hyperedge. At this scale merged valuation is cheap; whether it stays cheap in large positions is a T4 question.

## 7. Interpretation and limits

1. Passing T1 and T2 is instrument calibration; those conclusions apply only to random endgames with territory scoring, no ko, uncapturable walls and at most 12 empty points. T3 has only one capturable wall; the general set has only 31 positions, so T3 conclusions rest mainly on the constructed H5 positions.
2. Excluding ko biases toward simple positions; valid positions are about a third of those produced.
3. The settled test (no dame, and live groups survive even with the opponent moving first) has test support but no proof. The intuitive reason it holds is that, under Japanese counting, an invasion answered by the defender is usually a zero-sum exchange; whether this holds in all cases is an open question.
4. Passing: decomposition does not yet handle "end now" (Section 4).
5. GPT's rerun used the same code, not an independent implementation; an error in the code appears in both (3.2 is exactly such a case).

## 8. Next steps

1. Premise check: look for a provably miss-free condition between D1 and D1c, or adopt "loose detection + merged confirmation" as the standard procedure.
2. Passing: add comparison with the current count in decomposition and recheck optimal move sets.
3. T4: cost measured under controlled conditions (same machine, no competing processes, nodes and time recorded).
4. Second round: ko (komaster assumption), area scoring, seki.

## Appendix: files

- Code: `cgt.py`, `goeng.py`, `japanese.py`, `decomp.py`, `gen.py`, `gen3.py`, `tiles.py`, `t1.py`, `t1b.py`, `t2.py`, `t3.py`, `passdiag.py`, `regress_value4.py`
- Results: `results/t1_a.jsonl`, `results/t1_b.jsonl`, `results/t1_routeb.json`, `results/pass_diag.json`, `results/t2_merged.json`, `results/gpt_h1_h2_rerun_fixed.json`, `results/t3v2_a.jsonl`, `results/t3v3_h5.jsonl`
- Erroneous pre-fix results: `results/buggy_cache/`
- Progress log: `PROGRESS.md`

## References

- Berlekamp, E. R., & Wolfe, D. Mathematical Go: Chilling Gets the Last Point. A K Peters, 1994.
- Müller, M. Chapter on Go endgames in Games of No Chance, MSRI Publications 29, 1996.
- Müller, M. Decomposition Search: A Combinatorial Games Approach to Game Tree Search, with Applications to Solving Go Endgames. IJCAI 1999.
- Mathematical Go: Revisited. arXiv:1202.4657.
