"""Exhaustive solver with the basic ko rule (no immediate recapture).

State = (board, side to move, previous move was pass, ko-banned point).
A move that repeats an earlier (board, side to move) on the current line ends
the game at once with the Japanese count of the repeated board (a v0.4
convention for repetition). Values whose subtree met such a repetition depend
on the line and are not stored in the transposition table, so the table stays
exact for the remaining states."""


class FullSolverKo:
    def __init__(self, board, terminal, reverse=False):
        self.reverse = reverse
        self.bd = board
        self.terminal = terminal
        self.memo = {}
        self.path = set()
        self.nodes = 0
        self.ko_seen = False
        self.repetitions = 0

    def solve(self, b, tm, passed, kopt=None):
        return self._solve(b, tm, passed, kopt)[0]

    def _solve(self, b, tm, passed, kopt):
        key = (b, tm, passed, kopt)
        v = self.memo.get(key)
        if v is not None:
            return v, False
        self.nodes += 1
        if (b, tm) in self.path:
            # should not happen: repeating moves are pruned below
            self.repetitions += 1
            return self.terminal(b), True
        dep = False
        if passed:
            best = self.terminal(b)
        else:
            best, d = self._solve(b, 3 - tm, True, None)
            dep = dep or d
        self.path.add((b, tm))
        try:
            order = range(len(b) - 1, -1, -1) if self.reverse else range(len(b))
            for p in order:
                if b[p] != 0 or p == kopt:
                    continue
                r = self.bd.play(b, p, tm)
                if r is None:
                    continue
                nb, cap, ko = r
                if (nb, 3 - tm) in self.path:
                    # positional superko: a move may not repeat a position on
                    # the current line. The transposition table ignores this
                    # path dependence (graph-history interaction); results are
                    # cross-checked by solving with the reverse move order.
                    self.repetitions += 1
                    continue
                nk = None
                if ko:
                    self.ko_seen = True
                    nk = next(q for q in self.bd.nb[p] if b[q] != 0 and nb[q] == 0)
                v, d = self._solve(nb, 3 - tm, False, nk)
                dep = dep or d
                v += (cap if tm == 1 else -cap)
                best = max(best, v) if tm == 1 else min(best, v)
        finally:
            self.path.discard((b, tm))
        self.memo[key] = best
        return best, dep
