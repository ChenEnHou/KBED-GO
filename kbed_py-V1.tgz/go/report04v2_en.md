# KBED Virtual Boundary Validation: v0.4 Formal Report

Oct 8, 2026 · Chen-En Hou

This report replaces the earlier *KBED_Virtual_Boundary_Results_v0.4*, whose exhaustive solver was defective (Section 3); those results are void.

## 1. Summary

Research question: when an open area is cut along a virtual boundary and the parts are valued separately and added (M0), when is the result exact, and can such cases be screened in advance without solving the merged area?

| Item | Result |
|---|---|
| M0 cut-and-add exact (rounds 2–5 pooled) | 1112/3214 (35%) |
| Pre-registered screens (4 rounds) | first three failed; the fourth (round 5) passed |
| Final screen M1v | accepts 71 of 994 cuts (7%), 0 errors |
| M1v coverage of exact cuts | accepts only 71 of the 337 exact cuts (21%) |

On a new sample, M1v made no false acceptance, but it is conservative and accepts few cuts. The sample also contained no instance of the previously known failure types, so this zero has limited power (Section 7).

Failure types became more specific round by round, and all three known types correspond to v0.3 premise items; this shows neither that the premise list is complete nor that the method has converged.

## 2. Setting

- 7×7 board; an open area of 7 to 10 points enclosed by uncapturable walls, in the centre, on an edge or in a corner; 0 to 3 stones in the area.
- Separator $S$ (1 to 3 points) splitting the area into 2 or more knots of at least 2 points, every separator point touching at least two knots; up to 4 separators per area.
- **M2 (ground truth)**: exhaustive search of the whole area, score with Black first and with White first.
- **M0**: local values of each knot and of the seam knot ($S$ itself), others frozen; summed, score read from the stops.
- Screens added round by round (Section 5):
    - M1: knots insensitive to fixed interface states;
    - M1b: plus interface insensitive to both sides (static fills);
    - M1t: knots insensitive to states reachable by actual play on the interface;
    - M1v: M1, M1t and M1b, plus an interface-side screen by actual play and a structural check on whole groups.

## 3. Rules and solvers (from round 2)

1. **Exhaustive search (`fullexact.py`)**:
    - The state is board, side to move, whether the last move was a pass, and the ko-banned point; basic ko rule only. With this state, table lookups do not depend on move history.
    - A cycle in the state graph (triple ko, eternal life, etc.) rejects the position.
    - Regression: on 280 tiny positions (81 with ko) it agrees exactly with plain minimax without a table.
2. **Dead-stone determination**: also basic ko rule; any cycle rejects the position.
3. **Local values**: CGT cannot handle ko; separators whose local search meets ko or a cycle are skipped.
4. **Defect in version 1 (void)**:
    - The old solver `fullko.py` forbade repeating (board, side to move) but stored history-dependent values in the table, while its docstring said the opposite;
    - dead-stone determination treated repetition as the defender surviving, also history-dependent.
    - Both were pointed out in GPT's code review and confirmed.

## 4. Rounds

| Round | Sample | Cuts | M0 exact | Pre-registered screen | Passed | Errors | Criterion |
|---|---|---|---|---|---|---|---|
| 1 | version-1 seeds, new solver | 156 | 67 | (M1b, post hoc) | 19 | 0 | — |
| 2 | new seeds from 500000 | 649 | 237 | M1b | 54 | 1 | failed |
| 3 | new seeds from 700000 | 752 | 254 | M1tb (M1t plus static interface side) | 166 | 24 | failed |
| 4 | new seeds from 800000 | 819 | 284 | M1u (M1, M1t, M1b) | 72 | 1 | failed |
| 5 | new seeds from 900000 | 994 | 337 | M1v | 71 | 0 | **passed** |

Rounds 2–5 pooled: 2312 valid positions, 6342 rejected for cycles; 3214 cuts analysed, 2072 skipped for local ko or cycles.

## 5. Failure types and the checks that address them

| Type | First seen | Content | v0.3 premise | Check that removes it |
|---|---|---|---|---|
| A Interface depends on both sides | version 1 | an interface point valued alone counts as one colour's territory if only that colour is adjacent, though it depends on later play on both sides | interface dependence | interface-side screen (M1b) |
| B Capture on the interface | round 2 (seed 500781) | a stone on one side has its last liberty on the interface; the fixed-state screen skipped "interface set to the opponent's stone" as illegal, though that is a capturing move | transitions, sente threats | actual play on the interface (M1t), or the structural check |
| C Shared liberties | round 4 (seed 850002) | a stone on the interface with its two liberties in different knots; capturing it needs a move on each side; neither side alone can capture it | shared liberties (T3's shared object) | structural check; interface-side screen by actual play |
| Design error | round 3 | M1t sees only reachable states; with a stone already on the interface it sees only the current state and is weaker than M1 (all 115 such cases) | — | combine with M1 |

Types B and C both surfaced through the same implementation weakness: skipping a static fill that leaves stones without liberties as "illegal". Round 5 uses actual play instead (legality, merging, liberties and captures handled by the move routine).

**Effect of each check in round 5:**

| Screen combination | Passed | Errors |
|---|---|---|
| M1 | 164 | 68 |
| M1b | 89 | 0 |
| M1u (M1b plus M1t) | 89 | 0 |
| M1u plus interface-side screen by play | 80 | 0 |
| M1u plus structural check | 71 | 0 |
| M1v (all) | 71 | 0 |

- The structural check fails 254/994; the interface-side screen by play fails 640/994.
- Both earlier known counterexamples are rejected by M1v (checked before the run).
- All 76 false acceptances across rounds are stored in `results/t4_counterexamples.json`.

## 6. Exactness of cutting (M0, rounds 2–5 pooled, 3214 cuts)

| Factor | By group |
|---|---|
| Interface width | 1: 42%; 2: 29%; 3: 23% |
| Position | centre 33%; edge 36%; corner 40% |
| Junction | none 35%; present 27% |
| Stones on the interface | 0: 27%; 1: 47%; 2: 68% |
| Depth (distance from interface to nearest stone) | 1: 38%; 2: 33%; 3: 31%; 4 or more: 25% (16 cases); no stones in the area: 25% |
| Number of knots | 2: 36%; 3 or more: 26% |
| Interface assigned to one knot | at least one assignment exact 75%; every assignment exact 38% |

- Narrower interfaces, fewer knots and no junction make cutting more often exact.
- Stones on the interface raise exactness markedly, perhaps because they fix part of the boundary.
- Assigning the interface to one side is often better than a seam knot, but which side is not known in advance.

## 7. Statistical limits

1. **Low power.** Round 5 had 71 passes and 0 errors; the one-sided 95% upper bound on the error rate is about 4%. The earlier M1b error rate was about 2/283 (0.7%); a sample of 71 is unlikely to detect errors at that frequency. Moreover, in round 5 even M1b alone made no error. This zero mainly shows that M1v introduced no new error, not that it covers all types.
2. **Selection bias.**
    - About two thirds of positions were rejected for cycles;
    - every cut with ko (2056) was skipped, and tempo fights and ko threats may well lie among them.
3. **Scale.** Areas of only 7 to 10 points.
4. **Post-hoc design.** Each M1v check was added after seeing errors; only round 5's sample was generated after the rules were fixed.

## 8. Cost

- Median search nodes: screening about 150, merged solving about 2460. Screening is cheap; a rejected case pays a little extra screening and then merges.
- For cuts that pass M1v, cut-plus-screen has a median of 148 nodes against 836 for merging, about 5.6 times fewer; but only 7% of cuts get this saving.
- At this scale, the total cost of "screen, merge if rejected" is close to merging directly.

## 9. Interpretation

1. **Virtual boundaries can be used safely, but the current screen is very conservative.** Of 337 exact cuts, M1v recognises only 71.
2. **Failure types are becoming specific, but the method cannot be said to have converged.** New counterexamples may still come from move order and tempo, moves away from the interface, or several dependencies at once.
3. **All three known types correspond to v0.3 premises** (interface dependence, transitions and sente, shared liberties). This is structural evidence that the premise list points the right way, not that it is complete.
4. **Shared liberties reproduce T3's result on virtual boundaries:** interaction passes through shared objects, so the structural check must take whole groups and the distribution of their liberties as its unit.
5. **As agreed before this round, no further screening rules are added in v0.4.**

## 10. Open problems and next steps

1. **Ko:** cuts with local ko outnumber valid cuts; this needs local valuation of loopy games, or exact search with state.
2. **Coverage:** examine the 266 exact cuts that were rejected, to see which checks are too strict.
3. **Scale and cost:** a formal T4 cost measurement on larger areas is needed to say whether decomposition pays.
4. **Choice of method:** choose an exact algorithm per knot according to its structure and interface complexity, provided all algorithms share the same rules and result semantics.

## Appendix: files

- Code: `t4.py`, `gen4.py`, `fullexact.py`, `regress_ko.py`, `sum_t4.py`, `t4_replay.py`
- Results:
    - `results/t4x_old.jsonl` (round 1)
    - `results/t4x_new.jsonl`, `results/t4x_new_m1t.jsonl` (round 2)
    - `results/t4t_*.jsonl` (round 3)
    - `results/t4u_*.jsonl` (round 4)
    - `results/t4v_*.jsonl` (round 5)
    - Summaries: `results/*summary*.txt`
    - Counterexamples: `results/t4_counterexamples.json`
- Void version 1: `results/t4_v1/`, `fullko.py`
- Timeline and each round's pre-registration: `PROGRESS.md`
