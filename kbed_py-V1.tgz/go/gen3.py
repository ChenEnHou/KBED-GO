"""Positions with one capturable wall chain (H3/H4/H5) plus independent regions.

The chain is made of ordinary stones of one colour. Its neighbours are either
cells of the regions it touches or uncapturable walls of the OPPOSITE colour,
so it never joins an uncapturable group. Regions are separated from each
other by walls or by the chain.
"""
import random
from goeng import Board, EMPTY, B, W, BW, WW


def make3(rng, size=9, touch=(1, 3), extra=(0, 2), regsize=(2, 4),
          chain_len=(1, 3), max_empty=12, stone_p=0.12):
    bd = Board(size, size)
    N = size * size
    b = [None] * N
    # chain
    c = rng.choice([B, W])
    opp_wall = WW if c == B else BW
    start = rng.randrange(N)
    x, y = start % size, start // size
    if not (2 <= x <= size - 3 and 2 <= y <= size - 3):
        return None
    chain = [start]
    L = rng.randint(*chain_len)
    while len(chain) < L:
        fr = [r for q in chain for r in bd.nb[q] if r not in chain]
        chain.append(rng.choice(fr))
    for q in chain:
        b[q] = c
    chain_set = set(chain)
    adj = sorted({r for q in chain for r in bd.nb[q] if r not in chain_set})
    k = rng.randint(*touch)
    if len(adj) < k:
        return None
    seeds = rng.sample(adj, k)
    regions = []
    owner = {}
    for ri, s in enumerate(seeds):
        if s in owner:
            return None
        # a seed must not touch another region
        if any(owner.get(r) is not None for r in bd.nb[s]):
            return None
        comp = [s]
        owner[s] = ri
        size_r = rng.randint(*regsize)
        tries = 0
        while len(comp) < size_r and tries < 50:
            tries += 1
            fr = [r for q in comp for r in bd.nb[q]
                  if r not in owner and r not in chain_set and b[r] is None]
            fr = [r for r in fr if all(owner.get(n, ri) == ri for n in bd.nb[r])]
            if not fr:
                break
            r = rng.choice(fr)
            comp.append(r)
            owner[r] = ri
        regions.append(comp)
    for comp in regions:
        for q in comp:
            b[q] = EMPTY
    # chain neighbours that are not region cells: opposite-colour walls
    for q in adj:
        if b[q] is None:
            b[q] = opp_wall
    # independent extra regions, away from chain and other regions
    ne = rng.randint(*extra)
    for _ in range(ne):
        for _t in range(100):
            s = rng.randrange(N)
            if b[s] is not None:
                continue
            if any(b[r] is not None and b[r] in (EMPTY,) or r in chain_set for r in bd.nb[s]):
                continue
            comp = [s]
            ok = True
            size_r = rng.randint(*regsize)
            while len(comp) < size_r:
                fr = [r for q in comp for r in bd.nb[q] if b[r] is None and r not in comp
                      and not any((b[n] == EMPTY or n in chain_set) and n not in comp for n in bd.nb[r])]
                if not fr:
                    break
                comp.append(rng.choice(fr))
            if len(comp) < 2:
                continue
            for q in comp:
                b[q] = EMPTY
            regions.append(comp)
            break
    # walls around regions: random colours, but never the chain colour next to the chain
    for comp in regions:
        for q in comp:
            for r in bd.nb[q]:
                if b[r] is None:
                    b[r] = rng.choice([BW, WW])
    for q in range(N):
        if b[q] is None:
            b[q] = rng.choice([BW, WW])
    # interior stones
    for comp in regions:
        for q in comp:
            if rng.random() < stone_p:
                b[q] = rng.choice([B, W])
    b = tuple(b)
    # sanity: no group without liberties unless immortal; chain must have >= 1 liberty
    for q in range(N):
        if b[q] in (B, W):
            g, libs, imm = bd.group(b, q)
            if not libs and not imm:
                return None
    g, libs, imm = bd.group(b, chain[0])
    if imm or set(g) != chain_set:
        return None   # chain merged with something else
    empties = sum(1 for x in b if x == EMPTY)
    if empties > max_empty or empties < 3:
        return None
    # regions as cell lists, and which touch the chain
    touching = [i for i, comp in enumerate(regions)
                if any(r in chain_set for q in comp for r in bd.nb[q])]
    return bd, b, [sorted(r) for r in regions], sorted(chain), touching
