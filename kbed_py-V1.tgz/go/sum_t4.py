import json, glob, collections
import statistics as stt
import sys
pat = sys.argv[1] if len(sys.argv) > 1 else 'results/t4x_*.jsonl'
rs = [json.loads(l) for f in sorted(glob.glob(pat)) for l in open(f)]
st = collections.Counter(r['status'] for r in rs)
ok = [r for r in rs if r['status'] == 'ok']
print('excluded for GHI mismatch:', sum(1 for r in ok if r.get('ghi_check') is False))
ok = [r for r in ok if r.get('ghi_check') is not False]
print('records', len(rs), dict(st))
print('GHI cross-check (positions with superko pruning):', collections.Counter(r.get('ghi_check') for r in ok if 'ghi_check' in r))
seps = [(r, s) for r in ok for s in r['seps'] if 'status' not in s]
skipped = collections.Counter(s['status'] for r in ok for s in r['seps'] if 'status' in s)
print('separators analysed', len(seps), 'skipped', dict(skipped))
def rate(sel, f):
    sel = list(sel)
    return '%d/%d' % (sum(1 for x in sel if f(x)), len(sel)) if sel else '-'
print('E1 M0 seam exact:', rate(seps, lambda x: x[1]['M0_seam_ok']))
print('   M0 assign exact (any / all assignments):', rate(seps, lambda x: any(x[1]['M0_assign_ok'])), rate(seps, lambda x: all(x[1]['M0_assign_ok'])))
for key, fn in [('w', lambda s: s['w']), ('where', None), ('junction', lambda s: s['junction']),
                ('S_stones', lambda s: s['S_stones']), ('depth', lambda s: s['depth']),
                ('n_knots', lambda s: s['n_knots'])]:
    groups = collections.defaultdict(list)
    for r, s in seps:
        k = r['where'] if key == 'where' else fn(s)
        groups[k].append((r, s))
    print('  by', key, {k: rate(v, lambda x: x[1]['M0_seam_ok']) for k, v in sorted(groups.items(), key=lambda kv: str(kv[0]))})
passed = [x for x in seps if x[1]['M1_pass']]
print('E2 M1 pass (coverage):', rate(seps, lambda x: x[1]['M1_pass']))
print('   M1 false pass (passed but M0 wrong):', rate(passed, lambda x: not x[1]['M0_seam_ok']))
print('   M1b (two-way) pass:', rate(seps, lambda x: x[1].get('M1b_pass', False)), ' false pass:', rate([x for x in seps if x[1].get('M1b_pass')], lambda x: not x[1]['M0_seam_ok']))
print('   M1t pass:', rate(seps, lambda x: x[1].get('M1t_pass', False)), ' false:', rate([x for x in seps if x[1].get('M1t_pass')], lambda x: not x[1]['M0_seam_ok']))
print('   M1tb pass:', rate(seps, lambda x: x[1].get('M1tb_pass', False)), ' false:', rate([x for x in seps if x[1].get('M1tb_pass')], lambda x: not x[1]['M0_seam_ok']))
print('   M1u (M1 & M1t & seam) pass:', rate(seps, lambda x: x[1].get('M1b_pass', False) and x[1].get('M1t_pass', False)), ' false:', rate([x for x in seps if x[1].get('M1b_pass') and x[1].get('M1t_pass')], lambda x: not x[1]['M0_seam_ok']))
print('   M1v (pre-reg 3) pass:', rate(seps, lambda x: x[1].get('M1v_pass', False)), ' false:', rate([x for x in seps if x[1].get('M1v_pass')], lambda x: not x[1]['M0_seam_ok']))
print('   structural fail:', rate(seps, lambda x: x[1].get('structural_ok') is False), ' seam_play fail:', rate(seps, lambda x: x[1].get('seam_play_insensitive') is False))
if seps and 'M1v_nodes' in seps[0][1]:
    print('   screening nodes median (M1 + M1v parts):', stt.median(s['M1_nodes'] + s['M1v_nodes'] for _, s in seps))
print('   M1t truncated:', sum(1 for x in seps if x[1].get('M1t_truncated')))
print('   M0 exact among M1 fail:', rate([x for x in seps if not x[1]['M1_pass']], lambda x: x[1]['M0_seam_ok']))
import statistics as stt
if seps:
    print('E4 nodes median: M0', stt.median(s['M0_nodes'] for _, s in seps), 'M1', stt.median(s['M1_nodes'] for _, s in seps),
          'M2', stt.median(r['full_nodes'] for r in ok))
