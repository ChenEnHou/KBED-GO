import json, glob, collections
rs=[]
for f in sorted(glob.glob('results/t1_*.jsonl')):
    rs += [json.loads(l) for l in open(f)]
c=collections.Counter(r['status'] for r in rs)
ok=[r for r in rs if r['status']=='ok']
print('records',len(rs),dict(c))
if ok:
    print('score agree', sum(r['score_ok'] for r in ok),'/',len(ok))
    print('first move agree', sum(r['move_ok_B'] and r['move_ok_W'] for r in ok))
    print('move sets equal', sum(r['moveset_equal'] for r in ok))
    h=[r for r in ok if 'hot_has_opt_B' in r]
    print('hottest region contains an optimal Black move', sum(r['hot_has_opt_B'] for r in h),'/',len(h))
    print('by empties', sorted(collections.Counter(r['n_empty'] for r in ok).items()))
    print('by regions', sorted(collections.Counter(r['n_regions'] for r in ok).items()))
    print('max full time', max(r['time_full'] for r in ok))
print('STOP files', glob.glob('results/*.STOP'))
