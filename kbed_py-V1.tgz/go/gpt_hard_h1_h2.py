import json, glob, collections, time, signal
import cgt
from goeng import parse, FullSolver, Ko, Cycle
from decomp import LocalSolver, decompose
from tiles import tile, touches_edge, assemble, swap

# Build unique realized local Go tiles from all successful T1 runs.
pool={}
for f in sorted(glob.glob('results/t1_*.jsonl')):
    for line in open(f):
        r=json.loads(line)
        if r.get('status')!='ok': continue
        bd,b=parse(r['board'])
        for reg in r['regions']:
            t=tile(bd,b,reg)
            if touches_edge(t): continue
            k=json.dumps(t)
            if k in pool: continue
            try:
                abd,ab=assemble([t]); regs=__import__('goeng').regions(abd,ab)
                if len(regs)!=1: continue
                v=LocalSolver(abd,regs[0]).value(ab)
            except (Ko,Cycle):
                continue
            pool[k]=(t,v,sum(x==0 for x in ab))

vals=collections.defaultdict(list)
for x in pool.values(): vals[cgt.ser(x[1])].append(x)

class EvalTimeout(Exception): pass
def _alarm(*a): raise EvalTimeout()
def eval_tiles(ts):
    signal.signal(signal.SIGALRM,_alarm); signal.alarm(4)
    bd,b=assemble(ts); regs=__import__('goeng').regions(bd,b)
    d=decompose(bd,b,regs)
    fs=FullSolver(bd); vb,ob=fs.root(b,1); vw,ow=fs.root(b,2)
    signal.alarm(0)
    return {
      'score_ok': str(d['ls'])==str(vb) and str(d['rs'])==str(vw),
      'B_decomp':str(d['ls']),'W_decomp':str(d['rs']),'B_full':vb,'W_full':vw,
      'optB_dec':sorted(map(str,d['opt1'])),'optW_dec':sorted(map(str,d['opt2'])),
      'optB_full':sorted(map(str,ob)),'optW_full':sorted(map(str,ow)),
      'moveB_ok': any(str(x) in set(map(str,ob)) for x in d['opt1'] if x!='pass') or ('pass' in d['opt1'] and 'pass' in ob),
      'moveW_ok': any(str(x) in set(map(str,ow)) for x in d['opt2'] if x!='pass') or ('pass' in d['opt2'] and 'pass' in ow),
      'nodes_full':fs.nodes,'nodes_local':d['local_nodes']
    }

out={'pool_tiles':len(pool),'pool_values':len(vals),'H1':[],'H2':{}}
# H1: realized high-temperature game + lower-temperature gote game.
# This is a targeted move-order/sente-like stress test, not a claim that each A is formal absolute sente.
hot=[]; low=[]
for t,v,ne in pool.values():
    try: temp=cgt.temperature_bound(v); ls=cgt.left_stop(v); rs=cgt.right_stop(v)
    except ValueError: continue
    if v not in cgt.NUM and temp >= 1: hot.append((t,v,ne,temp,ls,rs))
    if v not in cgt.NUM and temp > 0 and temp <= 1: low.append((t,v,ne,temp,ls,rs))
hot.sort(key=lambda x:(x[3],x[4]-x[5]), reverse=True)
low.sort(key=lambda x:(x[3],x[4]-x[5]))
seen=set()
for A in hot:
  for B in low:
    if A[2]+B[2]>12: continue
    sig=(cgt.ser(A[1]),cgt.ser(B[1]))
    if sig in seen: continue
    seen.add(sig)
    try:r=eval_tiles([A[0],B[0]])
    except (Ko,Cycle,EvalTimeout):
      signal.alarm(0); continue
    r.update({'A':cgt.ser(A[1]),'B':cgt.ser(B[1]),'tempA':str(A[3]),'tempB':str(B[3]),'stopsA':[str(A[4]),str(A[5])],'stopsB':[str(B[4]),str(B[5])]})
    out['H1'].append(r)
    if len(out['H1'])>=15: break
  if len(out['H1'])>=15: break

# H2a: realized STAR versus ZERO across realized contexts.
stars=vals[cgt.ser(cgt.STAR)]; zeros=vals[cgt.ser(cgt.ZERO)]
h2=[]
if stars and zeros:
 A=stars[0]; B=zeros[0]
 contexts=[]
 # -B context (zero), -A context (star because -*=*) and diverse realized contexts.
 contexts.append(('negB',[swap(B[0])]))
 contexts.append(('negA',[swap(A[0])]))
 # one representative from each common value, cap total and empties
 for sv,xs in sorted(vals.items(), key=lambda kv:-len(kv[1])):
    X=xs[0]
    if A[2]+X[2] <=12 and B[2]+X[2]<=12:
      contexts.append((sv,[X[0]]))
    if len(contexts)>=22: break
 for name,X in contexts:
    try:
      ra=eval_tiles([A[0]]+X); rb=eval_tiles([B[0]]+X)
    except (Ko,Cycle,EvalTimeout):
      signal.alarm(0); continue
    h2.append({'context':name,'A_scores':[ra['B_full'],ra['W_full']], 'B_scores':[rb['B_full'],rb['W_full']], 'same_score':ra['B_full']==rb['B_full'] and ra['W_full']==rb['W_full'], 'A_exact':ra['score_ok'],'B_exact':rb['score_ok']})
out['H2']['star_vs_zero']=h2
# Algebraic identity/distinction diagnostics
out['H2']['algebra']={
 'star_eq_zero':cgt.eq(cgt.STAR,cgt.ZERO),
 'star_plus_negstar':cgt.ser(cgt.add(cgt.STAR,cgt.neg(cgt.STAR))),
 'star_stops':[str(cgt.left_stop(cgt.STAR)),str(cgt.right_stop(cgt.STAR))],
 'zero_stops':['0','0'],
 'up_eq_zero':cgt.eq(cgt.UP,cgt.ZERO),
 'up_stops':[str(cgt.left_stop(cgt.UP)),str(cgt.right_stop(cgt.UP))]
}
json.dump(out,open('results/gpt_h1_h2_rerun_fixed.json','w'),ensure_ascii=False,indent=2)
print('pool',len(pool),'values',len(vals))
print('H1',len(out['H1']),'score pass',sum(x['score_ok'] for x in out['H1']),'moveB',sum(x['moveB_ok'] for x in out['H1']),'moveW',sum(x['moveW_ok'] for x in out['H1']))
print('H1 distinct pairs:', [(x['A'],x['B']) for x in out['H1'][:10]])
print('H2 star/zero contexts',len(h2),'same score',sum(x['same_score'] for x in h2),'A exact',sum(x['A_exact'] for x in h2),'B exact',sum(x['B_exact'] for x in h2))
print('H2 algebra',out['H2']['algebra'])
