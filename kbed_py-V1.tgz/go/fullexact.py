"""Exhaustive solver whose transposition table is exact.

Rules: basic ko rule only (no immediate recapture of a single stone); two
consecutive passes end the game; Japanese count at the end.
State = (board, side to move, previous move was pass, ko-banned point).
With this state the legal moves and the outcome of every continuation depend
only on the state, not on the history, so storing values by state is exact.

If the state graph reachable from the root contains a cycle (e.g. triple ko,
sending-two-returning-one), the game under these rules is not finite and the
position is rejected (raises Cycle), as in the first round. Cycle detection
uses the standard DFS rule: a cycle exists iff some state reaches a state that
is still on the DFS stack; states finished earlier cannot lie on a cycle
through the current stack, so the table does not hide cycles.
"""
from goeng import Cycle


class FullSolverExact:
    def __init__(self, board, terminal):
        self.bd = board
        self.terminal = terminal
        self.memo = {}
        self.stack = set()
        self.nodes = 0
        self.ko_seen = False

    def solve(self, b, tm, passed=False, kopt=None):
        key = (b, tm, passed, kopt)
        v = self.memo.get(key)
        if v is not None:
            return v
        if key in self.stack:
            raise Cycle()
        self.nodes += 1
        self.stack.add(key)
        try:
            best = self.terminal(b) if passed else self.solve(b, 3 - tm, True, None)
            for p in range(len(b)):
                if b[p] != 0 or p == kopt:
                    continue
                r = self.bd.play(b, p, tm)
                if r is None:
                    continue
                nb, cap, ko = r
                nk = None
                if ko:
                    self.ko_seen = True
                    nk = next(q for q in self.bd.nb[p] if b[q] != 0 and nb[q] == 0)
                v = (cap if tm == 1 else -cap) + self.solve(nb, 3 - tm, False, nk)
                best = max(best, v) if tm == 1 else min(best, v)
        finally:
            self.stack.discard(key)
        self.memo[key] = best
        return best


class PlainMinimax:
    """Same rules, no transposition table: an independent check of the table.
    Exponential; only for tiny positions."""

    def __init__(self, board, terminal):
        self.bd = board
        self.terminal = terminal
        self.stack = set()
        self.nodes = 0

    def solve(self, b, tm, passed=False, kopt=None):
        key = (b, tm, passed, kopt)
        if key in self.stack:
            raise Cycle()
        self.nodes += 1
        self.stack.add(key)
        try:
            best = self.terminal(b) if passed else self.solve(b, 3 - tm, True, None)
            for p in range(len(b)):
                if b[p] != 0 or p == kopt:
                    continue
                r = self.bd.play(b, p, tm)
                if r is None:
                    continue
                nb, cap, ko = r
                nk = None
                if ko:
                    nk = next(q for q in self.bd.nb[p] if b[q] != 0 and nb[q] == 0)
                v = (cap if tm == 1 else -cap) + self.solve(nb, 3 - tm, False, nk)
                best = max(best, v) if tm == 1 else min(best, v)
        finally:
            self.stack.discard(key)
        return best
