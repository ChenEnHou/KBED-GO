"""v0.4: virtual separators. M0 (cut and add), M1 (insensitivity screening),
M2 (merged exhaustive solution, ground truth).

usage: python3 t4.py OUT.jsonl SEED_START SEED_END
"""
import sys, json, os, random, signal, itertools
import cgt, japanese
from goeng import FullSolver, Ko, Cycle, render
from decomp import LocalSolver
from gen4 import make4
from fullexact import FullSolverExact


class Timeout(Exception):
    pass


def _alarm(*a):
    raise Timeout()


def legal_board(bd, b, area):
    for p in area:
        if b[p] in (1, 2):
            g, libs, imm = bd.group(b, p)
            if not libs and not imm:
                return False
    return True


def stops_of(vals):
    S = cgt.total(vals)
    return cgt.left_stop(S), cgt.right_stop(S)


def analyse_sep(bd, b, area, S, comps, touch, full):
    out = {'S': list(S), 'w': len(S), 'knot_sizes': [len(c) for c in comps],
           'n_knots': len(comps), 'junction': any(len(t) >= 3 for t in touch),
           'S_stones': sum(1 for s in S if b[s] in (1, 2))}
    stones = [p for p in area if b[p] in (1, 2) and p not in S]
    w_ = bd.w
    if stones:
        out['depth'] = min(abs(s % w_ - p % w_) + abs(s // w_ - p // w_) for s in S for p in stones)
    else:
        out['depth'] = None
    nodes = 0
    # M0 seam knot
    sols = [LocalSolver(bd, c) for c in comps] + [LocalSolver(bd, sorted(S))]
    vals = [s.value(b) for s in sols]
    nodes += sum(s.nodes for s in sols)
    ls, rs = stops_of(vals)
    out['M0_seam'] = [str(ls), str(rs)]
    out['M0_seam_ok'] = (ls, rs) == full
    out['M0_nodes'] = nodes
    # M0 assign S to one knot
    assign = []
    for i in range(len(comps)):
        parts = [sorted(set(comps[j]) | (set(S) if j == i else set())) for j in range(len(comps))]
        v = [LocalSolver(bd, p).value(b) for p in parts]
        a = stops_of(v)
        assign.append(a == full)
    out['M0_assign_ok'] = assign
    # M1 screening: each knot's value must be the same for every state of S
    insensitive = []
    m1nodes = 0
    for c in comps:
        seen = set()
        for st in itertools.product((0, 1, 2), repeat=len(S)):
            nb = list(b)
            for s, v in zip(S, st):
                nb[s] = v
            nb = tuple(nb)
            if not legal_board(bd, nb, area):
                continue
            ls_ = LocalSolver(bd, c)
            seen.add(cgt.ser(ls_.value(nb)))
            m1nodes += ls_.nodes
            if len(seen) > 1:
                break
        # at least one valid interface state is required (the current state is
        # always among them; guard added after code review)
        insensitive.append(len(seen) == 1)
    out['M1_insensitive'] = insensitive
    out['M1_pass'] = all(insensitive)
    out['M1_nodes'] = m1nodes
    out['M1_false_pass'] = out['M1_pass'] and not out['M0_seam_ok']
    # Two-way screen (pre-registered 2026-10-08): additionally, the seam knot's
    # value must not change when the empty knot points adjacent to S are set
    # all black, all white, or left as they are.
    adj = sorted({n for p in S for n in bd.nb[p] if n in set(area) and n not in S and b[n] == 0})
    seam_vals = set()
    for fill in (None, 1, 2):
        nb = list(b)
        if fill:
            for n in adj:
                nb[n] = fill
        nb = tuple(nb)
        if not legal_board(bd, nb, area):
            continue
        seam_vals.add(cgt.ser(LocalSolver(bd, sorted(S)).value(nb)))
    out['seam_insensitive'] = (len(seam_vals) == 1)
    out['M1b_pass'] = out['M1_pass'] and out['seam_insensitive']
    # M1t (transition screen, pre-registered 2026-10-08 after the M1b failure):
    # the interface states are those REACHABLE by legal moves of either colour
    # on S points (any order, captures included, ko ignored -> more states),
    # instead of fixed assignments. Each knot's value must be the same in
    # every reachable state; combined with the seam screen as M1tb.
    reach = {b}
    frontier = [b]
    while frontier and len(reach) < 300:
        cur = frontier.pop()
        for s_ in S:
            if cur[s_] != 0:
                continue
            for col in (1, 2):
                rr = bd.play(cur, s_, col)
                if rr is None:
                    continue
                nb2 = rr[0]
                if nb2 not in reach:
                    reach.add(nb2)
                    frontier.append(nb2)
    out['M1t_states'] = len(reach)
    out['M1t_truncated'] = len(reach) >= 300
    t_ins = []
    for c in comps:
        vs = set()
        for nb2 in reach:
            vs.add(cgt.ser(LocalSolver(bd, c).value(nb2)))
            if len(vs) > 1:
                break
        t_ins.append(len(vs) == 1)
    out['M1t_insensitive'] = t_ins
    out['M1t_pass'] = all(t_ins) and not out['M1t_truncated']
    out['M1tb_pass'] = out['M1t_pass'] and out['seam_insensitive']
    out['M1tb_false_pass'] = out['M1tb_pass'] and not out['M0_seam_ok']

    # ---- M1v (pre-registered 2026-10-08, round 5) ----
    # (a) seam screen by actual play: stones of either colour are PLAYED (legal
    #     moves only; merging, captures and liberties handled by Board.play) on
    #     the empty knot points adjacent to S, in any order, from the current
    #     position; the seam knot's value must be the same in every reachable
    #     position. Replaces the static fill, which skipped capturing fills.
    v_nodes = 0
    aset = set(area)
    sset = set(S)
    adj = sorted({n for p in S for n in bd.nb[p] if n in aset and n not in sset and b[n] == 0})
    reach2 = {b}
    frontier = [b]
    while frontier and len(reach2) < 300:
        cur = frontier.pop()
        for q in adj:
            if cur[q] != 0:
                continue
            for col in (1, 2):
                rr = bd.play(cur, q, col)
                if rr is None:
                    continue
                if rr[0] not in reach2:
                    reach2.add(rr[0])
                    frontier.append(rr[0])
    seam_play = set()
    for nb2 in reach2:
        ls_ = LocalSolver(bd, sorted(S))
        seam_play.add(cgt.ser(ls_.value(nb2)))
        v_nodes += ls_.nodes
        if len(seam_play) > 1:
            break
    out['seam_play_states'] = len(reach2)
    out['seam_play_insensitive'] = (len(seam_play) == 1) and len(reach2) < 300
    # (b) structural check on whole groups: for every capturable (non-wall)
    #     group, the parts it touches through its stones and liberties are
    #     collected (each knot is a part, the interface S is a part). A group
    #     touching two or more parts is a cross-boundary dependence that is
    #     not proved safe -> fail (merge).
    part = {}
    for i, c in enumerate(comps):
        for q in c:
            part[q] = i
    for q in S:
        part[q] = 'S'
    seen_g = set()
    cross = []
    for p in area:
        if b[p] in (1, 2) and p not in seen_g:
            g, libs, imm = bd.group(b, p)
            seen_g |= g
            if imm:
                continue
            parts = {part[q] for q in g if q in part} | {part[q] for q in libs if q in part}
            if len(parts) >= 2:
                cross.append(sorted(parts, key=str))
    out['cross_groups'] = [[str(x) for x in c] for c in cross]
    out['structural_ok'] = not cross
    out['M1v_nodes'] = v_nodes
    out['M1v_pass'] = (out['M1_pass'] and out['M1t_pass'] and out['seam_insensitive']
                       and out['seam_play_insensitive'] and out['structural_ok'])
    out['M1v_false_pass'] = out['M1v_pass'] and not out['M0_seam_ok']
    out['M1b_false_pass'] = out['M1b_pass'] and not out['M0_seam_ok']
    out['local_values'] = [cgt.ser(v) for v in vals]
    return out


def run_one(seed, limit=120, max_seps=4):
    japanese.KO_RULE = True
    japanese._DEAD.clear()
    rng = random.Random(seed)
    r = make4(rng)
    if r is None:
        return {'seed': seed, 'status': 'nogen'}
    bd, b, area, where, seps = r
    rec = {'seed': seed, 'board': render(bd, b), 'area': area, 'where': where,
           'n_area': len(area), 'n_stones': sum(1 for p in area if b[p] in (1, 2))}
    signal.signal(signal.SIGALRM, _alarm)
    signal.alarm(limit)
    try:
        fs0 = FullSolver(bd)
        fs = FullSolverExact(bd, fs0.terminal)
        vb = fs.solve(b, 1)
        vw = fs.solve(b, 2)
        rec['full'] = [vb, vw]
        rec['full_ko_seen'] = fs.ko_seen
        rec['full_nodes'] = fs.nodes
        full = (vb, vw)
        pick = rng.sample(seps, min(max_seps, len(seps)))
        rec['seps'] = []
        for S, comps, touch in pick:
            try:
                rec['seps'].append(analyse_sep(bd, b, area, S, comps, touch, full))
            except (Ko, Cycle) as e:
                rec['seps'].append({'S': list(S), 'status': 'local_' + type(e).__name__})
    except Ko:
        rec['status'] = 'ko'
        return rec
    except Cycle:
        rec['status'] = 'cycle'
        return rec
    except Timeout:
        rec['status'] = 'timeout'
        return rec
    finally:
        signal.alarm(0)
    rec['status'] = 'ok'
    return rec


def main():
    out, a, z = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    done = set()
    if os.path.exists(out):
        for line in open(out):
            done.add(json.loads(line)['seed'])
    with open(out, 'a') as f:
        for seed in range(a, z):
            if seed in done:
                continue
            rec = run_one(seed)
            f.write(json.dumps(rec, ensure_ascii=False) + '\n')
            f.flush()


if __name__ == '__main__':
    main()
