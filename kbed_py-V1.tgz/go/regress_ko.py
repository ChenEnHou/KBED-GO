"""Regression: exact-table solver vs plain minimax (no table) on tiny areas
with stones, including positions where ko occurs."""
import random, collections, sys
import japanese
from goeng import FullSolver, Cycle, Ko
from fullexact import FullSolverExact, PlainMinimax
from gen4 import make_area
from goeng import EMPTY, B, W, BW, WW
japanese.KO_RULE = True
rng = random.Random(int(sys.argv[1]) if len(sys.argv) > 1 else 5)
c = collections.Counter()
for t in range(400):
    r = make_area(rng, size=5, n=(4, 6))
    if r is None:
        continue
    bd, area, where = r
    b = [rng.choice([BW, WW])] * 0 + [None] * (bd.w * bd.h)
    for q in range(len(b)):
        b[q] = EMPTY if q in area else rng.choice([BW, WW])
    for p in rng.sample(area, rng.randint(0, 3)):
        b[p] = rng.choice([B, W])
    b = tuple(b)
    if any(b[p] in (1, 2) and not bd.group(b, p)[1] and not bd.group(b, p)[2] for p in area):
        continue
    japanese._DEAD.clear()
    term = FullSolver(bd).terminal
    try:
        e = FullSolverExact(bd, term)
        v1 = (e.solve(b, 1), e.solve(b, 2))
        p = PlainMinimax(bd, term)
        v2 = (p.solve(b, 1), p.solve(b, 2))
    except Cycle:
        c['cycle'] += 1
        continue
    c['ok'] += 1
    c['ko'] += e.ko_seen
    if v1 != v2:
        c['MISMATCH'] += 1
        print('MISMATCH', v1, v2)
print(dict(c))
