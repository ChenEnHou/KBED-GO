"""Random base positions: regions separated by uncapturable walls."""
import random
from goeng import Board, regions, EMPTY, B, W, BW, WW, COLOR


def make(rng, size=9, nreg=(2, 5), regsize=(2, 6), max_empty=12, stone_p=0.15):
    bd = Board(size, size)
    N = size * size
    k = rng.randint(*nreg)
    cells = [None] * N   # region index or None
    taken = set()
    blocked = set()
    regs = []
    for ri in range(k):
        for _ in range(200):
            s = rng.randint(*regsize)
            seed = rng.randrange(N)
            if seed in taken or seed in blocked:
                continue
            comp = [seed]
            cs = {seed}
            ok = True
            while len(comp) < s:
                frontier = [r for q in comp for r in bd.nb[q]
                            if r not in cs and r not in taken and r not in blocked]
                if not frontier:
                    ok = False
                    break
                r = rng.choice(frontier)
                comp.append(r)
                cs.add(r)
            if not ok:
                continue
            regs.append(comp)
            taken |= cs
            for q in comp:
                for r in bd.nb[q]:
                    if r not in cs:
                        blocked.add(r)
            break
    if len(regs) < nreg[0]:
        return None
    # wall colours: each region gets a boundary type
    b = [None] * N
    for q in taken:
        b[q] = EMPTY
    for comp in regs:
        kind = rng.choice(['B', 'W', 'split', 'split'])
        xs = [q % size for q in comp]
        ys = [q // size for q in comp]
        cx = sum(xs) / len(xs)
        cy = sum(ys) / len(ys)
        horiz = rng.random() < 0.5
        for q in comp:
            for r in bd.nb[q]:
                if b[r] is None:
                    if kind == 'B':
                        b[r] = BW
                    elif kind == 'W':
                        b[r] = WW
                    else:
                        coord = (r % size - cx) if horiz else (r // size - cy)
                        b[r] = BW if coord < 0 else WW
    # remaining cells: walls, coloured by majority of neighbours or random
    for q in range(N):
        if b[q] is None:
            b[q] = rng.choice([BW, WW])
    # interior stones
    for q in taken:
        if rng.random() < stone_p:
            b[q] = rng.choice([B, W])
    b = tuple(b)
    # every interior group must have a liberty or be immortal
    for q in taken:
        if b[q] in (B, W):
            g, libs, imm = bd.group(b, q)
            if not libs and not imm:
                return None
    empties = sum(1 for q in taken if b[q] == EMPTY)
    if empties > max_empty or empties < 2:
        return None
    regs2 = regions(bd, b)
    if len(regs2) != len(regs):
        return None
    return bd, b, regs2
