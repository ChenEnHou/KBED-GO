"""Open areas cut by virtual separators (v0.4).

An open area (8-12 points, a few stones) is enclosed by uncapturable walls and
placed in the centre, on an edge or in a corner. A separator S (1-3 points)
is chosen so that removing S splits the area into 2 or more knots. S points
belong to the interface and may hold stones.
"""
import random, itertools
from goeng import Board, EMPTY, B, W, BW, WW


def components(bd, cells):
    cs = set(cells)
    seen = set()
    out = []
    for p in cells:
        if p in seen:
            continue
        comp = [p]
        seen.add(p)
        st = [p]
        while st:
            q = st.pop()
            for r in bd.nb[q]:
                if r in cs and r not in seen:
                    seen.add(r)
                    comp.append(r)
                    st.append(r)
        out.append(sorted(comp))
    return out


def make_area(rng, size=7, n=(7, 10), where=None):
    bd = Board(size, size)
    where = where or rng.choice(['centre', 'edge', 'corner'])
    if where == 'centre':
        start = (size // 2) * size + size // 2
    elif where == 'edge':
        start = 0 * size + size // 2
    else:
        start = 0
    target = rng.randint(*n)
    area = [start]
    aset = {start}
    while len(area) < target:
        fr = [r for q in area for r in bd.nb[q] if r not in aset]
        if where == 'centre':
            # keep off the board edge
            fr = [r for r in fr if 0 < r % size < size - 1 and 0 < r // size < size - 1]
        if not fr:
            return None
        r = rng.choice(fr)
        area.append(r)
        aset.add(r)
    return bd, sorted(area), where


def make4(rng, stones=(0, 3), wmax=3):
    r = make_area(rng)
    if r is None:
        return None
    bd, area, where = r
    N = bd.w * bd.h
    aset = set(area)
    # all separators of size 1..wmax that split the area into >= 2 parts of size >= 2
    seps = []
    for w in range(1, wmax + 1):
        for S in itertools.combinations(area, w):
            rest = [p for p in area if p not in S]
            comps = components(bd, rest)
            if len(comps) >= 2 and all(len(c) >= 2 for c in comps):
                # minimality: every S point touches at least two components
                touch = [{i for i, c in enumerate(comps) if any(n in c for n in bd.nb[s])} for s in S]
                if all(len(t) >= 2 for t in touch):
                    seps.append((S, comps, touch))
    if not seps:
        return None
    # walls
    b = [None] * N
    for p in area:
        b[p] = EMPTY
    for q in range(N):
        if b[q] is None:
            b[q] = rng.choice([BW, WW])
    # stones anywhere in the area (including possibly on S)
    k = rng.randint(*stones)
    for p in rng.sample(area, k):
        b[p] = rng.choice([B, W])
    b = tuple(b)
    for p in area:
        if b[p] in (B, W):
            g, libs, imm = bd.group(b, p)
            if not libs and not imm:
                return None
    return bd, b, area, where, seps
