# KBED Hierarchical Exact Computation: Theory and Validation Design v0.2

Oct 7, 2026 · Chen-En Hou

## 0. Scope

This document sets out a layered computation scheme (exact local computation → combination by value → merging and recomputing where premises break) and proposes an experimental design for validating its correctness at small scale. No experiments are run here; the document is for review.

Where existing theory already covers a point, the source is given. The document claims no new mathematical result. It tests only whether the method is correct, not how much it saves in the middle game (Section 5).

Research question: in Go endgames known to be decomposable, can conditional exact local solutions replace full-board expansion, and can the scheme reliably fall back to a finer resolution when a premise breaks?

v0.2 is revised following review; changes are listed in Section 7.

## 1. Architecture

### 1.1 Three layers

| Layer | Object | Method |
|---|---|---|
| L0 Local | Knot: a region $R$ enclosed by a boundary $B$ | Solve exactly given boundary premise $\Pi$; record the result as $\Pi\Rightarrow v(K)=v$ |
| L1 Combination | Knots whose premises hold and which are mutually independent | Sum their combinatorial game values: $G=\sum_i G_i$ |
| L2 Interaction | Knots whose premises break or which interact | Merge into a larger local region and solve exactly; solve ko under a komaster assumption |

Pipeline: solve locally → certify premises → combine while premises hold → detect a broken premise → merge → re-solve.

### 1.2 Representation of a knot

Each knot carries four channels:

1. Value $v(K)$: the chilled, reduced canonical form, used as the identifier for equivalence (reason in 1.4);
2. Temperature $t(K)$: computed from $v(K)$; the value of moving first in this region;
3. Credibility $c(K)\in\{\text{proved},\ \text{conditional},\ \text{estimated}\}$;
4. Boundary premise $\Pi(K)$: the conditions under which $v(K)$ holds, including life of the walls, wall liberties, cutting points and connections, and liberties shared with other knots.

Merge rule:

$$v(K_1)=v(K_2),\quad c(K_1)=c(K_2)=\text{proved},\quad \Pi(K_1),\Pi(K_2)\ \text{hold}\ \Rightarrow\ K_1,K_2\ \text{are interchangeable}$$

Knots that share temperature and mean but differ in value (for example $0$ and $\uparrow$) must not be merged.

### 1.3 Move-by-move premise checks and colour difference

After each move:

1. Recompute the knot in which the move was played;
2. Check whether the boundary premise $\Pi$ of every adjacent knot still holds (proved by Benson's static test or by local search);
3. Merge any knot whose premise has broken with the knot of the move, and recompute (L2).

Interaction is decided by step 2, not by colour difference. Each knot's value is computed from its own region only; when the move is in A, B's region is unchanged, so B's value and temperature cannot change. "Colour difference appears only in the moved region" is therefore true by definition and cannot establish independence. Interaction usually happens at the boundary: the move changes B's premise (for example, it removes a wall liberty), not B's value, and the effect may surface only several moves later.

Colour difference is kept for visualization and ordering, extended to

$$\Delta M_t=(\Delta v_t,\ \Delta t_t,\ \Delta\Pi_t)$$

where $\Delta\Pi_t$ records changes in each knot's premise.

### 1.4 Reading the score from values

After summing local values, the global score cannot be obtained by adding local numbers; it must be read from the sum:

- The left and right stops of the sum are the score under optimal play with Black and with White moving first (Milnor; Berlekamp, Conway & Guy);
- In unchilled values, two regions differing by an infinitesimal have the same stops but can, in some sums, change who gets the last one-point gote move. Berlekamp and Wolfe's chilling turns that one-point difference into a value distinguishable under normal play. This document therefore uses chilled values as identifiers.

Both routes are implemented and cross-checked: (a) sum unchilled values and take stops; (b) sum chilled values, solve, and warm.

Under territory scoring dame are worth zero, so dame parity does not affect the score; parity arises under area scoring and is deferred to the second round.

### 1.5 Combination map of local outcomes (diagnostic)

Let $O_i$ be the possible outcomes of knot $i$. The feasible combinations are

$$\mathcal{F}=\{(o_1,\ldots,o_n)\in O_1\times\cdots\times O_n:\ \text{constraints between regions hold}\}$$

Constraints include capturing races (if one side lives the other dies), ko (only one side wins it), and the parts of one dragon living or dying together. Enumerate over $\mathcal{F}$ and compare global results:

- Influence of a single knot: the change in the global result when only $o_i$ changes;
- Interaction: the effect of $o_i$ depends on $o_j$.

The map describes "what the whole board looks like if each region ends with these outcomes". It contains no tempo exchange, so the winner cannot be read from it directly; the winner is decided by the game computation in L1 and L2.

## 2. Existing theory

| Claim | Source | Conditions |
|---|---|---|
| A local position can be represented by a value; the outcome of a sum is determined by the values | Combinatorial game theory (Conway; Berlekamp, Conway & Guy) | Regions independent |
| $G=H\iff G-H$ is a second-player win; equal values are interchangeable in any sum; for unequal values, $-H$ is a distinguishing context | Fundamental theorem of CGT (normal play) | Same |
| The score of a sum of scored games is given by the stops of the sum | Milnor (1953); Berlekamp, Conway & Guy | Non-negative incentives in each component |
| Go endgames map to CGT values; after chilling, the last point becomes a normal-play question | Berlekamp & Wolfe, *Mathematical Go* | Territory scoring, no ko, regions independent with safe boundaries |
| Combining local values solves endgames exactly; endgames of over 60 moves solved | Müller, decomposition search (1999) | Same |
| Ko can be valued given who holds the ko threats | Berlekamp's komaster; Müller, Berlekamp & Spight, generalized thermography (1996) | Komaster or threat situation specified exogenously |
| Basic types of capturing race can be decided by counting liberties and eyes | Müller (1999) | Limited to the analysed types |
| Life and death can be proved by static rules or local search | Benson (1976); Kishimoto & Müller (2005) | — |

The correspondence in row four, with its conditions, is the main object of this validation; T1 and T2 check it.

## 3. Validation design

### 3.1 Positions

Base positions:

- 7×7 or 9×9 board, with black and white groups already proved alive acting as walls that separate 2 to 5 regions;
- 2 to 6 empty points per region, possibly with a few stones; no more than 12 to 14 empty points on the whole board, so the full board can be searched exhaustively;
- Territory scoring (Japanese), to match the Berlekamp–Wolfe setting;
- No ko in the first round: positions in which ko arises during search are removed and logged separately;
- Positions generated at random, plus positions with known answers from Berlekamp & Wolfe as controls;
- Both Black and White to move are tested.

Hard positions (the base set is biased toward easy cases, so these are constructed separately):

| Type | Content | Used in |
|---|---|---|
| H1 Sente coupling | Independent regions combining large sente, reverse sente and small gote moves; tests whether the sum handles sente order correctly | T1 |
| H2 Close values | Regions with equal temperature and mean but different values (e.g., differing by an infinitesimal) | T1, T2 |
| H3 Unsafe walls | Walls with only two or three liberties, where a peep or cut in one region threatens a wall | T3 |
| H4 Shared liberties | Two regions sharing liberties, forming a capturing race | T3 |

H3 and H4 violate the premises of L1 and are not used in T1; they test whether premise checking sends such positions to L2.

### 3.2 Baseline

Full exhaustive search of the whole board (minimax with a transposition table), giving the exact score with Black first and with White first, and the set of all optimal first moves in each case.

### 3.3 Experiments

**T1: Correctness of summation**

- Method: value and reduce each region separately; sum, then determine the global score and first move by exact sum search (decomposition search), not by "play in the hottest region", which is recorded separately for comparison. The score is computed by both routes in 1.4 and cross-checked.
- Criterion: with Black first and with White first, the score agrees with the baseline; the first move chosen by decomposition belongs to the baseline's set of optimal moves.
- Falsification: a single disagreement means the correspondence conditions or the implementation are wrong; stop and diagnose.
- Note: the first-round query asks only for the score and the best first move, so full optimal lines are not compared. That would be needed only to claim the full strategy is preserved.

**T2: Correctness of substitution**

- Method: collect pairs of regions $(A,B)$ with equal value but different shape and size, plus a control group with different values. Two kinds of context: (i) random contexts; (ii) the constructed distinguishing context $-B$, i.e., $B$ with colours swapped, placed behind safe walls. Replace $A$ by $B$ and compare by exhaustive search.
- Criterion: for equal-value pairs, the score with Black first and with White first is unchanged in every context.
- Falsification: an equal-value pair changes the score, meaning "equal values may be merged" does not hold in this setting.
- Control group (diagnostic, not a criterion): for different-value pairs, record whether a score difference appears in context $-B$. In theory $A-B\neq 0$, but whether that difference shows in the score depends on the correspondence in Section 2, row four. If a different-value pair gives the same score in every context, the chilled value is finer than the "score" query needs; this is recorded, not counted as failure.

**T3: Detection of interaction**

- Ground truth: for each pair of adjacent regions $(A,B)$, after every move along optimal play, value $A\cup B$ exactly as a single region, and define

$$I(A,B)=1\iff v(A\cup B)\neq v(A)+v(B)$$

- Detectors: D1 premise checking (1.3); D2 colour difference (using only $\Delta v,\Delta t$).
- Criterion: compute miss and false-alarm rates of D1 and D2 against $I$; D1 must have no misses on base positions; record how many moves in advance D1 catches interactions that surface later.
- Falsification: a D1 miss on base positions or on H3/H4 means the list of premises is incomplete and $\Pi$ must be extended.
- Expectation: D2 misses most interactions (1.3); this experiment confirms it.

**T4: Cost**

- Method: compare search nodes and wall-clock time of full search versus decomposition, grouped by number of regions and empty points; decomposition cost includes premise checking.
- Criterion: a measurement, with no pass or fail.

**T5: Combination map (exploratory)**

- Method: for each position, list each region's possible outcomes and constraints; compute each region's influence and pairwise interactions over the feasible combinations.
- Check: whether the most influential region coincides with the region of the best first move in T1, or with the hottest region.
- Criterion: exploratory, with no pass or fail.

### 3.4 Second round (after the first round passes)

1. Add ko: value it under a komaster assumption and compare with full search under the same rules; log positions where the komaster assumption does not match the actual threat situation.
2. Switch to area scoring: handle the one-move parity difference from territory scoring.
3. Add seki and other special outcomes.

## 4. Interpretation

| Result | Meaning |
|---|---|
| T1 and T2 agree everywhere | Hierarchical exact computation is correct on independent endgames; equal values allow merging |
| Any disagreement in T1 or T2 | The correspondence conditions or the implementation are wrong; the scheme must not be used until the cause is found |
| Routes (a) and (b) disagree in T1 | Chilling or stop computation is implemented wrongly |
| T3: D1 has no misses | Premise checking can govern moving up and down layers |
| T3: D1 has misses | The list of premises is incomplete; extend and retest |
| T3: D2 misses many | Confirms that colour difference cannot establish independence; it is an aid only |

Passing the first round shows only that this implementation reproduces Berlekamp and Wolfe's results on independent endgames, i.e., the instrument is calibrated. It says nothing by itself about whether the hierarchy works with ko, seki or in the middle game.

## 5. Outside the scope of this validation

1. Savings in the middle game: depends on how many local regions in the middle game can be proved independent; small experiments cannot answer this.
2. Recurrence at the knot level: how often knots of equal value recur across large numbers of games.
3. "Moves outside known patterns arise in decisive regions or at points of interaction": a hypothesis; T5 gives only preliminary hints.
4. Endogeneity of ko: the komaster assumption takes the threat situation as given; in real games threats are determined by the whole board. The second round records this; it does not solve it.

## 6. Questions for reviewers

1. Section 1.4: in this setting (territory scoring, no ko, safe boundaries, prisoners counted), is it correct and sufficient to use chilled values as identifiers and read the score from stops?
2. T2: for two regions with different values, must context $-B$ produce a score difference? If not, how should "score equivalence" be defined?
3. T3: $I(A,B)$ is defined pairwise; can it miss interactions that appear only among three or more regions?
4. Section 1.2: is the list of premises in $\Pi$ (wall life, liberties, cutting points and connections, shared liberties) complete when there is no ko?

## 7. Revision log (v0.1 → v0.2)

Adopted:

- T3 now defines ground truth by merged valuation, uses premise checking as the main detector, and keeps colour difference as a comparison (both reviewers noted that interaction can exist with zero colour difference; in addition, under this definition colour difference can never fire in independent cases);
- T2's control group now uses the constructed distinguishing context $-B$ and is not a criterion;
- New Section 1.4 on chilling and stops;
- T1 states that the first move is chosen by exact sum search;
- Hard positions H1–H4 added;
- Interpretation states that the first round is calibration; Section 5 adds ko endogeneity.

Not adopted or corrected:

- "Without chilling the addition theorem fails": summation still holds; the issue is that the score cannot be read by adding numbers and must come from stops or from chilled values (1.4).
- "Dame parity decides the result": under territory scoring dame are worth zero; this applies to area scoring and is deferred to the second round.
- "T1 must compare both players moving first": already required in v0.1; now written into the criterion.
- "T1 must compare full strategies": the first-round query covers only score and first move; not adopted for now.

## References

- Benson, D. B. Life in the Game of Go. Information Sciences 10(2), 17–29, 1976.
- Berlekamp, E. R. The Economist's View of Combinatorial Games. In Games of No Chance, MSRI Publications 29, 1996.
- Berlekamp, E. R., Conway, J. H., & Guy, R. K. Winning Ways for Your Mathematical Plays. Academic Press, 1982.
- Berlekamp, E. R., & Wolfe, D. Mathematical Go: Chilling Gets the Last Point. A K Peters, 1994.
- Conway, J. H. On Numbers and Games. Academic Press, 1976.
- Kishimoto, A., & Müller, M. Search versus Knowledge for Solving Life and Death Problems in Go. AAAI 2005.
- Milnor, J. Sums of Positional Games. In Contributions to the Theory of Games II, Annals of Mathematics Studies 28, 291–301, 1953.
- Müller, M. Decomposition Search: A Combinatorial Games Approach to Game Tree Search, with Applications to Solving Go Endgames. IJCAI 1999.
- Müller, M. Race to Capture: Analyzing Semeai in Go. Game Programming Workshop, 1999.
- Müller, M., Berlekamp, E., & Spight, B. Generalized Thermography: Algorithms, Implementation, and Application to Go Endgames. ICSI Technical Report TR-96-030, 1996.
