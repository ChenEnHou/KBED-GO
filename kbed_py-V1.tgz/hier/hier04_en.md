# KBED Hierarchical Exact Computation: Validation Design for Virtual Boundaries and Interfaces v0.4

Oct 8, 2026 · Chen-En Hou

## 0. Scope

v0.3 and the first validation round (T1–T3) dealt with regions separated by walls: in T1 and T2 the interface is empty, in T3 it is one shared object (a wall that can die). This document treats the general case: knots are separated by virtual lines whose points are shared by both sides and may or may not hold stones. It is a design only; no experiments are run.

T3's results (D1, D1b, D1c, D2) are kept as a controlled test of a shared physical object; this document generalizes them to arbitrary interfaces.

## 1. Problem

When the interface between knots is not empty, either side can play on it, cross it, or interact near it. A and B are then not two independent games, the CGT addition theorem does not apply, and "value of A + value of B" is undefined.

This document asks:

1. Under what conditions is it still exact to cut along virtual boundaries, value each part and add?
2. Can those conditions be established (proved, or reliably estimated) without solving the merged region?
3. How do those conditions change with knot size, position on the board, interface width, stones on the interface, and junctions where several knots meet?

## 2. Definitions

### 2.1 Partition and interface

In theory, the interface between two knots is "all information that can affect computation across the cut", a joining relation; its state is a finite set of variables. These may be point occupancy, liberties and connections of blocks, ko conditions, or, in other problems, variables that are not spatial at all. This experiment takes only the first implementation: the interface represented by shared points.


- Partition $P=\{K_1,\ldots,K_n\}$: an open area divided into knots of any size, shape and position.
- Interface $I(K_i,K_j)$: points shared by two knots, belonging to both; they may be empty, black, white or mixed.
- Junction: an interface point touching three or more knots. The adjacency of knots forms a hypergraph: pairwise contact gives edges, contact of three or more at a junction gives hyperedges.
- Seam knot $S$: all interface points taken together as one small knot. Under this convention each interface point is counted once.

### 2.2 Position and distribution

Knots of the same size have different numbers of neighbours in the centre, on the edge and in the corner, and hence different interface combinations. Knot size, position and number jointly determine the adjacency structure. The design treats these as experimental factors and does not assume any one is typical.

### 2.3 Interface state

Interface state $\sigma$: the current occupancy of interface points (empty, black, white) and the liberties of blocks attached to them. Interface width $w$ is the number of interface points.

## 3. Three composition methods and one certificate

**M0 Cut and add.** Assign interface points to the seam knot $S$. For each knot (including $S$), freeze the points of other knots (no play, current occupancy kept), compute local values, add, and read the score from the stops. Cheapest, and most likely to be wrong.

**M1 Insensitivity certificate.** For knot $A$, fix its interface points to each possible state (empty, black, white; $3^{w}$ states, or a sample) and compute $A$'s local value in each. If all values are equal, certify "$A$ is insensitive to its interface". If every knot is certified, accept M0's sum; otherwise merge the uncertified knot with its neighbours and recompute.

The certificate has no theoretical guarantee. In a game, both sides can fight for tempo on the interface, which fixing its state may not capture. Whether it is reliable is exactly what is tested.

**M2 Merged solution (ground truth).** Solve all knots together exactly.

**M3 Conditional value tables (exploratory).** For each knot, record its value for each interface state as a table; join the tables over possible interface states to obtain lower and upper bounds on the global result. Equal bounds give the exact value. Cost grows exponentially in interface width, corresponding to $|I|(L)$ in KBED.

**Adaptive rule (hypothesis).** If the interface is small, keep knots separate and join them with M1 or M3; once it grows so that $C_{\text{sep}}(A)+C_{\text{sep}}(B)+C_{\text{interface}}\geq C_{\text{merged}}(A\cup B)$, merge them into one knot. E4 measures the interface size at which this crossover occurs.

## 4. Experiments

### 4.1 Positions

- Frame: an open area enclosed by uncapturable walls; the frame may lie against the board edge or corner, giving centre, edge and corner positions.
- Open area of 8 to 12 points with a few stones; the whole area can be searched exhaustively.
- Virtual lines divide the area into 2 to 4 knots:
    - knot sizes vary (2 to 6 points);
    - interface width $w=1,2,3$;
    - interface occupancy: empty, one stone, stones of both colours;
    - with and without junctions.
- The same area is partitioned in several ways, to compare the effect of the partition itself.
- Ko excluded, as in the first round.

### 4.2 Measurements

| Measure | Content |
|---|---|
| E1 Exactness of cutting | Fraction where M0's score equals M2's, grouped by knot size, position, $w$, interface occupancy, junctions |
| E2 Reliability of the certificate | Among cases certified by M1, the fraction where M0 is wrong (certificate error rate, the key measure); and the fraction certified (coverage) |
| E3 Effect of the partition | Differences in E1 and E2 across partitions of the same area; whether a better partition can be identified in advance |
| E4 Cost | Search nodes of M0, M1, M2, M3 as $w$ and the number of knots vary; when separate-plus-interface cost exceeds merging |
| E5 Junctions | Whether errors concentrate on knots meeting at a junction, i.e., hyperedges (compare T3's three-region wall result) |

### 4.3 Criteria

- E2: M1 can be used as a basis for reuse only if its certificate error rate is zero. Otherwise record the types of error (tempo, connection, cutting, invasion, escape route, etc.) as items to add to the next certificate.
- E1, E3, E4 and E5 are measurements without pass or fail.

## 5. Relation to the first round

| Experiment | Interface | Composition | Result or question |
|---|---|---|---|
| T1, T2 | Empty (walls) | Sum | Exact |
| T3 | One shared object (a wall that can die) | Sum if premises hold, else merge | Exact when premises hold; detection trades misses against false alarms |
| v0.4 | Shared line, width 1–3, stones allowed | M0, M1, M3 against M2 | This document |

T3's D1 detectors ask "can the shared object be broken"; M1 asks the more general "is this knot sensitive to its interface state". D1 is the special case of M1 where the interface is a wall.

## 6. Known limits and open questions

1. M1 fixes the interface state and does not cover tempo fights on the interface; the certificate may be systematically optimistic.
2. How to define M3's bounds correctly in a game, where interface points are played alternately, is not settled; the first version is exploratory.
3. Open areas of 8 to 12 points are far from real game scale; the experiment shows only whether the methods work at small scale, and the types of error.
4. There are many partitions; the experiment samples them and cannot be exhaustive.
5. Partitions are fixed during play here. In practice a suitable partition may move, merge or be recut as the game develops; dynamic repartitioning is outside this version.

## 7. Questions for reviewers

1. Are there known counterexample types to M1's insensitivity certificate in games (e.g., tempo fights on the interface)? Is there a better definition?
2. In M3, how should tempo be handled when joining conditional tables in an alternating game? Is there existing theory (e.g., Müller and others on boundary conditions in local search)?
3. Does the seam-knot convention (interface points counted once) bias scoring relative to the definition "interface points belong to both sides"?
4. Do the experimental factors (size, position, width, occupancy, junctions, partition) miss anything important?
