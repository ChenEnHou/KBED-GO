# KBED Hierarchical Exact Computation: Theory and Validation Design v0.1

Oct 7, 2026 · Chen-En Hou

## 0. Scope

This document sets out a layered computation scheme (exact local computation → combination by value → merging where regions interact → move-by-move temperature maps) and proposes an experimental design for validating its correctness at small scale. No experiments are run here; the document is for review.

Where existing theory already covers a point, the source is given. The document claims no new mathematical result. It tests only whether the method is correct, not how much it saves in the middle game (Section 5).

## 1. Architecture

### 1.1 Three layers

| Layer | Object | Method |
|---|---|---|
| L0 Local | Knot: a region $R$ enclosed by a boundary $B$ | Solve exactly under each boundary condition; record the result as a conditional statement |
| L1 Combination | Mutually independent knots | Sum their combinatorial game values: $G=\sum_i G_i$ |
| L2 Interaction | Interacting knots | Merge into a larger local region and solve exactly; solve ko under a komaster assumption |

### 1.2 Representation of a knot

Each knot carries three channels:

1. Value $v(K)$: the reduced canonical form, used as the identifier for equivalence;
2. Temperature $t(K)$: computed from $v(K)$; the value of moving first in this region;
3. Credibility $c(K)\in\{\text{proved},\ \text{conditional},\ \text{estimated}\}$.

Merge rule:

$$v(K_1)=v(K_2),\quad c(K_1)=c(K_2)=\text{proved}\ \Rightarrow\ K_1,K_2\ \text{are interchangeable}$$

Knots that share temperature and mean but differ in value (for example $0$ and $\uparrow$) must not be merged.

### 1.3 Move-by-move temperature maps and colour difference

Along the move number $t$, each knot on the board is coloured by $(v,t,c)$, giving a map sequence $M_0,M_1,\ldots$. After each move:

1. Recompute the knot in which the move was played;
2. Compute the colour difference $\Delta M_t=M_{t+1}-M_t$;
3. If $\Delta M_t$ appears only in the knot where the move was played, treat it as a local change; if it appears in other knots, the regions interact and must be merged and recomputed (L2).

### 1.4 Combination map of local outcomes (diagnostic)

Let $O_i$ be the possible outcomes of knot $i$. The feasible combinations are

$$\mathcal{F}=\{(o_1,\ldots,o_n)\in O_1\times\cdots\times O_n:\ \text{constraints between regions hold}\}$$

Constraints include capturing races (if one side lives the other dies), ko (only one side wins it), and the parts of one dragon living or dying together. Enumerate over $\mathcal{F}$ and compare global results:

- Influence of a single knot: the change in the global result when only $o_i$ changes;
- Interaction: the effect of $o_i$ depends on $o_j$.

The map describes "what the whole board looks like if each region ends with these outcomes". It contains no tempo exchange, so the winner cannot be read from it directly; the winner is decided by the game computation in L1 and L2.

## 2. Existing theory

| Claim | Source | Conditions |
|---|---|---|
| A local position can be represented by a value; the outcome of a sum is determined by the values | Combinatorial game theory (Conway; Berlekamp, Conway & Guy) | Regions independent |
| $G=H\iff G-H$ is a second-player win; equal values are interchangeable in any sum | Fundamental theorem of CGT (normal play) | Same |
| Go endgames map to CGT values | Berlekamp & Wolfe, *Mathematical Go* | Territory scoring, no ko, regions independent with safe boundaries |
| Combining local values solves endgames exactly; endgames of over 60 moves solved | Müller, decomposition search (1999) | Same |
| Ko can be valued given who holds the ko threats | Berlekamp's komaster; Müller, Berlekamp & Spight, generalized thermography (1996) | Komaster or threat situation must be specified |
| Basic types of capturing race can be decided by counting liberties and eyes | Müller (1999) | Limited to the analysed types |
| Life and death can be proved by static rules or local search | Benson (1976); Kishimoto & Müller (2005) | — |

The correspondence in row three, with its conditions, is the main object of this validation. CGT theorems hold under normal play; applying them to scored Go endgames requires the Berlekamp–Wolfe correspondence. Experiments T1 and T2 check whether that correspondence holds on our positions.

## 3. Validation design

### 3.1 Positions

- 7×7 or 9×9 board, with black and white groups already proved alive acting as walls that separate 2 to 5 regions;
- 2 to 6 empty points per region, possibly with a few stones; no more than 12 to 14 empty points on the whole board, so the full board can be searched exhaustively;
- Territory scoring (Japanese), to match the Berlekamp–Wolfe setting;
- No ko in the first round: positions in which ko arises during search are removed and logged separately;
- Positions generated at random, plus positions with known answers from Berlekamp & Wolfe as controls;
- Both sides to move are tested.

### 3.2 Baseline

Full exhaustive search of the whole board (minimax with a transposition table), giving the exact final score difference and the set of all optimal first moves.

### 3.3 Experiments

**T1: Correctness of summation**

- Method: value and reduce each region separately; sum, then determine the global result and the best first move.
- Criterion: the score difference agrees with the baseline on every position; the first move chosen by decomposition belongs to the baseline's set of optimal moves.
- Falsification: a single disagreement means the correspondence conditions or the implementation are wrong; stop and diagnose.

**T2: Correctness of substitution**

- Method: collect pairs of regions $(A,B)$ with equal value but different shape and size, plus a control group with different values; replace $A$ by $B$ in several whole-board contexts and compare by exhaustive search.
- Criterion: for equal-value pairs, the result is unchanged in every context; for different-value pairs, the result changes in at least one context.
- Falsification: an equal-value pair changes the result, meaning "equal values may be merged" does not hold in this setting.

**T3: Colour difference as an interaction detector**

- Method:
    1. Independent case: compute temperature maps and colour differences move by move along optimal play; check that colour difference appears only in the region where the move was played;
    2. Interacting case: construct positions where regions share cutting points, share liberties, or can supply ko threats to each other; check whether colour difference appears in other regions.
- Criterion: no false alarms in the independent case (colour difference only in the moved region); record the detection rate in the interacting case.
- Falsification: false alarms in the independent case, or most interactions undetected.

**T4: Cost**

- Method: compare search nodes and wall-clock time of full search versus decomposition, grouped by number of regions and number of empty points.
- Criterion: a measurement, with no pass or fail; it shows how much decomposition saves in the endgame.

**T5: Combination map (exploratory)**

- Method: for each position, list each region's possible outcomes and constraints; compute each region's influence and pairwise interactions over the feasible combinations.
- Check: whether the most influential region coincides with the region of the best first move in T1, or with the hottest region.
- Criterion: exploratory, with no pass or fail.

### 3.4 Second round (after the first round passes)

1. Add ko: value it under a komaster assumption and compare with full search under the same rules.
2. Switch to area scoring: handle the one-move parity difference from territory scoring.
3. Add seki and other special outcomes.

## 4. Interpretation

| Result | Meaning |
|---|---|
| T1 and T2 agree everywhere | Hierarchical exact computation is correct on independent endgames; equal colour (value) allows merging |
| Any disagreement in T1 or T2 | The correspondence conditions or the implementation are wrong; the scheme must not be used until the cause is found |
| T3: no false alarms when independent, high detection when interacting | Colour difference can serve as an interaction detector |
| T3: many false alarms or misses | Colour difference is only an aid; interaction must be decided by structural analysis |

## 5. Outside the scope of this validation

1. Savings in the middle game: depends on how many local regions in the middle game can be proved independent; small experiments cannot answer this.
2. Recurrence at the knot level: how often knots of equal value recur across large numbers of games.
3. "Moves outside known patterns arise in decisive regions or at points of interaction": a hypothesis; T5 gives only preliminary hints.

## 6. Questions for reviewers

1. Section 2, row three: does the Berlekamp–Wolfe correspondence hold fully in this setting (territory scoring, no ko, safe boundaries, prisoners counted)? Are there cases needing separate treatment (for example the last move, or dame)?
2. T1 criterion: is comparing the score difference and the best first move enough, or should the full set of optimal lines be compared?
3. T3: is "colour difference appears only in the moved region" sufficient in theory to establish independence? Could there be interaction with zero colour difference?
4. Does the position generator bias toward easy cases? How should hard control positions be added?
5. Does excluding ko and seki in the first round make the conclusions too optimistic?

## References

- Benson, D. B. Life in the Game of Go. Information Sciences 10(2), 17–29, 1976.
- Berlekamp, E. R. The Economist's View of Combinatorial Games. In Games of No Chance, MSRI Publications 29, 1996.
- Berlekamp, E. R., Conway, J. H., & Guy, R. K. Winning Ways for Your Mathematical Plays. Academic Press, 1982.
- Berlekamp, E. R., & Wolfe, D. Mathematical Go: Chilling Gets the Last Point. A K Peters, 1994.
- Conway, J. H. On Numbers and Games. Academic Press, 1976.
- Kishimoto, A., & Müller, M. Search versus Knowledge for Solving Life and Death Problems in Go. AAAI 2005.
- Müller, M. Decomposition Search: A Combinatorial Games Approach to Game Tree Search, with Applications to Solving Go Endgames. IJCAI 1999.
- Müller, M. Race to Capture: Analyzing Semeai in Go. Game Programming Workshop, 1999.
- Müller, M., Berlekamp, E., & Spight, B. Generalized Thermography: Algorithms, Implementation, and Application to Go Endgames. ICSI Technical Report TR-96-030, 1996.
