# KBED 研究地圖

Oct 7, 2026 · Chen-En Hou

## 0. 目的

本文件標定 KBED 與 Ring 在整體研究中的位置，列出各層的既有理論、KBED 已得的結論與未答的問題，並設定後續工作的停損點。本文件不修改任何既有版本，也不提出新結果。

## 1. 研究樹

| 層級 | 問題 |
|---|---|
| 原始問題 | 生成不應以 $P(x_{t+1}\mid x_{\le t})$ 作為決定真假的主要機制 |
| 架構 | 先建立世界允許什麼，再於其中搜尋、推理與驗證：A → B → C → D → E |
| KBED | C 層：完整空間太大時，100% 涵蓋是否必須逐一獨立計算 |
| Ring | KBED 內：重複的計算在何處，能否以結構表示而不逐一推導 |
| E12 | Ring 內：在規則完全已知的有限系統上，Ring 相對既有基準有無額外計算價值 |

架構的五層：

| 層 | 內容 |
|---|---|
| A | 世界表示與約束獲取 |
| B | 可行空間的建構 |
| C | 精確的結構計算 |
| D | 不確定下的優先排序 |
| E | 驗證與輸出 |

圍棋、五子棋、四子棋是 C 層的實驗環境：規則、狀態、終局與狀態相等皆已知，空間已足夠大，且可建立精確基準。現實世界的困難與此不同：

$$\text{圍棋：規則已知，空間巨大}$$

$$\text{現實世界：空間巨大，規則不完整，狀態部分可觀測，邊界不確定}$$

## 2. 各層的既有理論與未答問題

| 層 | 既有理論（舉例） | KBED 的貢獻 | 未答問題 |
|---|---|---|---|
| A | 約束獲取（Bessiere 等）；因果模型 | 無 | 約束從何而來；如何知道漏了變數 |
| B | 以語言模型將問題轉為約束或程式，再交由求解器（Logic-LM；SatLM；PAL）；規劃中的目標回歸 | 無 | 規則不完整時如何建構可行空間；由問題回推所需約束 |
| C | 符號式模型檢查；retrograde；bisimulation 商；組合式最小化；IC3／PDR；對局求解 | 見第 3 節 | Ring 在既有基準之外有無額外價值（E12） |
| D | bisimulation metric（Ferns、Panangaden 與 Precup）；因果抽象（Rubenstein 等；Beckers 與 Halpern） | 第 4 節的定位 | 近似等價的誤差界與修正；機率進入的層級 |
| E | 程式驗證；證明檢查 | 證明與還原的區分 | 沒有 ground truth 時如何驗證 |

A、B、D、E 層的既有理論只是初步舉例，尚未做完整的文獻定位。

## 3. KBED 已得、可轉移的結論

以下結論來自 KBED v1.9 與 Ring 筆記 v0.1、v0.2、v3.0，均屬 C 層：

1. 完整涵蓋不要求逐一獨立推導。盤面對稱優先展開已實證此點，但屬既有方法。
2. 展開前可精確辨認的等價，除可證明的結構（盤面對稱、Benson 類條件）外，目前未找到。事後的 bisimulation 顯示約 35% 的額外冗餘，但無法減少第一階段的展開。
3. 重用是否划算取決於 $C_{recognize}$ 與 $C_{derive}$ 的比較。圍棋的區塊映射成本高於推導，為負面結果；此即 utility problem。
4. 「全部算完」必須連同查詢成本定義，否則規則本身就是平凡的完整解。
5. 反向計算需要的是目標條件，不必是終局狀態。合作語意與對抗語意提供不同的可壓縮結構。
6. 單調系統的「棋子不消失」直接給出排除證明。
7. Ring v3.0 的計算機制，在既有文獻中皆已有。剩下的是問題表述（多查詢、三成本、區域解析度）與結構刻畫（哪些系統性質決定精確可壓縮性）。

## 4. 機率的位置

第 3 節第 2 點：在規則完全已知的系統中，「哪些情況可視為同一個」都難以在展開前精確證明；在規則不完整的現實世界中，只能近似，且須可修正。由此得到一個定位，目前只是假設：

$$\text{機率表示的是約束與等價的不確定性，而非答案的產生機制}$$

即機率位於 D 層，作用於「哪些約束成立」「哪些情況可視為等價」，而不作為逐步生成內容的主要機制。bisimulation metric 將 $\equiv_F$ 推廣為未來行為的距離，因果抽象處理兩個系統何時可視為同一因果結構，兩者是此定位最接近的既有理論。

## 5. 後續工作與停損點

| 工作 | 層 | 目的 | 停損點 |
|---|---|---|---|
| E12（$G(m,n,k)$） | C | 確定 Ring 在最有利的系統上有無額外計算價值 | 若不優於盤面對稱、retrograde 與 BDD 基準，結束 Ring 作為新計算方法的研究；不進入四子棋與圍棋 |
| A、B、D 層的文獻定位 | A、B、D | 確認原始問題中哪一部分真正尚未回答 | 在提出新架構之前完成 |
| E8（圍棋的 $\mathcal{O}(s)$） | C | 圍棋專屬的診斷 | 擱置，除非繼續發展圍棋專屬的表示 |

E12 的結果只決定 Ring 作為有限精確計算方法是否值得繼續，不決定原始架構問題，也不影響第 4 節的定位。

## 6. 文件譜系

| 文件 | 層 | 狀態 |
|---|---|---|
| KBED Methodology v1.8 | C | 凍結的中間版本 |
| KBED Methodology v1.9 | C | 第一階段的穩定版本 |
| Ring 探索筆記 v0.1：結構等價 | C | 完成 |
| Ring 探索筆記 v0.2：計算目標與三成本模型 | C | 完成 |
| Ring 探索筆記 v3.0：雙向多解析度結構 | C | 完成；E12 待執行 |
| 本研究地圖 | 全部 | 新增 |

## 參考資料

- Beckers, S., & Halpern, J. Y. Abstracting Causal Models. AAAI 2019. https://ojs.aaai.org/index.php/AAAI/article/view/4117
- Bessiere, C., Coletta, R., Koriche, F., & O'Sullivan, B. A SAT-Based Version Space Algorithm for Acquiring Constraint Satisfaction Problems. ECML 2005. https://doi.org/10.1007/11564096_8
- Ferns, N., Panangaden, P., & Precup, D. Metrics for Finite Markov Decision Processes. UAI 2004. https://arxiv.org/abs/1207.4114
- Gao, L., et al. PAL: Program-aided Language Models. ICML 2023. https://proceedings.mlr.press/v202/gao23f.html
- Pan, L., Albalak, A., Wang, X., & Wang, W. Y. Logic-LM: Empowering Large Language Models with Symbolic Solvers for Faithful Logical Reasoning. Findings of EMNLP 2023. https://arxiv.org/abs/2305.12295
- Rubenstein, P. K., Weichwald, S., Bongers, S., Mooij, J. M., Janzing, D., Grosse-Wentrup, M., & Schölkopf, B. Causal Consistency of Structural Equation Models. UAI 2017.
- Ye, X., Chen, Q., Dillig, I., & Durrett, G. SatLM: Satisfiability-Aided Language Models Using Declarative Prompting. NeurIPS 2023. https://arxiv.org/abs/2305.09656
- C 層的參考資料見 KBED Methodology v1.9 與 Ring 探索筆記 v3.0。
