# KBED Ring Computational Target and Three-Cost Model: Exploratory Note v0.2

Oct 7, 2026 · Chen-En Hou

## 0. Scope and Limits

This note continues Exploratory Note v0.1 and is independent of KBED Methodology v1.9: it does not modify v1.9, runs no new experiments, and proposes no new theorems. It covers three things:

1. fixing KBED's computational target and its queries;
2. comparing exact representations by their build, storage, and query costs;
3. placing the Ring's mechanisms in a single computational process, and designing candidate experiments (not run).

This note does not adopt a game-solving target. Neither the value of the initial position with a winning strategy (a weak solution) nor the win/draw/loss value of every state is KBED's target.

## 1. Computational Target

### 1.1 Target

$$T_\Gamma^{implicit}:\ \text{exactly represent the complete reachable transition structure and terminal relation from }s_0$$

Every reachable state, event, and path, and the complete future of every state, must be exactly queryable; none needs to be materialized individually in advance. Board-symmetry quotienting is an instance of this principle: the states quotiented away do not exist individually but are reconstructed exactly from a representative and a transformation $g$, and this has been accepted as complete coverage.

### 1.2 Queries

| Query | Definition |
|---|---|
| $q_1$ Reachability | $s\in S_{reach}$? |
| $q_2$ Successors | $Succ(s)$, $Out(t)$ |
| $q_3$ Terminal relation | $\mathcal{O}(s)$ |

where

$$\mathcal{O}(s)=\{\,t\in T:\ s\rightarrow^{*}t\,\}\ \cup\ \{\infty\ \text{if an infinite path starts at }s\}$$

$\mathcal{O}(s)$ keeps the terminal states themselves, from which scores follow by $Out$; $\infty$ marks the possibility of infinite play (a draw under $R_0$). Keeping only the results gives

$$\mathcal{O}_{Out}(s)=Out\big(\mathcal{O}(s)\setminus\{\infty\}\big)\cup\big(\mathcal{O}(s)\cap\{\infty\}\big)$$

$q_1$ cannot be dropped: $\delta$ gives successors, not reachability. Whether every legal position is reachable under $R_0$ is unknown and is not assumed.

### 1.3 Structure of $\mathcal{O}$

$$\mathcal{O}(t)=\{t\}\quad(t\in T),\qquad \mathcal{O}(s)=\bigcup_{s'\in Succ(s)}\mathcal{O}(s')\ \cup\ \Big(\{\infty\}\ \text{if }s\text{ reaches a cycle}\Big)$$

- The terminal part is the least fixed point of this equation. $\infty$ is decided by strongly connected components: $\infty\in\mathcal{O}(s)$ if and only if $s$ reaches a strongly connected component containing a cycle (Tarjan).
- States in the same strongly connected component reach one another and therefore have the same $\mathcal{O}$. This is an exact equivalence for $q_3$ and existing theory, but it requires $\Gamma$ first.
- Relation to $\equiv_F$: bisimulation preserves $Out$ at terminals, so $s\equiv_F s'\Rightarrow\mathcal{O}_{Out}(s)=\mathcal{O}_{Out}(s')$. The converse fails, so equivalence under $\mathcal{O}_{Out}$ can be coarser than $\equiv_F$.

### 1.4 Game Values as Derived Queries

$V(s)$ is obtained from $(\Gamma,Out)$ by retrograde analysis and is a derived query. It cannot be obtained from $\mathcal{O}(s)$ alone: let $A$ and $B$ each have exactly two successors, $t_1$ (Black wins) and $t_2$ (White wins), with Black to move at $A$ and White to move at $B$. Then

$$\mathcal{O}(A)=\mathcal{O}(B)=\{t_1,t_2\},\qquad V(A)\neq V(B)$$

$V$ depends on who chooses where, that is, on the structure of $\Gamma$, not only on the set of reachable terminals. $T_\Gamma^{implicit}$ must therefore keep the transition structure represented by $q_2$ and cannot replace it with $\mathcal{O}$.

### 1.5 Non-Trivial Content

$$\text{non-trivial content}=\text{reachable structure}\ (q_1)\ +\ \text{future/terminal relation}\ (q_3)$$

$q_2$ is given locally by $\delta$, but the structure, recurrence, and dependency studied in the Ring are all built on the reachable transition structure.

## 2. Three-Cost Model

### 2.1 Definition

The cost of an exact representation $D$ is

$$\big(C_B(D),\ C_S(D),\ C_Q(D)\big)$$

for build, storage, and query. $C_Q$ is taken as an expectation or a maximum over a query workload $W$ (a distribution over $Q$):

$$C_Q(D)=\mathbb{E}_{q\sim W}\big[cost_D(q)\big]\quad\text{or}\quad\max_{q\in W}cost_D(q)$$

### 2.2 Admissible Representations

The representation made of the rules alone, $D_0=(s_0,\delta)$, is exact and complete, with $C_B=0$ and $C_S=O(1)$, but every $q_3$ query re-expands the entire future. Such degenerate representations are excluded:

$$cost_D(q)\ll cost_{D_0}(q)\qquad(q\in W)$$

Beyond this, no query-cost bound $c_q$ is fixed in advance. Requiring $c_q=O(1)$ effectively demands near-complete materialization and would rule out the trade-offs this note sets out to study. $c_q$ is set later for each application.

### 2.3 Pareto Frontier

$$\mathcal{P}=\operatorname{Pareto}\big\{(C_B,C_S,C_Q)(D):\ D\ \text{exact, complete, admissible}\big\}$$

KBED's computational question becomes:

$$\text{Is there an exact representation }D\text{ that dominates, or adds to, full materialization and symmetry-only representation on }\mathcal{P}\text{?}$$

$|S/\!\sim|$ is just one coordinate of $C_S$ under quotienting, not the sole measure.

### 2.4 Lower Bounds

- The cost of a query enumerating $\mathcal{O}(s)$ is at least the output size $|\mathcal{O}(s)|$, unless the answer itself is given in a set representation such as a BDD.
- Storing $\mathcal{O}$ explicitly for every state takes $\sum_{s}|\mathcal{O}(s)|$ space, $|S|\cdot|T|$ in the worst case; this amounts to materializing a transitive closure.

### 2.5 Representation Points

| Representation | $C_B$ | $C_S$ | $C_Q(q_3)$ |
|---|---|---|---|
| $D_0$, rules alone (excluded) | 0 | $O(1)$ | Entire future |
| Materialized $\Gamma$ | $(\lvert S\rvert+\lvert E\rvert)\,c_\delta$ | $\lvert S\rvert+\lvert E\rvert$ | Search of the reachable subgraph |
| Materialized $\Gamma$ and $\mathcal{O}$ | Plus transitive closure | Plus $\sum_s\lvert\mathcal{O}(s)\rvert$ | Lookup |
| DAG of strongly connected components | Plus $O(\lvert S\rvert+\lvert E\rvert)$ | Depends on number of components | Search on the DAG |
| Reachability index (2-hop, etc.) | Index construction | Label size | Label comparison |
| Board-symmetry quotient | ÷ about $\lvert G\rvert$, plus canonicalisation | ÷ about $\lvert G\rvert$ | Plus canonicalisation |
| Region summaries (A, knots) | Lower when hits are frequent and $C_{recog}<C_{derive}$ | Lower | Plus composition |
| Deferred nodes (C) | See Section 4 | Lower | Plus $O(b^k)$ |
| Set-wise BDD | Set operations | BDD size | Depends on number of variables |

## 3. The Role of the Ring

The Ring is not a search for the smallest state quotient. It decides where the complete future structure is materialized, summarized, mapped, or deferred. Let $\{R_j\}$ be a partition of $S_{reach}$ into regions (for example by layer or by knot), and let the placement be

$$\Lambda:\ R_j\mapsto\{\mathrm{M},\ \Sigma,\ \Phi,\ \mathrm{D}\}$$

namely materialize, summarize, map, defer. The cost is approximately the sum over regions plus terms for dependencies between regions, for example that a mapping can be used only once its summary is complete:

$$C_X(\Lambda)\approx\sum_j C_X\big(R_j,\Lambda(R_j)\big)+C_X^{dep}(\Lambda),\qquad X\in\{B,S,Q\}$$

Choosing $\Lambda$ is a multi-objective optimization. Materialized-view selection in databases (Harinarayan, Rajaraman, and Ullman) is an existing problem of the same type: deciding which views to materialize under a storage limit so as to lower query cost; it is NP-hard in general and has greedy approximations.

## 4. Computational Process and Mechanisms

### 4.1 Computational Process

The computation is written as a fixed-point iteration over state labels:

$$st:\ S\rightarrow\{\text{unknown},\ \text{expanded},\ \text{complete},\ \text{mapped}(\Phi,s'),\ \text{deferred}\}$$

Operators: Expand (forward $\delta$), Map (quotienting and history-segment reuse), Close (propagation of $\mathcal{O}$), Defer. The order in which they are applied is the schedule. When every operator preserves exactness, the result does not depend on the order (chaotic iteration, Cousot); the cost does.

### 4.2 Effect of Each Mechanism

| Mechanism | $C_B$ | $C_S$ | $C_Q$ | Conditions and remarks |
|---|---|---|---|---|
| Board symmetry | Lower | Lower | Slightly higher | Demonstrated; positive control |
| Quotients $\sim_{S,f}$, $\equiv_F$, strongly connected components | Lower only if recognizable before expansion | Lower | Plus mapping | Post-hoc quotients lower only $C_S$ |
| A, history segments $\approx$ (following v0.1) | Lower when $C_{recog}<C_{derive}$ | Lower | Plus composition | Definition in Section 4.3 |
| B, Close | Unchanged alone | — | — | See Section 4.4 |
| C, Defer | Unchanged alone | Lower | Higher | See Section 4.5 |
| E, scheduling | Unchanged alone | Peak changes | — | See Section 4.6 |
| BDD | Depends on BDD size | Depends on BDD size | Depends on number of variables | See Section 4.7 |

### 4.3 A: History-Segment Reuse

A history segment is a labelled dependence graph:

$$H=(E_H,\ \le_H,\ \lambda_H,\ R(H),\ W(H))$$

$\le_H$ is the dependence order on events, $\lambda_H:E_H\rightarrow\mathcal{T}/\!\equiv_T$ assigns transformation classes, and $R(H)$ and $W(H)$ are the parts of the state read and changed. $H_A\approx H_B$ if there are a bijection $\Phi$ preserving $\le$ and $\lambda$ and a board transformation $g$ such that

$$g\big(R(H_A)\big)=R(H_B),\qquad s_B|_{R(H_B)}=g\big(s_A|_{R(H_A)}\big)$$

When $R(H)$ has been proven sufficient, $\Delta(H_B)=g(\Delta(H_A))$. All events and move numbers are kept; only the derivation of the effect is reused. Segments of length 0 and 1 give state equivalence and $\equiv_T$; identical events differing only in order give $\sim_T$; the block reuse of Appendix A.11.2 is the special case of linear segments, with a negative result. The corresponding existing theory is the Concurrency and Embedding/Extension Theorems of graph transformation, procedure summaries in program analysis, explanation-based generalization and macro-operators, and the utility problem (Minton).

### 4.4 B: Close

$\mathcal{O}$ propagates under

$$\mathcal{O}(s)\ \text{complete}\iff\forall s'\in Succ(s):\ \mathcal{O}(s')\ \text{complete}$$

(cycles are handled per strongly connected component). Unlike the computation of $V$, $\mathcal{O}$ requires every branch: knowing the result of one branch does not allow the others to be skipped. Close by itself therefore fixes only the order of propagation and saves no derivation. If Close can give an exact summary or certificate for an entire unexpanded region, it belongs to A or Defer and may lower the build cost.

### 4.5 C: Defer

Under $R_0$ every non-terminal state can pass, so its out-degree is at least 2. Skipping intermediate states without computing them is exact only when the entire skipped region, all branches included, already has a summary, that is, through A or knot decomposition. Defer by itself therefore lowers $C_S$ and raises $C_Q$; lowering $C_B$ requires summaries. Syzygy tablebases store positions with a winning capture as "don't care" and recover them at query time by a capture search; this is an existing instance of lowering storage, and the complete table must still be built first.

### 4.6 E: Scheduling

Without reuse, scheduling affects only the intermediate size $W_{\max}$. When the reuse units are composite (region summaries, macros, closure certificates), a unit can be applied only once it is complete; the schedule decides how early it becomes available and thus changes $N_{indep}$. With reuse by step-wise memoization of canonical contexts, the first instance creates the table entry, and the schedule does not affect the number of derivations. Saturation in symbolic state-space generation (Ciardo et al.) is an existing example in which the schedule alone changes intermediate sizes substantially.

### 4.7 Set-Wise Computation with BDDs

Set-wise computation handles a batch of states with one symbolic operation, so its work is not counted state by state (Burch et al.); it is a separate exact and complete baseline. Its cost depends on BDD size and variable order (Bryant). For Connect Four, the set of reachable states has polynomial-size BDDs, while the termination condition requires exponential size under every variable order (Edelkamp and Kissmann). Capture in Go is non-local, and there are no data on the BDD sizes for Go.

## 5. Existing Theory

| Question | Existing theory | Use for KBED | What does not carry over directly |
|---|---|---|---|
| Query/storage trade-off for $q_1$, $q_3$ | Transitive-closure compression (Agrawal, Borgida, and Jagadish); 2-hop labels (Cohen et al.) | Query indexes once $\Gamma$ is materialized | Requires $\Gamma$ first; does not lower $C_B$ |
| Cycles in the terminal relation | Strongly connected components (Tarjan) | Deciding $\infty$; equal $\mathcal{O}$ within a component | Obtained post hoc |
| Placement | Materialized-view selection (Harinarayan et al.) | $\Lambda$ in Section 3 | Dependencies between views differ |
| Fixed points and scheduling | Chaotic iteration (Cousot); saturation (Ciardo et al.) | Order-independent result, order-dependent cost | Limited event locality in Go |
| History-segment reuse | Graph transformation; procedure summaries (Reps, Horwitz, and Sagiv); EBG; utility problem | A | Non-local capture condition; recognition cost |
| Deferral and reconstruction | Syzygy "don't care" encoding | C | Complete table built first |
| Set-wise computation | Symbolic model checking (Burch et al.); BDDs (Bryant); Edelkamp and Kissmann | Baseline route | BDD sizes for Go unknown |

## 6. Candidate Experiments (Not Run)

### E4: History-Segment Reuse

- Hypothesis: on the 3×3 $\Gamma$, segments of length $k$ defined by dependence graphs and minimal read sets have far fewer classes than occurrences, and their number grows with $k$ more slowly than the linear blocks of Appendix A.11.2.
- Exactness criterion: $\Delta$ of every occurrence agrees with its class representative.
- Baseline: the linear blocks of Appendix A.11.2.
- Metrics: number of classes, hit rate, recognition operations ÷ derivation operations.
- Falsification: the number of classes also grows by about a factor of 9 per step, or $C_{recog}\ge C_{derive}$.

### E5: Pareto Points

- Hypothesis: besides full materialization and symmetry-only representation, there are exact representations that are not dominated.
- Exactness criterion: under a fixed query workload, every answer agrees with the materialized $\Gamma$ and $\mathcal{O}$.
- Baselines: materialized $\Gamma$; materialized $\Gamma$ with board symmetry.
- Metrics: $(C_B,C_S,C_Q)$ of each representation; distributions of $|\mathcal{O}(s)|$ and $|\mathcal{O}_{Out}(s)|$; number and sizes of strongly connected components.
- Falsification: every candidate representation is dominated by materialized $\Gamma$ with board symmetry.

### E6: Scheduling

- Hypothesis: in computations with composite reuse units, different schedules differ substantially in $N_{indep}$ and $W_{\max}$.
- Exactness criterion: all schedules give the same final result.
- Baseline: forward expansion layer by layer.
- Metrics: $N_{indep}$, $W_{\max}$, total operations.
- Falsification: all schedules have the same $N_{indep}$ and differ only in $W_{\max}$.

### E7: BDD Sizes

- Hypothesis: for some variable orders, the BDDs of $S_{reach}$, of the layers $L_t$, or of the sets $\mathcal{O}$ are far smaller than explicit storage.
- Exactness criterion: the sets represented by the BDDs agree element by element with the explicit sets.
- Baseline: explicit storage.
- Metrics: BDD node counts under each variable order; total cost of the set operations.
- Falsification: under every tested variable order, the BDD node count is no smaller than explicit storage.

## 7. Relation to v0.1 and v1.9

- The spatial and temporal axes of v0.1 are Map operators in this model; history segments $\approx$ generalize Map.
- L1 in v1.9 says "obtained exactly through $\phi$" without a query cost; L2 is stated in terms of states and computation. Both can later be restated as dominance on $\mathcal{P}$. This note does not modify v1.9.
- Among the falsification conditions in Section 13 of v1.9, $\rho\rightarrow1$ concerns only the quotient coordinate; under this model, falsification requires that no representation on $\mathcal{P}$ improve on the baselines.
- The version criterion is unchanged: KBED 2.0 is considered only if a theory of combining computation-dependent representations emerges, or if a result on $\mathcal{P}$ improves on the baselines.

Open questions:

1. Whether every legal position is reachable under $R_0$.
2. The size of $|\mathcal{O}(s)|$, and how much coarser equivalence under $\mathcal{O}_{Out}$ is than $\equiv_F$.
3. Whether the placement $\Lambda$ can exploit the structure of layers or knots instead of a general multi-objective search.
4. Whether Go admits representations beyond board symmetry that are not dominated on $\mathcal{P}$.

## References

- Agrawal, R., Borgida, A., & Jagadish, H. V. Efficient Management of Transitive Relationships in Large Data and Knowledge Bases. SIGMOD 1989, 253–262.
- Bryant, R. E. Graph-Based Algorithms for Boolean Function Manipulation. IEEE Transactions on Computers C-35(8), 677–691, 1986.
- Burch, J. R., Clarke, E. M., McMillan, K. L., Dill, D. L., & Hwang, L. J. Symbolic Model Checking: 10^20 States and Beyond. Information and Computation 98(2), 142–170, 1992.
- Ciardo, G., Lüttgen, G., & Siminiceanu, R. Saturation: An Efficient Iteration Strategy for Symbolic State-Space Generation. TACAS 2001, LNCS 2031, 328–342.
- Cohen, E., Halperin, E., Kaplan, H., & Zwick, U. Reachability and Distance Queries via 2-Hop Labels. SIAM Journal on Computing 32(5), 1338–1355, 2003. https://doi.org/10.1137/S0097539702403098
- Cousot, P. Asynchronous Iterative Methods for Solving a Fixed Point System of Monotone Equations in a Complete Lattice. Research Report R.R. 88, IMAG, Grenoble, 1977.
- de Man, R. Description of the Syzygy WDL encoding. TalkChess, 2013. https://talkchess.com/viewtopic.php?p=514499
- Edelkamp, S., & Kissmann, P. On the Complexity of BDDs for State Space Search: A Case Study in Connect Four. AAAI 2011. https://ojs.aaai.org/index.php/AAAI/article/view/7821
- Ehrig, H., Ehrig, K., Prange, U., & Taentzer, G. Fundamentals of Algebraic Graph Transformation. Springer, 2006.
- Harinarayan, V., Rajaraman, A., & Ullman, J. D. Implementing Data Cubes Efficiently. SIGMOD 1996, 205–216.
- Minton, S. Quantitative Results Concerning the Utility of Explanation-Based Learning. Artificial Intelligence 42(2–3), 363–391, 1990.
- Mitchell, T. M., Keller, R. M., & Kedar-Cabelli, S. T. Explanation-Based Generalization: A Unifying View. Machine Learning 1(1), 47–80, 1986.
- Reps, T., Horwitz, S., & Sagiv, M. Precise Interprocedural Dataflow Analysis via Graph Reachability. POPL 1995, 49–61.
- Tarjan, R. E. Depth-First Search and Linear Graph Algorithms. SIAM Journal on Computing 1(2), 146–160, 1972.
