# KBED Ring 計算目標與三成本模型：探索筆記 v0.2

Oct 7, 2026 · Chen-En Hou

## 0. 範圍與限制

本筆記延續探索筆記 v0.1，獨立於 KBED Methodology v1.9：不修改 v1.9，不執行新實驗，不提出新定理。內容限於三項：

1. 固定 KBED 的計算目標與查詢；
2. 以建構、儲存、查詢三種成本比較精確表示；
3. 將 Ring 的各機制放入同一計算過程，並設計候選實驗（不執行）。

本筆記不採 game solving 的目標。初始局面的值與必勝策略（weak solution）、或只求各狀態的勝和負，均不是 KBED 的目標。

## 1. 計算目標

### 1.1 目標

$$T_\Gamma^{implicit}:\ \text{精確表示從 }s_0\text{ 起完整的可達轉移結構與終局關係}$$

要求所有可達的狀態、事件與路徑，以及每一狀態的完整未來，皆可精確查詢；不要求每一項預先個別物化。盤面對稱商化即為此原則的實例：被商掉的狀態未個別存在，而以代表元與變換 $g$ 精確還原，此已被接受為完整涵蓋。

### 1.2 查詢

| 查詢 | 定義 |
|---|---|
| $q_1$ 可達性 | $s\in S_{reach}$？ |
| $q_2$ 後繼 | $Succ(s)$、$Out(t)$ |
| $q_3$ 終局關係 | $\mathcal{O}(s)$ |

其中

$$\mathcal{O}(s)=\{\,t\in T:\ s\rightarrow^{*}t\,\}\ \cup\ \{\infty\ \text{若自 }s\text{ 起存在無限路徑}\}$$

$\mathcal{O}(s)$ 保留終局狀態本身，可由 $Out$ 得到計分；$\infty$ 表示可無限延續（依 $R_0$ 判和）。只保留結果時記為

$$\mathcal{O}_{Out}(s)=Out\big(\mathcal{O}(s)\setminus\{\infty\}\big)\cup\big(\mathcal{O}(s)\cap\{\infty\}\big)$$

$q_1$ 不可省略：$\delta$ 給出後繼，不給出可達性。$R_0$ 下合法盤面是否皆可達，目前未知，不作假設。

### 1.3 $\mathcal{O}$ 的結構

$$\mathcal{O}(t)=\{t\}\quad(t\in T),\qquad \mathcal{O}(s)=\bigcup_{s'\in Succ(s)}\mathcal{O}(s')\ \cup\ \Big(\{\infty\}\ \text{若 }s\text{ 可達一循環}\Big)$$

- 終局部分為上式的最小不動點。$\infty$ 由強連通分量判定：$\infty\in\mathcal{O}(s)$ 當且僅當 $s$ 可達一個含循環的強連通分量（Tarjan）。
- 同一強連通分量中的狀態彼此可達，故 $\mathcal{O}$ 相同。這是對 $q_3$ 精確、且為既有理論的等價，但需先有 $\Gamma$。
- 與 $\equiv_F$ 的關係：bisimulation 保持終局的 $Out$，故 $s\equiv_F s'\Rightarrow\mathcal{O}_{Out}(s)=\mathcal{O}_{Out}(s')$。反向不成立，因此 $\mathcal{O}_{Out}$ 的等價可比 $\equiv_F$ 粗。

### 1.4 博弈值為衍生查詢

$V(s)$ 可由 $(\Gamma,Out)$ 以 retrograde 求得，屬衍生查詢。但 $V$ 不能只由 $\mathcal{O}(s)$ 求得：設 $A$、$B$ 均只有兩個後繼 $t_1$（黑勝）與 $t_2$（白勝），$A$ 由黑方行棋，$B$ 由白方行棋，則

$$\mathcal{O}(A)=\mathcal{O}(B)=\{t_1,t_2\},\qquad V(A)\neq V(B)$$

$V$ 依賴於誰在何處選擇，即 $\Gamma$ 的結構，而不只是可達的終局集合。因此 $T_\Gamma^{implicit}$ 須保留 $q_2$ 所代表的轉移結構，不能以 $\mathcal{O}$ 取代。

### 1.5 非平凡的內容

$$\text{非平凡內容}=\text{可達結構}\ (q_1)\ +\ \text{未來／終局關係}\ (q_3)$$

$q_2$ 由 $\delta$ 局部給出，但 Ring 所研究的結構、重現與依賴，均建立在可達的轉移結構上。

## 2. 三成本模型

### 2.1 定義

精確表示 $D$ 的成本為

$$\big(C_B(D),\ C_S(D),\ C_Q(D)\big)$$

分別為建構、儲存與查詢成本。$C_Q$ 依查詢負載 $W$（$Q$ 上的分佈）取期望值或最大值：

$$C_Q(D)=\mathbb{E}_{q\sim W}\big[cost_D(q)\big]\quad\text{或}\quad\max_{q\in W}cost_D(q)$$

### 2.2 可接受的表示

只由規則構成的表示 $D_0=(s_0,\delta)$ 精確且完整，$C_B=0$、$C_S=O(1)$，但每次查詢 $q_3$ 須重新展開整個後續空間。排除此類退化表示：

$$cost_D(q)\ll cost_{D_0}(q)\qquad(q\in W)$$

除此之外，不預先指定查詢成本上限 $c_q$。$c_q=O(1)$ 實際上要求接近完整物化，會排除本筆記要研究的取捨。$c_q$ 依用途另行設定。

### 2.3 Pareto frontier

$$\mathcal{P}=\operatorname{Pareto}\big\{(C_B,C_S,C_Q)(D):\ D\ \text{精確、完整、可接受}\big\}$$

KBED 的計算問題改寫為：

$$\text{是否存在精確表示 }D\text{，在 }\mathcal{P}\text{ 上支配或補足完整物化與只用對稱的表示？}$$

$|S/\!\sim|$ 只是 $C_S$ 在商化機制下的一個座標，不是唯一指標。

### 2.4 下界

- 列舉 $\mathcal{O}(s)$ 的查詢成本不低於輸出大小 $|\mathcal{O}(s)|$，除非答案本身以集合式結構（如 BDD）表示。
- 逐狀態明確儲存 $\mathcal{O}$ 的空間為 $\sum_{s}|\mathcal{O}(s)|$，最壞為 $|S|\cdot|T|$。這相當於遞移閉包的物化。

### 2.5 表示點

| 表示 | $C_B$ | $C_S$ | $C_Q(q_3)$ |
|---|---|---|---|
| $D_0$ 規則本身（排除） | 0 | $O(1)$ | 整個後續空間 |
| 物化 $\Gamma$ | $(\lvert S\rvert+\lvert E\rvert)\,c_\delta$ | $\lvert S\rvert+\lvert E\rvert$ | 可達子圖的搜尋 |
| 物化 $\Gamma$ 與 $\mathcal{O}$ | 另加遞移閉包 | 另加 $\sum_s\lvert\mathcal{O}(s)\rvert$ | 查表 |
| 強連通分量縮合後的 DAG | 另加 $O(\lvert S\rvert+\lvert E\rvert)$ | 依分量數 | DAG 上的搜尋 |
| 可達性索引（2-hop 等） | 索引建構 | 標籤大小 | 標籤比對 |
| 盤面對稱商化 | ÷約 $\lvert G\rvert$，另加標準形 | ÷約 $\lvert G\rvert$ | 另加標準形 |
| 區域摘要（A、knot） | 命中多且 $C_{recog}<C_{derive}$ 時下降 | 下降 | 另加組合 |
| 延後節點（C） | 見第 4 節 | 下降 | 另加 $O(b^k)$ |
| BDD 集合式 | 集合運算 | BDD 大小 | 依變數數 |

## 3. Ring 的角色

Ring 不是尋找最小的狀態商，而是決定完整的未來結構在何處物化、何處摘要、何處映射、何處延後。設 $\{R_j\}$ 為 $S_{reach}$ 的區域分割（例如依層或依 knot），配置為

$$\Lambda:\ R_j\mapsto\{\mathrm{M},\ \Sigma,\ \Phi,\ \mathrm{D}\}$$

即物化、摘要、映射、延後。成本近似為各區域之和，另加區域間的依賴，例如映射須在摘要完成後才可使用：

$$C_X(\Lambda)\approx\sum_j C_X\big(R_j,\Lambda(R_j)\big)+C_X^{dep}(\Lambda),\qquad X\in\{B,S,Q\}$$

選擇 $\Lambda$ 為多目標最佳化。資料庫中的物化視圖選擇（Harinarayan、Rajaraman 與 Ullman）為同型的既有問題：在儲存限制下決定物化哪些視圖，以降低查詢成本；一般情形為 NP-hard，有貪婪近似。

## 4. 計算過程與機制

### 4.1 計算過程

以狀態標記的不動點迭代表示：

$$st:\ S\rightarrow\{\text{未知},\ \text{已展開},\ \text{完成},\ \text{映射}(\Phi,s'),\ \text{延後}\}$$

運算子：Expand（前向 $\delta$）、Map（商化與歷史段重用）、Close（$\mathcal{O}$ 的傳播）、Defer（延後）。套用順序即排程。各運算子保持精確性時，結果與順序無關（chaotic iteration，Cousot）；成本依順序而異。

### 4.2 各機制的作用

| 機制 | $C_B$ | $C_S$ | $C_Q$ | 條件與說明 |
|---|---|---|---|---|
| 盤面對稱 | 下降 | 下降 | 小幅增加 | 已實證，為正對照 |
| 商化 $\sim_{S,f}$、$\equiv_F$、強連通分量 | 只在展開前可辨認時下降 | 下降 | 另加映射 | 事後求得者只降低 $C_S$ |
| A 歷史段 $\approx$（v0.1 後續） | 在 $C_{recog}<C_{derive}$ 時下降 | 下降 | 另加組合 | 定義見第 4.3 節 |
| B Close | 單獨不變 | — | — | 見第 4.4 節 |
| C Defer | 單獨不變 | 下降 | 上升 | 見第 4.5 節 |
| E 排程 | 單獨不變 | 峰值改變 | — | 見第 4.6 節 |
| BDD | 依 BDD 大小 | 依 BDD 大小 | 依變數數 | 見第 4.7 節 |

### 4.3 A：歷史段重用

歷史段為帶標記的依賴圖：

$$H=(E_H,\ \le_H,\ \lambda_H,\ R(H),\ W(H))$$

$\le_H$ 為事件間的依賴順序，$\lambda_H:E_H\rightarrow\mathcal{T}/\!\equiv_T$ 為轉移類別，$R(H)$ 與 $W(H)$ 為讀取與改變的狀態部分。$H_A\approx H_B$ 若存在保持 $\le$ 與 $\lambda$ 的雙射 $\Phi$ 及盤面變換 $g$，使

$$g\big(R(H_A)\big)=R(H_B),\qquad s_B|_{R(H_B)}=g\big(s_A|_{R(H_A)}\big)$$

在已證明 $R(H)$ 充分時，$\Delta(H_B)=g(\Delta(H_A))$。事件與手數全部保留，只有效果的推導被重用。段長為 0、1 時分別為狀態等價與 $\equiv_T$；事件相同而只差順序時為 $\sim_T$；附錄 A.11.2 的區塊重用為線性段的特例，已得負面結果。對應的既有理論為圖轉換的 Concurrency 與 Embedding／Extension 定理、程式分析中的程序摘要、explanation-based generalization 與 macro-operator，以及 utility problem（Minton）。

### 4.4 B：Close

$\mathcal{O}$ 的傳播條件為

$$\mathcal{O}(s)\ \text{完成}\iff\forall s'\in Succ(s):\ \mathcal{O}(s')\ \text{完成}$$

（循環以強連通分量為單位處理。）與求 $V$ 不同，$\mathcal{O}$ 要求所有分支：已知某一分支的結果，不能省略其餘分支。因此 Close 單獨只決定傳播順序，不減少推導。若 Close 能對一整塊未展開區域給出精確的摘要或證明，則屬 A 或 Defer，可能減少建構成本。

### 4.5 C：Defer

$R_0$ 下任何非終局皆可 pass，出度至少為 2。跳過中間狀態而不計算，只在以下情形精確：被跳過的整塊區域（含所有分支）已有摘要，即 A 或 knot 分解。因此 Defer 單獨降低 $C_S$、提高 $C_Q$；降低 $C_B$ 須經由摘要。Syzygy 殘局庫將有可勝提子的局面存為 don't care、查詢時以提子搜尋還原，為降低儲存的既有實例；其完整表仍須先建構。

### 4.6 E：排程

沒有重用時，排程只影響中間規模 $W_{\max}$。重用單位為複合結構時（區域摘要、macro、閉合證明），單位須完成後才可套用，排程決定其多早可用，因而改變 $N_{indep}$。以標準情境逐步記憶化的重用，第一個實例即建立表項，排程不影響推導次數。符號式狀態空間生成中的 saturation（Ciardo 等）為排程大幅改變中間規模的既有例子。

### 4.7 BDD 集合式計算

集合式計算以一次符號運算處理一批狀態，運算量不依狀態逐一計算（Burch 等），為另一條精確且完整的基準路線。其成本取決於 BDD 大小與變數順序（Bryant）。在四子棋上，可達狀態集合存在多項式大小的 BDD，但終局條件在任何變數順序下皆需指數大小（Edelkamp 與 Kissmann）。圍棋的提子條件為非局部，對其 BDD 大小目前沒有資料。

## 5. 既有理論對照

| 問題 | 既有理論 | 對 KBED 的用途 | 不能直接套用之處 |
|---|---|---|---|
| $q_1$、$q_3$ 的查詢與儲存取捨 | 遞移閉包壓縮（Agrawal、Borgida 與 Jagadish）；2-hop 標籤（Cohen 等） | 物化 $\Gamma$ 後的查詢索引 | 須先有 $\Gamma$；不降低 $C_B$ |
| 終局關係的循環 | 強連通分量（Tarjan） | $\infty$ 的判定；同分量的 $\mathcal{O}$ 相同 | 事後求得 |
| 物化配置 | 物化視圖選擇（Harinarayan 等） | 第 3 節的 $\Lambda$ | 視圖間的依賴結構不同 |
| 不動點與排程 | chaotic iteration（Cousot）；saturation（Ciardo 等） | 結果與順序無關、成本依順序而異 | 圍棋的事件局部性有限 |
| 歷史段重用 | 圖轉換；程序摘要（Reps、Horwitz 與 Sagiv）；EBG；utility problem | A | 提子條件非局部；辨識成本 |
| 延後與還原 | Syzygy 的 don't care 編碼 | C | 完整表須先建構 |
| 集合式計算 | symbolic model checking（Burch 等）；BDD（Bryant）；Edelkamp 與 Kissmann | 基準路線 | 圍棋的 BDD 大小未知 |

## 6. 候選實驗（不執行）

### E4：歷史段重用

- 假設：在 3×3 的 $\Gamma$ 上，以依賴圖與最小讀集定義的長度 $k$ 段，類別數遠少於出現次數，且隨 $k$ 的成長慢於附錄 A.11.2 的線性區塊。
- 精確性判準：每一出現的 $\Delta$ 與類別代表一致。
- 基準：附錄 A.11.2 的線性區塊。
- 指標：類別數、命中率、辨識操作數 ÷ 推導操作數。
- 否證：類別數同樣約每步乘 9，或 $C_{recog}\ge C_{derive}$。

### E5：Pareto 點

- 假設：除完整物化與只用對稱之外，存在不被支配的精確表示。
- 精確性判準：在固定的查詢負載下，每一查詢的答案與物化 $\Gamma$ 及 $\mathcal{O}$ 的結果逐一相同。
- 基準：物化 $\Gamma$；物化 $\Gamma$ 加盤面對稱。
- 指標：各表示的 $(C_B,C_S,C_Q)$；$|\mathcal{O}(s)|$ 與 $|\mathcal{O}_{Out}(s)|$ 的分佈；強連通分量的數目與大小。
- 否證：所有候選表示皆被物化 $\Gamma$ 加盤面對稱所支配。

### E6：排程

- 假設：在含複合重用單位的計算中，不同排程的 $N_{indep}$ 與 $W_{\max}$ 有顯著差異。
- 精確性判準：各排程的最終結果相同。
- 基準：逐層前向展開。
- 指標：$N_{indep}$、$W_{\max}$、總操作數。
- 否證：各排程的 $N_{indep}$ 相同，差異只在 $W_{\max}$。

### E7：BDD 大小

- 假設：$S_{reach}$、各層 $L_t$ 或 $\mathcal{O}$ 的集合，在某些變數順序下的 BDD 遠小於明確儲存。
- 精確性判準：BDD 所表示的集合與明確集合逐一相同。
- 基準：明確儲存。
- 指標：各變數順序下的 BDD 節點數；集合運算的總成本。
- 否證：所有測試的變數順序下，BDD 節點數不小於明確儲存的規模。

## 7. 與 v0.1、v1.9 的關係

- v0.1 的空間軸與時間軸，在本模型中屬 Map 運算子；歷史段 $\approx$ 為 Map 的推廣。
- v1.9 的 L1 寫「可經 $\phi$ 精確取得」，未規定查詢成本；L2 以狀態與計算量為判準。日後可改寫為 $\mathcal{P}$ 上的支配關係。本筆記不修改 v1.9。
- v1.9 第 13 節的否證條件中，$\rho\rightarrow1$ 只涉及商化這一座標；在本模型下，否證須以 $\mathcal{P}$ 上不存在優於基準的表示為準。
- 版本判準不變：只有在組合多種計算依賴的表示形成理論，或在 $\mathcal{P}$ 上得到優於基準的結果時，才考慮 KBED 2.0。

待研究的問題：

1. $R_0$ 下合法盤面是否皆可達。
2. $|\mathcal{O}(s)|$ 的規模，以及 $\mathcal{O}_{Out}$ 的等價比 $\equiv_F$ 粗多少。
3. 配置 $\Lambda$ 是否可利用層或 knot 的結構，而不需一般的多目標搜尋。
4. 圍棋上是否存在盤面對稱以外、在 $\mathcal{P}$ 上不被支配的表示。

## 參考資料

- Agrawal, R., Borgida, A., & Jagadish, H. V. Efficient Management of Transitive Relationships in Large Data and Knowledge Bases. SIGMOD 1989, 253–262.
- Bryant, R. E. Graph-Based Algorithms for Boolean Function Manipulation. IEEE Transactions on Computers C-35(8), 677–691, 1986.
- Burch, J. R., Clarke, E. M., McMillan, K. L., Dill, D. L., & Hwang, L. J. Symbolic Model Checking: 10^20 States and Beyond. Information and Computation 98(2), 142–170, 1992.
- Ciardo, G., Lüttgen, G., & Siminiceanu, R. Saturation: An Efficient Iteration Strategy for Symbolic State-Space Generation. TACAS 2001, LNCS 2031, 328–342.
- Cohen, E., Halperin, E., Kaplan, H., & Zwick, U. Reachability and Distance Queries via 2-Hop Labels. SIAM Journal on Computing 32(5), 1338–1355, 2003. https://doi.org/10.1137/S0097539702403098
- Cousot, P. Asynchronous Iterative Methods for Solving a Fixed Point System of Monotone Equations in a Complete Lattice. Research Report R.R. 88, IMAG, Grenoble, 1977.
- de Man, R. Syzygy 殘局庫的 WDL 編碼說明. TalkChess, 2013. https://talkchess.com/viewtopic.php?p=514499
- Edelkamp, S., & Kissmann, P. On the Complexity of BDDs for State Space Search: A Case Study in Connect Four. AAAI 2011. https://ojs.aaai.org/index.php/AAAI/article/view/7821
- Ehrig, H., Ehrig, K., Prange, U., & Taentzer, G. Fundamentals of Algebraic Graph Transformation. Springer, 2006.
- Harinarayan, V., Rajaraman, A., & Ullman, J. D. Implementing Data Cubes Efficiently. SIGMOD 1996, 205–216.
- Minton, S. Quantitative Results Concerning the Utility of Explanation-Based Learning. Artificial Intelligence 42(2–3), 363–391, 1990.
- Mitchell, T. M., Keller, R. M., & Kedar-Cabelli, S. T. Explanation-Based Generalization: A Unifying View. Machine Learning 1(1), 47–80, 1986.
- Reps, T., Horwitz, S., & Sagiv, M. Precise Interprocedural Dataflow Analysis via Graph Reachability. POPL 1995, 49–61.
- Tarjan, R. E. Depth-First Search and Linear Graph Algorithms. SIAM Journal on Computing 1(2), 146–160, 1972.
