# KBED Ring 雙向多解析度結構：探索筆記 v3.0

Oct 7, 2026 · Chen-En Hou

## 0. 範圍與限制

本筆記延續 Ring 探索筆記 v0.1 與 v0.2。由於建構架構的改變較大，版本號改為 3.0；此版本號屬於 Ring 筆記系列，不等同 KBED 2.0。本筆記不修改 KBED Methodology v1.9，不執行新實驗，不提出新定理。

本版為 v3.0 的補強，版本號不變。新增研究問題（第 1 節）、單調系統的對照（第 3.3、4.4 節）、跨系統基準（第 11 節）、文獻定位與比較矩陣（第 12 節）、可能結果的解讀（第 13 節），並更新候選實驗（第 14 節）。原有對圍棋與 $R_0$ 的限制分析全部保留。

v0.2 的目標 $T_\Gamma^{implicit}$、三成本模型與精確查詢原則保留：

$$Coverage=100\%,\qquad Exactness=100\%,\qquad Materialization\le100\%$$

本筆記檢查的問題為：有限系統的完整求解，能否由「逐步建立完整的可達圖」改為「建立完整、可精確展開與重建的雙向結構表示」。

## 1. 研究問題

### 1.1 主問題

$$\text{對巨大但有限、規則完全確定的系統，100\% 精確涵蓋是否必然要求近乎逐狀態、逐事件的獨立計算？}$$

形式化：給定有限轉移系統 $\Gamma=(S,E,\delta)$，是否存在精確表示或建構 $R$：

$$Soundness(R)=1,\qquad Completeness(R)=1$$

能依指定的查詢約定精確還原所需資訊，且

$$N_{indep}\ll|S|,\ |E|,\ N_{histories}$$

或至少在 $(C_{build},C_{storage},C_{query})$ 上存在不被既有精確基準支配的表示。

「全部算完」定義為

$$Exact\ representability/queryability=100\%$$

而非 $Materialization=100\%$。被壓縮、映射、macro 化或延後的具體狀態、事件與歷史仍屬於語意上的目標，只是不要求逐一獨立推導或物化。

### 1.2 更高層的問題

$$\text{有限而組合爆炸的確定系統，其計算量有多少來自可能性多，又有多少來自逐一表示與逐一推導的選擇？}$$

$$\text{狀態空間大小是否為獨立計算量的適當代理變數？或應量測 }N_{indep}\ ?$$

### 1.3 既有文獻已回答的部分

此問題本身並非新問題，既有文獻已給出兩個方向的答案：

- 正面：符號式模型檢查已證明精確計算不等於逐狀態列舉（Bryant；Burch 等）。四子棋 7×6 的全部 4,531,985,219,092 個可達局面，以 84,088,763 個 BDD 節點精確表示（Edelkamp 與 Kissmann，2008）。在該系統中，狀態數不是表示成本的適當代理。
- 負面：同一系統的終局條件在任何變數順序下需指數大小的 BDD（Edelkamp 與 Kissmann，2011）；一般化圍棋為 EXPTIME-complete（Robson）；對簡潔表示的圖，許多問題的複雜度呈指數上升（Papadimitriou 與 Yannakakis）。

因此主問題沒有一般的是或否答案，結果依系統而定。尚未系統化回答的是：哪些系統結構使精確的結構計算能降低獨立計算量（第 11 節）。

## 2. 目標的再定義

### 2.1 定義

$$\exists\ \text{有限的精確表示 }R:\quad Soundness(R)=100\%,\quad Completeness(R)=100\%,\quad Materialization(R)<100\%\ \text{允許}$$

此定義與 v0.2 的 $T_\Gamma^{implicit}$ 一致：兩者都要求所有可達結構與未來可精確查詢，而不要求逐項物化。

### 2.2 退化與所需條件

規則本身 $D_0=(s_0,\delta)$ 即為有限、精確、完整的表示，物化比例為 0。因此「存在有限精確表示」本身沒有內容。資訊量上也沒有障礙：$\Gamma$ 由一段短程式產生，其描述長度不超過 $|\delta|+O(\log N)$。困難在計算，不在資訊。

避免退化須加三項條件：

1. 查詢成本：$cost_R(q)\ll cost_{D_0}(q)$（v0.2 第 2.2 節）。
2. 證明可驗：每一被壓縮的區域附有證明，其驗證成本低於重新展開該區域。
3. 還原程序：每一查詢類別有明確的還原程序及其成本。

## 3. 終局空間

### 3.1 $R_0$ 下的基本事實

狀態為 $(b,p,k,c)$，$c$ 為連續 pass 數。

$$T=\{s:\ c=2\},\qquad \forall s\notin T:\ s\xrightarrow{pass}\xrightarrow{pass}T$$

因此：

- 任何可達盤面接兩次 pass 即為終局，$|T|$ 與 $|S|$ 同階，不遠小於 $|S|$。
- $Pre^{*}(T)=S_{reach}$：對整個 $T$ 做反向可達，得到全部狀態，沒有資訊。
- 以面積計分時，結果類別數不超過 $2N^2+1$，遠小於 $|T|$。

| 量 | 規模 |
|---|---|
| $\lvert S\rvert$ | 原空間 |
| $\lvert T\rvert$ | 與 $\lvert S\rvert$ 同階 |
| 終局結果類別 | 不超過 $2N^2+1$ |
| 終局的結構描述 | $T$ 本身只需一個條件 $c=2$；難處在可達性 |

終局集合本身的壓縮是平凡的。要壓縮的是關係 $s\mapsto\mathcal{O}(s)$，而不是集合 $T$。

### 3.2 推測：$\mathcal{O}(s)$ 可能近乎常數

$\mathcal{O}(s)$ 為合作意義下的可達：不問雙方是否願意，只問存在合法路徑。圍棋中任何棋塊都可經合作而被提取：對方填滿其外氣；有兩眼時，己方先填一眼（不構成自殺），對方再提。若由此可推得「自幾乎任一狀態可到達幾乎任一合法終局盤面」，則

$$\mathcal{O}(s)\approx T_{reach}\quad\text{對大多數 }s$$

此時 $\mathcal{O}$ 可以「全集減去少數例外」精確表示，壓縮容易，但所含資訊很少；未來結構中真正需要計算的內容，在於誰於何處選擇，即 $\Gamma$ 的交替結構。此推測未經驗證，小棋盤上可能有例外；3×3 的完整 $\Gamma$ 已存在，可直接檢驗（實驗 E8）。若成立，$q_3$ 的定義須重新考慮。

### 3.3 與單調系統的對照

第 3.1、3.2 節的結論依賴 $R_0$ 的兩項性質：pass 使任何局面兩步內可終局，以及提子使棋子可消失。單調系統（一般化五子棋 $G(m,n,k)$、四子棋）不具這兩項性質：

- 終局條件為局部條件的析取：$T=\bigvee_{w}\big(w\ \text{全為黑}\ \vee\ w\ \text{全為白}\big)\ \vee\ \text{棋盤已滿}$，其中 $w$ 為長度 $k$ 的直線窗口，共 $O(mn)$ 個。
- 棋子不消失：$s\rightarrow^{*}t\Rightarrow b_s\subseteq b_t$。因此第 5.3 節的排除證明可直接取

$$Inv_s=\{t:\ b_t\supseteq b_s\}$$

  不需另行尋找。
- 轉移圖無循環，$\infty\notin\mathcal{O}(s)$；每一狀態只出現於一層（層數等於棋子數）。

$|T|$ 與 $|S|$ 的比例，以及 $\mathcal{O}(s)$ 在 $\{t:\ b_t\supseteq b_s\}$ 中所佔的比例，目前沒有資料。

## 4. 結構化反向

### 4.1 問題

$$C_T\ \overset{Pre^{*}}{\Longleftarrow}\ C_{T-1}\ \overset{Pre^{*}}{\Longleftarrow}\ \cdots$$

其中 $C_t$ 為狀態集合、結構條件或其他壓縮表示。問題為 $Pre$ 能否直接作用於壓縮表示，以及

$$C_{\text{compressed }Pre}<C_{\text{enumerate predecessors}}\ ?$$

### 4.2 既有理論

| 方法 | 數學對象 | 對應 |
|---|---|---|
| 符號式前像 | $Pre_\exists(X)=\{s:\exists a,\ \delta(s,a)\in X\}$，$X$ 以 BDD 表示（Burch 等） | 直接作用於集合表示 |
| 博弈的可控前像 | $CPre(X)$：輪到一方時存在後繼於 $X$，輪到另一方時所有後繼於 $X$；attractor 的不動點（Zielonka） | 交替結構下的反向 |
| 謂詞轉換 | 最弱前置條件 $wp$（Dijkstra） | 以條件而非集合表示 |
| IC3／PDR | 以 frames 過度近似可達集合；對壞狀態的前像做一般化，得到子句，再向前傳播（Bradley；Een 等） | 「終局側的結構壓縮」最接近的既有方法 |
| retrograde | 逐狀態的 un-move 生成（Thompson） | 枚舉式反向，即本問題要避免的形式 |

### 4.3 圍棋的反向

- 提子：前像須還原被提的棋塊，其形狀與位置不唯一；前像集合須表示「一組氣已被填滿的對方棋塊」，為非局部條件。
- 劫：前像須與劫禁點一致。
- pass：前像為同一盤面、$c-1$、行棋方互換。

轉移不可逆，前像為集合而非單一狀態。結構化反向只在這些集合的表示保持小時有利；四子棋的終局條件在任何變數順序下皆需指數大小的 BDD（Edelkamp 與 Kissmann），圍棋的提子條件涉及連通與氣，其表示大小目前沒有資料。

### 4.4 單調系統的反向

- $G(m,n,k)$：前像為移除上一手行棋方的一顆棋子，且所得局面不是終局；前像數不超過棋子數，不遺失資訊。
- 四子棋：前像為移除某一行最上方、屬上一手行棋方的棋子；前像數不超過行數。

單調系統的前像是局部且有界的，但這不保證符號式反向有利：四子棋的可達集合有多項式大小的 BDD，終局條件則需指數大小（Edelkamp 與 Kissmann，2011）。由終局叢集反推，正好作用於表示最困難的部分。

## 5. 前後接合

### 5.1 接合的層級

| 接合對象 | 條件 | 既有對應 |
|---|---|---|
| 具體狀態 | $s_F=s_B$ | 殘局庫與前向搜尋的結合 |
| 狀態集合 | $F\cap B\neq\emptyset$ 或 $F\subseteq B$ | 符號式前向與反向可達的組合 |
| 謂詞 | $F\models P_j$ | 即 v1.9 的 P4：展開前可判定的精確 signature |
| interface | $Interface(F)\cong Interface(B)$ | 開放系統的組合（interface automata）；v1.9 定理 1 |
| 未來簽名 | $FutureSignature(F)=BackwardSignature(B)$ | 若簽名為 $\equiv_F$ 的類別，即 bisimulation 商上的接合；若為較弱的簽名，屬直覺，尚無對應 |

### 5.2 雙向搜尋的節省不直接適用

雙向搜尋的節省來自單一目標：兩端各搜一半深度，$2b^{d/2}\ll b^d$。完整涵蓋要求前向側到達所有可達狀態，因此前後接合只在至少一側以壓縮形式涵蓋大區域時，才可能減少建構成本。

### 5.3 接合的最小證明

對區域 $X$ 宣稱 $\mathcal{O}(s)=\bigcup_{j\in J(X)}C_j$（$s\in X$），須有：

1. 包含：$\forall s\in X,\ \forall j\in J(X):\ C_j\subseteq\mathcal{O}(s)$。可由前像謂詞給出：$X\subseteq[\![P_j]\!]$，其中 $[\![P_j]\!]\subseteq\{s:\ C_j\subseteq\mathcal{O}(s)\}$。
2. 排除：存在歸納不變量 $Inv$：

$$X\subseteq Inv,\qquad Post(Inv)\subseteq Inv,\qquad Inv\cap T\subseteq\bigcup_{j\in J(X)}C_j$$

包含屬可達性，排除屬安全性。排除的證明即程式驗證中的歸納不變量。驗證兩者只需一步的 $Post$ 與謂詞包含的檢查，成本通常低於找到它們；但最小歸納不變量在最壞情形可為指數大小。

此外，叢集須與區域相容：在 $X$ 上，每個 $C_j$ 對所有 $s\in X$ 為全有或全無。否則 $\mathcal{O}$ 不能寫成叢集的聯集，須再細分 $X$ 或 $C_j$。

## 6. 多解析度收縮

### 6.1 層的收縮

層的演化為集合上的確定函數迭代（v1.8 第 6.2 節）：

$$L_b=Succ^{\,b-a}(L_a)$$

因此 $M_{a:b}=Succ^{\,b-a}$ 本身即為精確的跨層關係，中間層可由 $L_a$ 重算，不必保存。收縮不刪除歷史。

### 6.2 時間紀錄的保存

事件的身分可定義為 $(t,s,a)$，由 $s_0$、$\delta$ 與確定的列舉順序唯一決定，不需儲存。時間紀錄因此由確定性保存；儲存的只是為了降低查詢成本的檢查點。經對稱商化的事件，以代表元與 $g$ 還原其具體的 $s$。

### 6.3 檢查點與重算

只保存部分層、其餘重算，為儲存與查詢的取捨。對長度為 $n$ 的確定鏈，以二項式排程的檢查點，可使時間與空間的額外倍數皆為對數階（Griewank）。此方法降低 $C_S$，提高 $C_Q$，不降低 $C_B$。

### 6.4 降低建構成本的收縮

| 方法 | 機制 | 條件 |
|---|---|---|
| iterative squaring | 以 $R^{2k}=R^k\circ R^k$ 計算多步關係（符號式模型檢查） | 關係的 BDD 保持小 |
| 區域摘要 | 程序摘要、階層狀態機（Alur 與 Yannakakis）、v0.2 的歷史段 $\approx$ | 摘要可重用且 $C_{recog}<C_{derive}$ |
| 文法壓縮 | 以文法或 straight-line program 表示重複結構，並在壓縮形式上直接運算 | 結構高度重複 |

## 7. 結果叢集作為反向接合目標

$\mathcal{O}(s)=C_1\cup\cdots\cup C_k$。若反向側已有 $C_j$ 的前像謂詞 $P_j$，且前向結構 $F\models P_j$，則可直接建立 $F\Rightarrow C_j$。

此接合減少 $C_B$ 的條件：

$$C_{eval}(P_j,F)+C_{cert}<C_{expand}(F\rightarrow C_j)$$

且排除證明（第 5.3 節）同時存在。若 $P_j$ 的求值須展開 $F$ 的未來，成本只是轉移到證明；若排除證明不存在，只得到 $C_j\subseteq\mathcal{O}(s)$，不得到 $\mathcal{O}(s)$。

Benson 的無條件活棋為既有實例：它給出「這些棋塊永遠不被提取」的排除證明，可排除所有不含這些棋塊的終局。在合作意義的 $\mathcal{O}$ 下，對方可以配合，此排除不成立；Benson 的結論只在對抗意義下成立。這再次顯示第 3.2 節的問題：$\mathcal{O}$ 的合作語意與博弈的對抗語意，提供的可壓縮結構不同。

## 8. Ring 的再定義

$$Ring=\text{精確、可展開與收縮、可雙向建構、各區域可採不同解析度的計算結構}$$

$$\boxed{F}\rightarrow\boxed{U}\leftarrow\boxed{B}$$

終止條件為 $U=\emptyset$，且所有被壓縮的區域皆有證明與還原程序。

此定義合理，且與 v0.2 的配置 $\Lambda$ 相容：$\Lambda$ 的選項增加反向側的表示與接合。各解析度（事件、狀態、macro、結果叢集）在符號式模型檢查、IC3／PDR、階層狀態機與檢查點中皆有對應。

## 9. 最小形式模型

$$R=(F,\ U,\ B,\ M,\ J)$$

| 成分 | 定義 | 精確性條件 |
|---|---|---|
| $F$ | 前向已解區域：$\{(X_i,\kappa_i)\}$，$X_i$ 以明確或符號式表示，$\kappa_i$ 為可達證明 | $X_i\subseteq Post^{*}(s_0)$ |
| $B$ | 反向已解結構：$\{(C_j,P_j)\}$，$C_j\subseteq T$ 為結果叢集，$P_j$ 為前像謂詞 | $[\![P_j]\!]\subseteq\{s:\ C_j\subseteq\mathcal{O}(s)\}$ |
| $M$ | 跨層關係：$\{(M_{a:b},\ rec_{a:b})\}$ | $M_{a:b}=Succ^{\,b-a}$ 限於其定義域；$rec_{a:b}$ 精確還原中間層 |
| $J$ | 接合：$\{(X,\ J(X),\ Inv_X)\}$ | 第 5.3 節的包含、排除與叢集相容 |
| $U$ | 未解區域 | $U=Post^{*}(s_0)\setminus\big(\mathrm{dom}(J)\cup\text{已明確完成者}\big)$ |

四項要求：

| 要求 | 條件 |
|---|---|
| Coverage | $Post^{*}(s_0)\subseteq\bigcup_iX_i\cup Rec(M)$，且每一可達狀態的 $\mathcal{O}$ 由 $J$ 或明確傳播決定 |
| Exactness | 上表各成分的精確性條件；所有證明可機械驗證 |
| Reconstruction | 每一查詢類別有還原程序，成本符合查詢成本模型；事件身分 $(t,s,a)$ 可由確定性重算 |
| Termination | $S$ 有限，各運算子單調，且每一步使 $U$ 嚴格縮小或已證明的部分嚴格增加 |

## 10. 八個問題的回答

1. 與 v0.2 實質不同之處在建構方式：v0.2 的運算只有前向展開加上映射、閉合、延後；本模型加入反向的壓縮表示、接合證明與跨層收縮。目標與成本模型不變。
2. 沒有單一既有框架完整涵蓋，但符號式模型檢查加 IC3／PDR 幾乎涵蓋其中的計算機制：壓縮集合上的前像與後像、前後組合、跨多步的關係、以歸納不變量作證明。博弈的 attractor 涵蓋交替結構，檢查點涵蓋收縮與重算的取捨。
3. 剩餘的形式問題：
    - 既有方法驗證單一性質；KBED 要求對所有狀態的多種查詢，問題為多查詢的表示與成本的 Pareto 最佳化。
    - 各區域採不同解析度的配置（$\Lambda$）。
    - 圍棋的提子條件能否以小的符號表示。
    - $\mathcal{O}$ 的語意（第 3.2 節）。
4. 降低 $C_B$ 的可能來源：壓縮集合上的前像與後像（若表示保持小）；可廉價求值的前像謂詞接合；iterative squaring；區域摘要。只降低 $C_S$、提高 $C_Q$：檢查點收縮、終局集合的壓縮、延後。
5. 下界：
    - 資訊上沒有障礙（第 2.2 節）。以規則表示的 $\Gamma$ 屬簡潔表示的圖；對簡潔表示的圖，許多圖問題的複雜度呈指數上升（Papadimitriou 與 Yannakakis）。
    - 計算上：在 Japanese ko 規則下，一般化圍棋為 EXPTIME-complete（Robson），而 $P\neq EXPTIME$ 為無條件成立。因此對 $N\times N$ 的局面族，不存在多項式建構且多項式查詢博弈值的表示；壓縮必然在某一成本上付出。此結論涉及最壞局面，最難的局面是否可由空盤到達尚未確立。
    - 列舉 $\mathcal{O}(s)$ 的查詢成本不低於輸出大小，除非答案以集合表示。
    - 排除證明的最小歸納不變量在最壞情形可為指數大小。
6. 時間紀錄由確定性保存（第 6.2 節）。
7. 接合證明最少須保存包含與排除兩項，以及叢集相容（第 5.3 節）。
8. 構成 Ring 架構的候選，以本系列的版本號 3.0 記錄。是否構成 KBED 2.0，判準不變：須在 $\mathcal{P}$ 上得到優於基準的結果，或形成組合多種計算依賴表示的理論。

## 11. 跨系統驗證

### 11.1 識別問題

圍棋與 $R_0$ 同時具有：非單調演化、提子、氣與連通的非局部依賴、劫、pass、循環、前像不唯一，以及 $|T|$ 與 $|S|$ 同階。若在圍棋上觀察到 Ring 沒有削減，無法區分以下兩種解釋：

1. Ring 的原理沒有計算價值；
2. 圍棋恰好是對結構化反向、接合與壓縮極不友善的系統。

單一基準無法區分兩者。圍棋保留為困難的對照，不再單獨用來證明或否證 Ring 的一般性。

### 11.2 基準族

| 系統 | 單調 | 前像 | 終局結構 | 依賴範圍 | 循環 |
|---|---|---|---|---|---|
| $G(m,n,k)$ | 是 | 移除一子，局部、有界 | 長度 $k$ 窗口的析取 | 直線窗口 | 無 |
| 四子棋 | 是，另有重力限制 | 移除行頂一子，局部、有界 | 長度 4 窗口的析取 | 直線窗口 | 無 |
| 圍棋 $R_0$ | 否 | 提子與劫使前像不唯一 | $c=2$，關係困難 | 棋塊連通與氣，非局部 | 有 |

| 系統 | 既有結果 |
|---|---|
| $G(m,n,k)$ | (3,3,3) 和；$m,n\ge3$ 且其一 $\ge4$ 時 $(m,n,3)$ 先手勝；(5,5,4) 和、(6,5,4) 先手勝；(7,7,5)、(8,8,5) 和；15×15 自由式五子棋先手勝（Allis 等）；一般化五子棋為 PSPACE-complete（Reisch） |
| 四子棋 | 1988 年弱解（Allen；Allis）；可達局面 4,531,985,219,092，BDD 表示（Edelkamp 與 Kissmann）；7×6 強解，BDD 加 retrograde（Böck，2025） |
| 圍棋 $R_0$ | Japanese ko 規則下 EXPTIME-complete（Robson） |


$G(m,n,k)$ 不使用標準 15×15，而以可完全窮舉驗證的小型族逐步增加 $m,n,k$，例如 $G(3,3,3)$、$G(4,4,3)$、$G(5,5,4)$。四子棋使用小於 7×6、可完全驗證的棋盤，並以既有 BDD 結果作為外部參照。

### 11.3 候選的結構變數

$$Advantage_{Ring}\ \overset{?}{=}\ f(M,\ I,\ T,\ D,\ R,\ J)$$

| 變數 | 意義 | 候選量測 |
|---|---|---|
| $M$ | 單調性 | 是否存在沿每一轉移嚴格遞增的秩函數（如棋子數） |
| $I$ | 前像的局部性與歧義 | $\lvert Pre(s)\rvert$ 的分佈；前像是否需要非局部資訊 |
| $T$ | 終局的結構可壓縮性 | $T$ 與結果叢集在所測變數順序下的最小 BDD 大小 |
| $D$ | 依賴與 interface 寬度 | v1.8 P1′ 的 $\lvert I\rvert(L)$ |
| $R$ | 結構重現與可重用 macro 的密度 | v0.2 E4 的類別數 ÷ 出現次數 |
| $J$ | 接合的辨識與證明成本 | $(C_{eval}+C_{cert})/C_{expand}$ |

這些只是候選的解釋變數，不假定其間存在函數關係，也不構成定理。要問的是：哪些有限系統的結構條件，使精確的結構表示能真正降低獨立計算量。

### 11.4 比較的計算架構

為避免與建構成本 $C_B$ 混淆，架構記為 $\mathcal{A}$：

| 架構 | 內容 |
|---|---|
| $\mathcal{A}_F$ | 一般的完整前向建構 |
| $\mathcal{A}_B$ | 結構化或符號式的反向建構 |
| $\mathcal{A}_{FB}$ | 前向、反向與接合 |
| $\mathcal{A}_{FBM}$ | 前向、反向、接合與跨層收縮 |

每一架構皆記錄三成本 $(C_{build},C_{storage},C_{query})$，不只記錄實際時間；另記錄

$$N_{states},\quad N_{events},\quad N_{nodes},\quad N_{indep},\quad N_{macros},\quad N_{joins}$$

外部基準至少包含：盤面對稱、記憶化與置換表、明確的 retrograde、BDD 符號式前向與反向。精確性一律與完整的明確基準逐一比對。

## 12. 文獻定位

### 12.1 前人做了什麼

| 文獻族 | 已解決的問題 | 與 Ring 的關係 |
|---|---|---|
| 殘局庫與 retrograde | Thompson 以反向分析建立西洋棋殘局庫；Romein 與 Bal 以平行 retrograde 求得 Awari 所有可達局面的最佳著法 | 目標為逐狀態的值；涵蓋完整，但以明確表為主 |
| 對局求解 | 四子棋於 1988 年弱解（Allen；Allis）；Allis 等以 threat-space search 與 proof-number search 弱解 15×15 自由式五子棋，解樹含 138,790 個局面；Schaeffer 等弱解西洋跳棋：前向的證明樹搜尋接上反向的殘局庫（10 子以下，$3.9\times10^{13}$ 個局面） | 目標為值與策略；西洋跳棋已是前後接合的既有實例 |
| 符號式模型檢查 | BDD（Bryant）；符號式模型檢查（Burch 等）；saturation（Ciardo 等）；IC3／PDR（Bradley；Een 等） | 已證明精確計算不等於逐狀態列舉；Ring 不能以此為新意 |
| 四子棋與 BDD | 可達集合的 BDD 表示（Edelkamp 與 Kissmann，2008）；終局條件的指數下界（2011）；符號式與明確搜尋的混合，記憶體不足時切換為明確的 retrograde（Edelkamp、Kissmann 與 Rohte，2014）；7×6 強解（Böck，2025） | 本基準最接近的既有基準；「不同區域採不同表示」已有混合式的先例 |
| 雙向搜尋 | 雙向搜尋（Pohl）；符號式前向與反向的組合；殘局庫加前向搜尋（西洋跳棋） | 「由兩端計算再接合」本身已有 |
| 階層與組合 | 階層狀態機（Alur 與 Yannakakis）；組合式模型檢查（Clarke、Long 與 McMillan）；interface automata；程序摘要（Reps 等）；partial order reduction（Godefroid）；bisimulation 商；圖轉換 | macro、區域解析度與還原的個別機制皆已有 |
| 簡潔表示與成本取捨 | 簡潔圖的複雜度（Papadimitriou 與 Yannakakis）；2-hop 可達性索引；物化視圖選擇；檢查點（Griewank） | 建構、儲存與查詢之間不可避免的取捨 |

### 12.2 比較矩陣

| 方法 | 完整精確涵蓋 | 隱式表示 | 前向 | 反向 | 雙向接合 | 多解析度 | macro 重用 | 精確還原 | 多查詢成本最佳化 |
|---|---|---|---|---|---|---|---|---|---|
| 殘局庫／retrograde | 有¹ | 部分² | 無 | 有 | 無 | 無 | 無 | 有 | 部分³ |
| BDD 符號式模型檢查 | 有 | 有 | 有 | 有 | 部分⁴ | 部分⁵ | 部分⁶ | 有 | 無 |
| IC3／PDR | 無⁷ | 有 | 有 | 有 | 有⁸ | 無 | 無 | 部分⁹ | 無 |
| 階層狀態機與程序摘要 | 有 | 有 | 有 | 部分 | 無 | 有 | 有 | 有 | 無 |
| partial order reduction | 無¹⁰ | 無 | 有 | 無 | 無 | 無 | 無 | 部分 | 無 |
| 對局求解系統 | 部分¹¹ | 部分 | 有 | 有 | 有¹² | 無 | 部分¹³ | 部分 | 無 |
| Ring v3.0 | 設計 | 設計 | 設計 | 設計 | 設計 | 設計 | 設計 | 設計 | 設計 |

註：

1. 涵蓋一個子類的全部局面（殘局庫），或全部可達局面（Awari）。
2. 以明確表為主，另有壓縮編碼（如 Syzygy）。
3. 壓縮率與查詢成本的取捨（Syzygy 的 don't care 編碼）。
4. 符號式前向與反向可組合；Edelkamp 等先以 BDD 前向求可達集合，再反向分類。
5. 符號式與明確表示的混合切換（Edelkamp、Kissmann 與 Rohte）。
6. iterative squaring 計算多步關係。
7. 以性質為導向，證明單一性質，不完整表示可達集合。
8. frames 向前建構，對壞狀態的前像向後封鎖。
9. 反例路徑的還原。
10. 只保持指定性質，不表示全部狀態。
11. 弱解（西洋跳棋、五子棋、1988 年的四子棋）不涵蓋全部局面；強解（Awari、2025 年的四子棋 7×6）涵蓋全部可達局面的值。
12. 西洋跳棋的前向證明樹接上反向殘局庫。
13. 置換表只在狀態層級重用。

格中的「有」「部分」「無」依所引文獻自述的範圍填寫；Ring v3.0 一列只表示設計目標，尚無實作與驗證。

### 12.3 判斷

- 機制層級：表中每一欄都至少有一種既有方法具備。符號式模型檢查加上混合表示、階層摘要、前後接合（西洋跳棋）與物化視圖選擇，可組合出 Ring v3.0 的全部計算機制。在機制層級屬 Case 1：Ring 不構成新的計算原理。
- 問題的表述：「整個空間的精確多查詢表示 + 各區域的解析度與方向選擇 + 前後接合 + macro 還原 + 建構、儲存與查詢的最佳化」，在本次查證的文獻範圍內，未見作為同一問題的表述；但不能據此斷定不存在。若成立，屬 Case 2：架構與最佳化的表述，而非新數學。
- Case 3 未決：只有在跨系統實驗中，控制盤面對稱、記憶化、retrograde 與 BDD 等基準之後，仍出現既有方法不能解釋的 $N_{indep}$ 削減，才需進一步檢查是否有新的計算原理。

Ring 與符號式模型檢查的實質差異，剩下：

1. 目標：整個空間的多查詢精確表示，而非單一性質；
2. 明確的三成本目標與區域解析度配置；
3. 事件身分與時間紀錄的保存；
4. 以結果叢集為對象的接合。其中排除證明即 IC3 的歸納不變量，包含證明即前像。

前三項為問題表述上的差異，第四項的機制已有。

## 13. 可能結果的解讀

| 結果 | 條件 | 解讀 |
|---|---|---|
| A：所有系統皆無優勢 | $C_{Ring}\ge C_{baseline}$ | Ring 沒有一般的計算優勢，可能只是表示或組織架構 |
| B：$G(m,n,k)$ 有效，圍棋無效 | 依系統而異 | Ring 的有效性有結構邊界；下一問題為哪些結構性質決定精確可壓縮性。這是適用範圍的結果，不是失敗 |
| C：不同系統需要不同配置 | 例如 $G(m,n,k)$ 以反向與叢集、四子棋以符號式與雙向、圍棋以前向與局部商化 | Ring 的價值可能在配置的選擇（meta-level），而非單一演算法 |
| D：跨系統皆有顯著削減 | 控制盤面對稱、記憶化、retrograde 與 BDD 基準後仍存在 | 才值得進一步研究一般的精確計算架構 |

任何結果的「優勢」都以第 11.4 節的外部基準為準。四子棋已有很強的 BDD 結果，若 Ring 在四子棋上的表現不超過既有 BDD，不構成結果 D。

## 14. 候選實驗（不執行）

### E8：$\mathcal{O}(s)$ 的大小

- 假設：在 3×3 上，大多數可達狀態的 $\mathcal{O}(s)$ 接近全部可達的終局。
- 精確性判準：以完整 $\Gamma$ 逐狀態計算 $\mathcal{O}(s)$。
- 基準：$|T_{reach}|$。
- 指標：$|\mathcal{O}(s)|/|T_{reach}|$ 的分佈；$\mathcal{O}_{Out}$ 的相異類別數；例外狀態的結構。
- 否證：$|\mathcal{O}(s)|$ 對多數狀態遠小於 $|T_{reach}|$。
- 定位：此實驗只診斷圍棋的合作未來關係是否有資訊量，不在主研究問題的關鍵路徑上。只有在繼續發展圍棋專屬的 $q_3$ 與終局叢集反向表示時，才須先做。

### E9：符號式前像

- 假設：在 3×3 上，以 BDD 表示的反向可達，其中間集合的 BDD 遠小於明確集合。
- 精確性判準：與 retrograde 的明確結果逐一相同。
- 基準：逐狀態的 un-move 生成。
- 指標：各步 BDD 節點數、總運算成本、提子與劫的前像規模。
- 否證：所有測試的變數順序下，BDD 不小於明確集合。

### E10：接合謂詞

- 假設：以 Benson 類的條件為 $P_j$，在 3×3、3×4 上可對相當比例的狀態給出精確接合（對抗語意下）。
- 精確性判準：接合結果與完整計算逐一相同。
- 基準：完整前向展開。
- 指標：被接合的狀態比例、$C_{eval}+C_{cert}$ 與 $C_{expand}$ 的比值。
- 否證：被接合比例很小，或 $C_{eval}+C_{cert}\ge C_{expand}$。

### E11：檢查點收縮

- 假設：以檢查點保存部分層，可在對數階的查詢額外成本下大幅降低儲存。
- 精確性判準：重算的層與原層逐一相同。
- 基準：保存全部層。
- 指標：$C_S$、$C_Q$ 的曲線。
- 否證：此項為既有結果的實作檢驗，預期成立；主要用於校準成本模型。

### E12：$G(m,n,k)$ 族的跨架構比較

- 假設：在單調、前像局部的 $G(m,n,k)$ 上，$\mathcal{A}_{FB}$ 或 $\mathcal{A}_{FBM}$ 的 $N_{indep}$ 與三成本，相對於 $\mathcal{A}_F$ 與 BDD 基準有實質削減，且削減隨 $m,n,k$ 呈規律變化。
- 精確性判準：所有查詢與完整明確基準逐一相同。
- 基準：$\mathcal{A}_F$、盤面對稱、記憶化、明確 retrograde、BDD 前向與反向。
- 指標：三成本；$N_{states}$、$N_{events}$、$N_{nodes}$、$N_{indep}$、$N_{macros}$、$N_{joins}$；隨 $m,n,k$ 的變化。
- 否證：在此最友善的系統族上，所有 Ring 架構皆不優於 BDD 與 retrograde 基準。若如此，可較有把握地判斷問題不在圍棋，Ring 至少目前沒有額外的計算原理。

### E13：四子棋小棋盤

- 假設：在重力限制下，Ring 架構相對既有 BDD 方法的差異，與 $G(m,n,k)$ 不同。
- 精確性判準：與完整明確基準及既有 BDD 結果逐一相同。
- 基準：Edelkamp 與 Kissmann 及 Böck 的 BDD 方法（依其公開描述重做於小棋盤）。
- 指標：同 E12。
- 否證：結果與 $G(m,n,k)$ 無差異，則重力限制不是有效的結構變數。

### E14：結構變數的量測

- 假設：第 11.3 節的變數在三類系統間有可量測的差異，且與 E12、E13 及圍棋上的 Ring 效果有一致的方向。
- 精確性判準：各變數依其定義在完整 $\Gamma$ 上計算。
- 基準：無；此為描述性量測。
- 指標：各系統、各規模的 $M,I,T,D,R,J$。
- 否證：變數與 Ring 效果之間沒有一致的方向。此實驗只能顯示關聯，不能確立因果。

優先順序：

$$E12_{G(m,n,k)}\gg E12_{\text{四子棋}}>E12_{\text{圍棋}}>E8$$

先只做 $G(m,n,k)$。它是對 Ring 最有利的系統：單調、無循環、前像局部且有界，排除證明由棋子不消失直接給出（第 3.3 節）。若在此系統上 $C_{Ring}\ge C_{best\ baseline}$，且所有削減都可由盤面對稱、retrograde 或 BDD 解釋，則不必進入四子棋與圍棋，E8 可無限期擱置。只有在 $G(m,n,k)$ 上出現基準不能解釋的 $N_{indep}$ 削減，且削減與第 11.3 節的某些結構變數相關時，才依序進入四子棋，再回到圍棋；每一步只增加結構上的困難。

## 15. 與先前版本的關係與結論

- v0.1 的兩軸與 v0.2 的歷史段 $\approx$ 屬 $M$ 或 Map 類的機制；v0.2 的三成本與 $\Lambda$ 保留。
- v1.9 不修改。v1.9 的 P4 在本模型中為接合謂詞 $P_j$ 的特例，且本模型提供產生 $P_j$ 的另一個來源：由終局側的反向計算，而非由前向側猜測。
- 第 3.2 節的推測只影響圍棋專屬的 $q_3$；跨系統比較的查詢約定在各系統上另行固定（第 14 節 E12）。

結論：

以本次查證的文獻而言，Ring v3.0 的各項計算機制皆已有。剩下尚未回答的研究問題有兩項，皆不是新演算法：

1. 表述與最佳化問題：對整個有限空間的精確多查詢表示，如何選擇各區域的解析度與建構方向，使 $(C_{build},C_{storage},C_{query})$ 最佳。此問題接近物化視圖選擇與符號式模型檢查的組合，但未見以此形式提出。
2. 結構刻畫問題：哪些系統性質（第 11.3 節）決定精確的結構計算能否降低獨立計算量。既有文獻有個別系統的結果，例如四子棋 BDD 的上下界，但未見跨系統的系統化刻畫。

圍棋上的困難屬表示問題，即提子與連通條件能否有小的符號表示。是否存在新的計算原理（Case 3），只能由跨系統實驗、相對於 BDD 與 retrograde 基準來回答，目前未決。

## 參考資料

- Allis, L. V. A Knowledge-Based Approach of Connect-Four: The Game Is Solved, White Wins. M.Sc. thesis, Vrije Universiteit Amsterdam, 1988.
- Allis, L. V., van den Herik, H. J., & Huntjens, M. P. H. Go-Moku Solved by New Search Techniques. AAAI Fall Symposium on Games: Planning and Learning, FS-93-02, 1993.
- Alur, R., & Yannakakis, M. Model Checking of Hierarchical State Machines. FSE 1998; ACM TOPLAS 23(3), 2001.
- Bradley, A. R. SAT-Based Model Checking without Unrolling. VMCAI 2011, LNCS 6538, 70–87.
- Bryant, R. E. Graph-Based Algorithms for Boolean Function Manipulation. IEEE Transactions on Computers C-35(8), 677–691, 1986.
- Burch, J. R., Clarke, E. M., McMillan, K. L., Dill, D. L., & Hwang, L. J. Symbolic Model Checking: 10^20 States and Beyond. Information and Computation 98(2), 142–170, 1992.
- Böck, M. Strongly Solving 7×6 Connect-Four on Consumer Grade Hardware. arXiv:2507.05267, 2025. https://arxiv.org/abs/2507.05267
- Ciardo, G., Lüttgen, G., & Siminiceanu, R. Saturation: An Efficient Iteration Strategy for Symbolic State-Space Generation. TACAS 2001, LNCS 2031, 328–342.
- Clarke, E. M., Long, D. E., & McMillan, K. L. Compositional Model Checking. LICS 1989.
- Cohen, E., Halperin, E., Kaplan, H., & Zwick, U. Reachability and Distance Queries via 2-Hop Labels. SIAM Journal on Computing 32(5), 1338–1355, 2003.
- de Alfaro, L., & Henzinger, T. A. Interface Automata. ESEC/FSE 2001, 109–120.
- Dijkstra, E. W. Guarded Commands, Nondeterminacy and Formal Derivation of Programs. Communications of the ACM 18(8), 453–457, 1975.
- Edelkamp, S., & Kissmann, P. On the Complexity of BDDs for State Space Search: A Case Study in Connect Four. AAAI 2011.
- Edelkamp, S., & Kissmann, P. Symbolic Classification of General Two-Player Games. KI 2008, LNCS 5243.
- Edelkamp, S., Kissmann, P., & Rohte, M. Symbolic and Explicit Search Hybrid through Perfect Hash Functions: A Case Study in Connect Four. ICAPS 2014. https://doi.org/10.1609/icaps.v24i1.13637
- Een, N., Mishchenko, A., & Brayton, R. Efficient Implementation of Property Directed Reachability. FMCAD 2011.
- Godefroid, P. Partial-Order Methods for the Verification of Concurrent Systems. LNCS 1032, Springer, 1996.
- Griewank, A. Achieving Logarithmic Growth of Temporal and Spatial Complexity in Reverse Automatic Differentiation. Optimization Methods and Software 1(1), 35–54, 1992. https://doi.org/10.1080/10556789208805505
- Harinarayan, V., Rajaraman, A., & Ullman, J. D. Implementing Data Cubes Efficiently. SIGMOD 1996, 205–216.
- Papadimitriou, C. H., & Yannakakis, M. A Note on Succinct Representations of Graphs. Information and Control 71(3), 181–185, 1986.
- Pohl, I. Bi-Directional Search. Machine Intelligence 6, 127–140, 1971.
- Reisch, S. Gobang ist PSPACE-vollständig. Acta Informatica 13, 59–66, 1980. https://doi.org/10.1007/BF00288964
- Reps, T., Horwitz, S., & Sagiv, M. Precise Interprocedural Dataflow Analysis via Graph Reachability. POPL 1995, 49–61.
- Robson, J. M. The Complexity of Go. Proceedings of the IFIP 9th World Computer Congress, 1983.
- Romein, J. W., & Bal, H. E. Solving Awari with Parallel Retrograde Analysis. IEEE Computer 36(10), 26–33, 2003. https://doi.org/10.1109/MC.2003.1236468
- Schaeffer, J., Burch, N., Björnsson, Y., Kishimoto, A., Müller, M., Lake, R., Lu, P., & Sutphen, S. Checkers Is Solved. Science 317(5844), 1518–1522, 2007.
- Thompson, K. Retrograde Analysis of Certain Endgames. ICCA Journal 9(3), 1986.
- OEIS A212693. Number of Legal 7×6 Connect-Four Positions after n Plies. https://oeis.org/A212693
- Uiterwijk, J. W. H. M., & van den Herik, H. J. The Advantage of the Initiative. Information Sciences 122(1), 43–58, 2000.
- Zielonka, W. Infinite Games on Finitely Coloured Graphs with Applications to Automata on Infinite Trees. Theoretical Computer Science 200(1–2), 135–183, 1998.
