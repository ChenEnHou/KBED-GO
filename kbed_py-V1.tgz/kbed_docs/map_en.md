# KBED Research Map

Oct 7, 2026 · Chen-En Hou

## 0. Purpose

This document locates KBED and the Ring within the research as a whole, lists for each layer the existing theory, the conclusions KBED has reached, and the open questions, and sets stopping points for further work. It modifies no existing version and reports no new results.

## 1. Research Tree

| Level | Question |
|---|---|
| Original problem | Generation should not use $P(x_{t+1}\mid x_{\le t})$ as the main mechanism for deciding what is true |
| Architecture | First establish what the world permits, then search, reason, and verify within it: A → B → C → D → E |
| KBED | Layer C: when the full space is too large, does 100% coverage require computing each possibility independently? |
| Ring | Within KBED: where is computation repeated, and can it be represented structurally rather than derived one by one? |
| E12 | Within the Ring: on finite systems with fully known rules, does the Ring add computational value beyond established baselines? |

The five layers of the architecture:

| Layer | Content |
|---|---|
| A | World representation and constraint acquisition |
| B | Construction of the feasible space |
| C | Exact structural computation |
| D | Prioritization under uncertainty |
| E | Verification and output |

Go, Gomoku, and Connect Four are experimental environments for layer C: rules, states, terminals, and state equality are all known, the spaces are large enough, and exact baselines can be built. The difficulty of the real world is of another kind:

$$\text{Go: rules known, space huge}$$

$$\text{Real world: space huge, rules incomplete, states partially observed, boundaries uncertain}$$

## 2. Existing Theory and Open Questions by Layer

| Layer | Existing theory (examples) | KBED's contribution | Open questions |
|---|---|---|---|
| A | Constraint acquisition (Bessiere et al.); causal models | None | Where constraints come from; how to tell that a variable is missing |
| B | Language models translating problems into constraints or programs for a solver (Logic-LM; SatLM; PAL); goal regression in planning | None | Building the feasible space when rules are incomplete; working back from a question to the constraints it needs |
| C | Symbolic model checking; retrograde analysis; bisimulation quotients; compositional minimization; IC3/PDR; game solving | See Section 3 | Whether the Ring adds value beyond established baselines (E12) |
| D | Bisimulation metrics (Ferns, Panangaden, and Precup); causal abstraction (Rubenstein et al.; Beckers and Halpern) | The position in Section 4 | Error bounds and revision for approximate equivalence; the layer at which probability enters |
| E | Program verification; proof checking | The distinction between certificates and reconstruction | How to verify without ground truth |

The existing theory listed for layers A, B, D, and E consists of preliminary examples only; full literature positioning has not been done.

## 3. Transferable Conclusions from KBED

These conclusions come from KBED v1.9 and Ring notes v0.1, v0.2, and v3.0, and all belong to layer C:

1. Complete coverage does not require deriving every possibility independently. Symmetry-first expansion demonstrates this, but it is an established method.
2. Apart from provable structure (board symmetry, Benson-type conditions), no equivalence has been found that can be recognized exactly before expansion. Post-hoc bisimulation shows about 35% additional redundancy but cannot reduce first-stage expansion.
3. Whether reuse pays off depends on $C_{recognize}$ versus $C_{derive}$. In Go, block mapping costs more than derivation, a negative result; this is the utility problem.
4. "Computing everything" must be defined together with a query cost; otherwise the rules themselves are a trivial complete solution.
5. Backward computation needs a target condition, not necessarily terminal states. Cooperative and adversarial semantics offer different compressible structure.
6. In monotonic systems, the fact that stones never disappear directly provides exclusion certificates.
7. Every computational mechanism of Ring v3.0 already exists in the literature. What remains is problem formulation (multiple queries, three costs, regional resolution) and structural characterization (which system properties determine exact compressibility).

## 4. Where Probability Belongs

From point 2 of Section 3: even in systems with fully known rules, "which situations can be treated as the same" is hard to prove exactly before expansion; in a real world with incomplete rules it can only be approximated, and must remain revisable. This suggests a position, at present only a hypothesis:

$$\text{Probability represents uncertainty about constraints and equivalence, not the mechanism that produces answers}$$

Probability thus sits in layer D, acting on "which constraints hold" and "which situations may be treated as equivalent", rather than serving as the main mechanism for generating content step by step. Bisimulation metrics generalize $\equiv_F$ into a distance between future behaviors, and causal abstraction addresses when two systems can be treated as the same causal structure; these are the closest existing theories to this position.

## 5. Further Work and Stopping Points

| Work | Layer | Purpose | Stopping point |
|---|---|---|---|
| E12 ($G(m,n,k)$) | C | Establish whether the Ring adds computational value on the most favorable system | If it does not beat the board-symmetry, retrograde, and BDD baselines, end the study of the Ring as a new computational method; do not proceed to Connect Four or Go |
| Literature positioning for layers A, B, D | A, B, D | Determine which part of the original problem is genuinely unanswered | Complete before proposing any new architecture |
| E8 ($\mathcal{O}(s)$ in Go) | C | Go-specific diagnostic | Deferred unless Go-specific representations are pursued |

The result of E12 decides only whether the Ring is worth pursuing as an exact method for finite systems; it does not decide the original architecture problem and does not affect the position in Section 4.

## 6. Document Lineage

| Document | Layer | Status |
|---|---|---|
| KBED Methodology v1.8 | C | Frozen intermediate version |
| KBED Methodology v1.9 | C | Stable version of the first stage |
| Ring Exploratory Note v0.1: Structural Equivalence | C | Complete |
| Ring Exploratory Note v0.2: Computational Target and Three-Cost Model | C | Complete |
| Ring Exploratory Note v3.0: Bidirectional Multi-Resolution Structure | C | Complete; E12 pending |
| This research map | All | New |

## References

- Beckers, S., & Halpern, J. Y. Abstracting Causal Models. AAAI 2019. https://ojs.aaai.org/index.php/AAAI/article/view/4117
- Bessiere, C., Coletta, R., Koriche, F., & O'Sullivan, B. A SAT-Based Version Space Algorithm for Acquiring Constraint Satisfaction Problems. ECML 2005. https://doi.org/10.1007/11564096_8
- Ferns, N., Panangaden, P., & Precup, D. Metrics for Finite Markov Decision Processes. UAI 2004. https://arxiv.org/abs/1207.4114
- Gao, L., et al. PAL: Program-aided Language Models. ICML 2023. https://proceedings.mlr.press/v202/gao23f.html
- Pan, L., Albalak, A., Wang, X., & Wang, W. Y. Logic-LM: Empowering Large Language Models with Symbolic Solvers for Faithful Logical Reasoning. Findings of EMNLP 2023. https://arxiv.org/abs/2305.12295
- Rubenstein, P. K., Weichwald, S., Bongers, S., Mooij, J. M., Janzing, D., Grosse-Wentrup, M., & Schölkopf, B. Causal Consistency of Structural Equation Models. UAI 2017.
- Ye, X., Chen, Q., Dillig, I., & Durrett, G. SatLM: Satisfiability-Aided Language Models Using Declarative Prompting. NeurIPS 2023. https://arxiv.org/abs/2305.09656
- References for layer C are given in KBED Methodology v1.9 and Ring Exploratory Note v3.0.
